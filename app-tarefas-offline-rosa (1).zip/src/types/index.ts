// ============= ENUMS =============
export enum Priority {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH'
}

export enum OccurrenceStatus {
  PENDING = 'PENDING',
  DONE = 'DONE'
}

export enum RecurrenceType {
  DAILY = 'DAILY',
  WEEKLY = 'WEEKLY',
  BIWEEKLY = 'BIWEEKLY',
  MONTHLY = 'MONTHLY'
}

export enum MonthlyMode {
  DAY_OF_MONTH = 'DAY_OF_MONTH',
  NTH_WEEKDAY = 'NTH_WEEKDAY'
}

export enum EndMode {
  NEVER = 'NEVER',
  UNTIL_DATE = 'UNTIL_DATE',
  AFTER_COUNT = 'AFTER_COUNT'
}

export type Weekday = 'MON' | 'TUE' | 'WED' | 'THU' | 'FRI' | 'SAT' | 'SUN';
export type NthWeek = 1 | 2 | 3 | 4 | 'LAST';

// ============= RECURRENCE RULE =============
export interface RecurrenceEnd {
  mode: EndMode;
  untilDate?: string; // YYYY-MM-DD
  count?: number;
}

export interface DailyRule {
  type: RecurrenceType.DAILY;
  interval: number;
  end: RecurrenceEnd;
}

export interface WeeklyRule {
  type: RecurrenceType.WEEKLY;
  interval: number;
  weekdays: Weekday[];
  end: RecurrenceEnd;
}

export interface BiweeklyRule {
  type: RecurrenceType.BIWEEKLY;
  interval: number;
  dayOfPeriod: number; // Dia dentro da quinzena (1-15)
  end: RecurrenceEnd;
}

export interface MonthlyDayOfMonthRule {
  type: RecurrenceType.MONTHLY;
  interval: number;
  monthlyMode: MonthlyMode.DAY_OF_MONTH;
  dayOfMonth: number;
  end: RecurrenceEnd;
}

export interface MonthlyNthWeekdayRule {
  type: RecurrenceType.MONTHLY;
  interval: number;
  monthlyMode: MonthlyMode.NTH_WEEKDAY;
  nth: NthWeek;
  weekday: Weekday;
  end: RecurrenceEnd;
}

export type MonthlyRule = MonthlyDayOfMonthRule | MonthlyNthWeekdayRule;
export type RecurrenceRule = DailyRule | WeeklyRule | BiweeklyRule | MonthlyRule;

// ============= MODELS =============
export interface Task {
  id: string;
  title: string;
  description?: string;
  dueDate?: string; // YYYY-MM-DD
  dueTime?: string; // HH:mm
  priority: Priority;
  listId: string;
  reminderEnabled: boolean;
  recurrenceEnabled: boolean;
  recurrenceRuleJson?: string;
  recurrenceAnchorDate?: string; // YYYY-MM-DD
  createdAt: string;
  updatedAt: string;
}

export interface Subtask {
  id: string;
  taskId: string;
  title: string;
  done: boolean;
  sortOrder: number;
}

export interface ListCategory {
  id: string;
  name: string;
  colorHex: string;
  iconName: string;
}

export interface Tag {
  id: string;
  name: string;
  colorHex: string;
}

export interface TaskTag {
  id: string;
  taskId: string;
  tagId: string;
}

export interface TaskOccurrence {
  id: string;
  taskId: string;
  occurrenceDate: string; // YYYY-MM-DD
  status: OccurrenceStatus;
  completedAt?: string;
}

// ============= VIEW MODELS =============
export interface TaskWithRelations extends Task {
  subtasks: Subtask[];
  tags: Tag[];
  occurrence?: TaskOccurrence;
  cycleStatus?: 'pending' | 'overdue' | 'completed'; // Status do ciclo para tarefas recorrentes
}

export type ViewMode = 'list' | 'kanban' | 'calendar';
export type FilterType = 'all' | 'pending' | 'completed' | 'high' | 'medium' | 'low' | 'today';

// ==================== GOALS ====================

export type GoalType = 'HABIT' | 'OBJECTIVE';
export type RenewalPeriod = 'DAILY' | 'WEEKLY' | 'MONTHLY';

export interface Goal {
  id: string;
  title: string;
  description?: string;
  type: GoalType;
  icon: string;
  color: string;
  
  // Frequência
  renewalPeriod: RenewalPeriod;
  targetCount: number; // Quantas vezes por período
  
  // Para objetivos únicos
  totalTarget?: number; // Ex: ler 50 livros
  totalProgress?: number; // Progresso acumulado
  
  // Prazo
  deadline?: string; // YYYY-MM-DD
  
  // Streak
  currentStreak: number;
  bestStreak: number;
  lastCompletedDate?: string; // YYYY-MM-DD
  
  // Status
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface GoalProgress {
  id: string;
  goalId: string;
  date: string; // YYYY-MM-DD para DAILY, YYYY-Www para WEEKLY, YYYY-MM para MONTHLY
  periodStart: string; // YYYY-MM-DD início do período
  periodEnd: string; // YYYY-MM-DD fim do período
  count: number; // Quantas vezes foi feito nesse período
  completed: boolean;
  completedAt?: string;
}

// ==================== MEASUREMENTS ====================

export interface MeasurementEntry {
  id: string;
  dateKey: string; // YYYY-MM-DD
  weightKg?: number;
  waistCm?: number;
  bustCm?: number;
  armCm?: number;
  hipCm?: number;
  thighCm?: number; // Coxa - NOVO
  note?: string;
  createdAt: string;
  updatedAt: string;
}

export type MeasurementField = 'weightKg' | 'waistCm' | 'bustCm' | 'armCm' | 'hipCm' | 'thighCm';
export type MeasurementPeriod = '30days' | '3months' | '6months' | '1year' | 'all';

// Regras de delta: quais campos são "bons" quando diminuem
// Peso, Cintura, Braço, Busto = diminuir é bom (verde)
// Quadril, Coxa = aumentar é bom (verde)
export const DECREASE_IS_GOOD_FIELDS: MeasurementField[] = ['weightKg', 'waistCm', 'armCm', 'bustCm'];
export const INCREASE_IS_GOOD_FIELDS: MeasurementField[] = ['hipCm', 'thighCm'];

export interface DeltaStyle {
  color: string;
  icon: '↑' | '↓' | '→';
  text: string;
  isGood: boolean;
}

// ==================== NOTEPAD ====================

export interface NotepadNote {
  id: string;
  title: string;
  content: string;
  colorHex?: string;
  pinned: boolean;
  createdAt: string;
  updatedAt: string;
}

// ==================== SECRET DIARY ====================

export interface DiaryEntry {
  id: string;
  dateKey: string; // YYYY-MM-DD
  title: string;
  content: string;
  moodId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface SecretDiarySettings {
  hasPin: boolean;
  pinHash?: string;
  biometryEnabled: boolean;
  failedAttempts: number;
  lockedUntil?: string;
}

// ==================== MY RECORDS (Calorias & Jejum) ====================

export interface DailyHealthRecord {
  id: string;
  dateKey: string; // YYYY-MM-DD
  caloriesKcal?: number; // Total do dia
  fastingStartTime?: string; // HH:mm (parei de comer)
  fastingEndTime?: string; // HH:mm (comecei a comer no dia seguinte)
  fastingDurationMinutes?: number; // Calculado automaticamente
  note?: string;
  createdAt: string;
  updatedAt: string;
}

export interface MyRecordsGoals {
  id: string;
  calorieMinKcal?: number; // Meta mínima do intervalo
  calorieMaxKcal?: number; // Meta máxima do intervalo
  fastingTargetMinutes?: number; // Mínimo de jejum (ex 16h = 960)
  createdAt: string;
  updatedAt: string;
}

export interface WeeklyMyRecordsSummary {
  avgCalories: number | null;
  avgFastingMinutes: number | null;
  daysCaloriesHitGoal: number;
  daysCaloriesWithData: number;
  daysFastingHitGoal: number;
  daysFastingWithData: number;
  dailyRecords: DailyHealthRecordWithStatus[];
}

export interface DailyHealthRecordWithStatus {
  date: string;
  dayName: string;
  record: DailyHealthRecord | null;
  caloriesHitGoal: boolean | null;
  fastingHitGoal: boolean | null;
}
