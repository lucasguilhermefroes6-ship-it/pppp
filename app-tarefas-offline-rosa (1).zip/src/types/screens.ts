// All available screens in the app
export type Screen = 
  | { name: 'home' }
  | { name: 'tasks' }
  | { name: 'task-form'; taskId?: string }
  | { name: 'goals' }
  | { name: 'pomodoro' }
  | { name: 'notes' }
  | { name: 'note-view'; noteId: string }
  | { name: 'note-edit'; noteId?: string }
  | { name: 'water' }
  | { name: 'sleep' }
  | { name: 'workout' }
  | { name: 'mood' }
  | { name: 'expenses' }
  | { name: 'new-transaction'; isFixed?: boolean }
  | { name: 'stats' }
  | { name: 'folders' }
  | { name: 'folder-edit'; folderId?: string }
  | { name: 'folder-detail'; folderId: string }
  | { name: 'folder-item-edit'; folderId: string; itemId?: string; itemType?: 'NOTE' | 'LINK' | 'CHECKLIST' }
  | { name: 'folders-search' }
  | { name: 'measurements' }
  | { name: 'measurement-edit'; entryId?: string }
  | { name: 'femininity' }
  | { name: 'health-summary' }
  | { name: 'wellbeing-summary' }
  | { name: 'notepad' }
  | { name: 'notepad-edit'; noteId?: string }
  | { name: 'secret-diary' }
  | { name: 'secret-diary-home' }
  | { name: 'secret-diary-edit'; entryId?: string; createNew?: boolean }
  | { name: 'secret-diary-settings' }
  | { name: 'my-records' }
  | { name: 'my-records-edit'; dateKey?: string }
  | { name: 'my-records-goals' }
  | { name: 'settings' }
  | { name: 'sleep-weekly-summary' };

export type ScreenName = Screen['name'];
