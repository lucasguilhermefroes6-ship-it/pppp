import { openDB, DBSchema, IDBPDatabase } from 'idb';
import { Task, Subtask, ListCategory, Tag, TaskTag, TaskOccurrence, OccurrenceStatus } from '@/types';

interface TasksDB extends DBSchema {
  tasks: {
    key: string;
    value: Task;
    indexes: { 'by-dueDate': string };
  };
  subtasks: {
    key: string;
    value: Subtask;
    indexes: { 'by-taskId': string };
  };
  categories: {
    key: string;
    value: ListCategory;
  };
  tags: {
    key: string;
    value: Tag;
  };
  taskTags: {
    key: string;
    value: TaskTag;
    indexes: { 'by-taskId': string; 'by-tagId': string };
  };
  taskOccurrences: {
    key: string;
    value: TaskOccurrence;
    indexes: { 'by-taskId': string; 'by-date': string; 'by-taskDate': string };
  };
}

let dbInstance: IDBPDatabase<TasksDB> | null = null;

export async function getDB(): Promise<IDBPDatabase<TasksDB>> {
  if (dbInstance) return dbInstance;
  
  dbInstance = await openDB<TasksDB>('tasks-db', 1, {
    upgrade(db) {
      // Tasks store
      const tasksStore = db.createObjectStore('tasks', { keyPath: 'id' });
      tasksStore.createIndex('by-dueDate', 'dueDate');
      
      // Subtasks store
      const subtasksStore = db.createObjectStore('subtasks', { keyPath: 'id' });
      subtasksStore.createIndex('by-taskId', 'taskId');
      
      // Categories store
      db.createObjectStore('categories', { keyPath: 'id' });
      
      // Tags store
      db.createObjectStore('tags', { keyPath: 'id' });
      
      // TaskTags store
      const taskTagsStore = db.createObjectStore('taskTags', { keyPath: 'id' });
      taskTagsStore.createIndex('by-taskId', 'taskId');
      taskTagsStore.createIndex('by-tagId', 'tagId');
      
      // TaskOccurrences store
      const occStore = db.createObjectStore('taskOccurrences', { keyPath: 'id' });
      occStore.createIndex('by-taskId', 'taskId');
      occStore.createIndex('by-date', 'occurrenceDate');
      occStore.createIndex('by-taskDate', ['taskId', 'occurrenceDate']);
    }
  });
  
  // Seed default categories
  const categories = await dbInstance.getAll('categories');
  if (categories.length === 0) {
    const defaultCategories: ListCategory[] = [
      { id: 'personal', name: 'Pessoal', colorHex: '#E91E63', iconName: 'user' },
      { id: 'work', name: 'Trabalho', colorHex: '#2196F3', iconName: 'briefcase' },
      { id: 'health', name: 'Saúde', colorHex: '#4CAF50', iconName: 'heart' },
      { id: 'shopping', name: 'Compras', colorHex: '#FF9800', iconName: 'shopping-cart' },
    ];
    
    for (const cat of defaultCategories) {
      await dbInstance.put('categories', cat);
    }
  }
  
  return dbInstance;
}

// ============= TASKS =============
export async function getAllTasks(): Promise<Task[]> {
  const db = await getDB();
  return db.getAll('tasks');
}

export async function getTaskById(id: string): Promise<Task | undefined> {
  const db = await getDB();
  return db.get('tasks', id);
}

export async function createTask(task: Task): Promise<Task> {
  const db = await getDB();
  await db.put('tasks', task);
  return task;
}

export async function updateTask(task: Task): Promise<Task> {
  const db = await getDB();
  task.updatedAt = new Date().toISOString();
  await db.put('tasks', task);
  return task;
}

export async function deleteTask(id: string): Promise<void> {
  const db = await getDB();
  await db.delete('tasks', id);
  
  // Delete related subtasks
  const subtasks = await db.getAllFromIndex('subtasks', 'by-taskId', id);
  for (const st of subtasks) {
    await db.delete('subtasks', st.id);
  }
  
  // Delete related task tags
  const taskTags = await db.getAllFromIndex('taskTags', 'by-taskId', id);
  for (const tt of taskTags) {
    await db.delete('taskTags', tt.id);
  }
  
  // Delete related occurrences
  const occurrences = await db.getAllFromIndex('taskOccurrences', 'by-taskId', id);
  for (const occ of occurrences) {
    await db.delete('taskOccurrences', occ.id);
  }
}

// ============= SUBTASKS =============
export async function getSubtasksByTaskId(taskId: string): Promise<Subtask[]> {
  const db = await getDB();
  const subtasks = await db.getAllFromIndex('subtasks', 'by-taskId', taskId);
  return subtasks.sort((a, b) => a.sortOrder - b.sortOrder);
}

export async function createSubtask(subtask: Subtask): Promise<Subtask> {
  const db = await getDB();
  await db.put('subtasks', subtask);
  return subtask;
}

export async function updateSubtask(subtask: Subtask): Promise<Subtask> {
  const db = await getDB();
  await db.put('subtasks', subtask);
  return subtask;
}

export async function deleteSubtask(id: string): Promise<void> {
  const db = await getDB();
  await db.delete('subtasks', id);
}

// ============= CATEGORIES =============
export async function getAllCategories(): Promise<ListCategory[]> {
  const db = await getDB();
  return db.getAll('categories');
}

// ============= TAGS =============
export async function getAllTags(): Promise<Tag[]> {
  const db = await getDB();
  return db.getAll('tags');
}

export async function createTag(tag: Tag): Promise<Tag> {
  const db = await getDB();
  await db.put('tags', tag);
  return tag;
}

export async function getTagsByTaskId(taskId: string): Promise<Tag[]> {
  const db = await getDB();
  const taskTags = await db.getAllFromIndex('taskTags', 'by-taskId', taskId);
  const tags: Tag[] = [];
  for (const tt of taskTags) {
    const tag = await db.get('tags', tt.tagId);
    if (tag) tags.push(tag);
  }
  return tags;
}

export async function setTaskTags(taskId: string, tagIds: string[]): Promise<void> {
  const db = await getDB();
  
  // Remove existing
  const existing = await db.getAllFromIndex('taskTags', 'by-taskId', taskId);
  for (const tt of existing) {
    await db.delete('taskTags', tt.id);
  }
  
  // Add new
  for (const tagId of tagIds) {
    const taskTag: TaskTag = {
      id: `${taskId}-${tagId}`,
      taskId,
      tagId
    };
    await db.put('taskTags', taskTag);
  }
}

// ============= TASK OCCURRENCES =============
export async function getOccurrenceByTaskAndDate(taskId: string, date: string): Promise<TaskOccurrence | undefined> {
  const db = await getDB();
  const occurrences = await db.getAllFromIndex('taskOccurrences', 'by-taskId', taskId);
  return occurrences.find(o => o.occurrenceDate === date);
}

export async function createOrUpdateOccurrence(occurrence: TaskOccurrence): Promise<TaskOccurrence> {
  const db = await getDB();
  await db.put('taskOccurrences', occurrence);
  return occurrence;
}

export async function markOccurrenceDone(taskId: string, date: string): Promise<TaskOccurrence> {
  const db = await getDB();
  let occurrence = await getOccurrenceByTaskAndDate(taskId, date);
  
  if (occurrence) {
    occurrence.status = OccurrenceStatus.DONE;
    occurrence.completedAt = new Date().toISOString();
  } else {
    occurrence = {
      id: `${taskId}-${date}`,
      taskId,
      occurrenceDate: date,
      status: OccurrenceStatus.DONE,
      completedAt: new Date().toISOString()
    };
  }
  
  await db.put('taskOccurrences', occurrence);
  return occurrence;
}

export async function markOccurrencePending(taskId: string, date: string): Promise<void> {
  const db = await getDB();
  const occurrence = await getOccurrenceByTaskAndDate(taskId, date);
  
  if (occurrence) {
    await db.delete('taskOccurrences', occurrence.id);
  }
}

export async function getOccurrencesByDate(date: string): Promise<TaskOccurrence[]> {
  const db = await getDB();
  return db.getAllFromIndex('taskOccurrences', 'by-date', date);
}

export async function getAllOccurrencesByTaskId(taskId: string): Promise<TaskOccurrence[]> {
  const db = await getDB();
  return db.getAllFromIndex('taskOccurrences', 'by-taskId', taskId);
}

// ============= NON-RECURRENT TASK COMPLETION =============
export async function toggleNonRecurrentTaskDone(task: Task): Promise<Task> {
  const db = await getDB();
  const now = new Date().toISOString();
  
  // For non-recurrent tasks, we toggle using a special "done" occurrence
  const date = task.dueDate || 'no-date';
  const occurrence = await getOccurrenceByTaskAndDate(task.id, date);
  
  if (occurrence?.status === OccurrenceStatus.DONE) {
    await markOccurrencePending(task.id, date);
  } else {
    await markOccurrenceDone(task.id, date);
  }
  
  task.updatedAt = now;
  await db.put('tasks', task);
  return task;
}

export async function isNonRecurrentTaskDone(task: Task): Promise<boolean> {
  const date = task.dueDate || 'no-date';
  const occurrence = await getOccurrenceByTaskAndDate(task.id, date);
  return occurrence?.status === OccurrenceStatus.DONE;
}

// ============= STATS =============
export async function getPendingTasksCount(): Promise<number> {
  const db = await getDB();
  const tasks = await db.getAll('tasks');
  const today = new Date().toISOString().split('T')[0];
  
  let count = 0;
  
  for (const task of tasks) {
    if (!task.recurrenceEnabled) {
      // Non-recurrent: check if not done
      const date = task.dueDate || 'no-date';
      const occurrence = await getOccurrenceByTaskAndDate(task.id, date);
      if (occurrence?.status !== OccurrenceStatus.DONE) {
        count++;
      }
    } else {
      // Recurrent: check if occurs today and not done today
      if (task.recurrenceRuleJson && task.recurrenceAnchorDate) {
        const { occursOnDate, parseRecurrenceRule } = await import('@/services/recurrenceService');
        const rule = parseRecurrenceRule(task.recurrenceRuleJson);
        if (rule && occursOnDate(rule, task.recurrenceAnchorDate, today)) {
          const occurrence = await getOccurrenceByTaskAndDate(task.id, today);
          if (occurrence?.status !== OccurrenceStatus.DONE) {
            count++;
          }
        }
      }
    }
  }
  
  return count;
}
