import {
  RecurrenceRule,
  RecurrenceType,
  MonthlyMode,
  Weekday,
  NthWeek,
  EndMode
} from '@/types';
import {
  parseISO,
  format,
  addDays,
  getDay,
  getDaysInMonth,
  startOfMonth,
  isBefore,
  isAfter,
  isSameDay,
  differenceInDays,
  differenceInWeeks,
  differenceInMonths
} from 'date-fns';

const WEEKDAY_MAP: Record<Weekday, number> = {
  SUN: 0,
  MON: 1,
  TUE: 2,
  WED: 3,
  THU: 4,
  FRI: 5,
  SAT: 6
};

const DAY_TO_WEEKDAY: Record<number, Weekday> = {
  0: 'SUN',
  1: 'MON',
  2: 'TUE',
  3: 'WED',
  4: 'THU',
  5: 'FRI',
  6: 'SAT'
};

function getWeekdayOfDate(date: Date): Weekday {
  return DAY_TO_WEEKDAY[getDay(date)];
}

function getNthWeekdayOfMonth(year: number, month: number, weekday: Weekday, nth: NthWeek): Date | null {
  const targetDay = WEEKDAY_MAP[weekday];
  const firstDayOfMonth = startOfMonth(new Date(year, month, 1));
  const daysInMonth = getDaysInMonth(firstDayOfMonth);
  
  const occurrences: Date[] = [];
  
  for (let day = 1; day <= daysInMonth; day++) {
    const date = new Date(year, month, day);
    if (getDay(date) === targetDay) {
      occurrences.push(date);
    }
  }
  
  if (occurrences.length === 0) return null;
  
  if (nth === 'LAST') {
    return occurrences[occurrences.length - 1];
  }
  
  const index = nth - 1;
  return occurrences[index] || null;
}

function checkEndCondition(rule: RecurrenceRule, _anchorDate: Date, checkDate: Date, occurrenceCount?: number): boolean {
  const end = rule.end;
  
  if (end.mode === EndMode.NEVER) return true;
  
  if (end.mode === EndMode.UNTIL_DATE && end.untilDate) {
    const untilDate = parseISO(end.untilDate);
    return !isAfter(checkDate, untilDate);
  }
  
  if (end.mode === EndMode.AFTER_COUNT && end.count && occurrenceCount !== undefined) {
    return occurrenceCount <= end.count;
  }
  
  return true;
}

export function occursOnDate(rule: RecurrenceRule, anchorDateStr: string, dateStr: string): boolean {
  const anchorDate = parseISO(anchorDateStr);
  const date = parseISO(dateStr);
  
  // Date must be on or after anchor
  if (isBefore(date, anchorDate) && !isSameDay(date, anchorDate)) {
    return false;
  }
  
  switch (rule.type) {
    case RecurrenceType.DAILY: {
      const daysDiff = differenceInDays(date, anchorDate);
      if (daysDiff < 0) return false;
      const isOnInterval = daysDiff % rule.interval === 0;
      if (!isOnInterval) return false;
      return checkEndCondition(rule, anchorDate, date, Math.floor(daysDiff / rule.interval) + 1);
    }
    
    case RecurrenceType.WEEKLY: {
      const weeksDiff = differenceInWeeks(date, anchorDate);
      if (weeksDiff < 0) return false;
      
      // Check if on correct interval week
      if (weeksDiff % rule.interval !== 0) return false;
      
      // Check if weekday matches
      const dateWeekday = getWeekdayOfDate(date);
      if (!rule.weekdays.includes(dateWeekday)) return false;
      
      return checkEndCondition(rule, anchorDate, date);
    }
    
    case RecurrenceType.MONTHLY: {
      const monthsDiff = differenceInMonths(date, anchorDate);
      if (monthsDiff < 0) return false;
      
      // Check interval
      if (monthsDiff % rule.interval !== 0) return false;
      
      if (rule.monthlyMode === MonthlyMode.DAY_OF_MONTH) {
        // Check if day matches
        if (date.getDate() !== rule.dayOfMonth) return false;
        
        // Check if month even has this day
        const daysInMonth = getDaysInMonth(date);
        if (rule.dayOfMonth > daysInMonth) return false;
        
        return checkEndCondition(rule, anchorDate, date);
      } else {
        // NTH_WEEKDAY
        const nthWeekday = getNthWeekdayOfMonth(date.getFullYear(), date.getMonth(), rule.weekday, rule.nth);
        if (!nthWeekday || !isSameDay(date, nthWeekday)) return false;
        
        return checkEndCondition(rule, anchorDate, date);
      }
    }
    
    default:
      return false;
  }
}

export function nextOccurrenceAfter(rule: RecurrenceRule, anchorDateStr: string, afterDateStr: string): Date | null {
  const anchorDate = parseISO(anchorDateStr);
  let currentDate = parseISO(afterDateStr);
  
  // Start from anchor if after date is before anchor
  if (isBefore(currentDate, anchorDate)) {
    currentDate = anchorDate;
  } else {
    currentDate = addDays(currentDate, 1);
  }
  
  // Limit search to 2 years to prevent infinite loops
  const maxDate = addDays(currentDate, 730);
  
  while (isBefore(currentDate, maxDate)) {
    const dateStr = format(currentDate, 'yyyy-MM-dd');
    if (occursOnDate(rule, anchorDateStr, dateStr)) {
      return currentDate;
    }
    currentDate = addDays(currentDate, 1);
  }
  
  return null;
}

export function occurrencesInRange(
  rule: RecurrenceRule, 
  anchorDateStr: string, 
  startDateStr: string, 
  endDateStr: string
): Date[] {
  const results: Date[] = [];
  const startDate = parseISO(startDateStr);
  const endDate = parseISO(endDateStr);
  let currentDate = startDate;
  
  while (!isAfter(currentDate, endDate)) {
    const dateStr = format(currentDate, 'yyyy-MM-dd');
    if (occursOnDate(rule, anchorDateStr, dateStr)) {
      results.push(new Date(currentDate));
    }
    currentDate = addDays(currentDate, 1);
  }
  
  return results;
}

export function parseRecurrenceRule(json: string): RecurrenceRule | null {
  try {
    return JSON.parse(json) as RecurrenceRule;
  } catch {
    return null;
  }
}

export function createDefaultRecurrenceRule(): RecurrenceRule {
  return {
    type: RecurrenceType.DAILY,
    interval: 1,
    end: { mode: EndMode.NEVER }
  };
}
