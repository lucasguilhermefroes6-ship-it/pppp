import { create } from 'zustand';

// ===== TIPOS =====
export interface MoodOption {
  id: string;
  label: string;
  emoji: string;
  color: string;
  bgColor: string;
  category: 'positive' | 'neutral' | 'negative';
}

export interface MoodEntry {
  id: string;
  dateKey: string; // YYYY-MM-DD
  moodId: string;
  label: string;
  emoji: string;
  color: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

// Lista de humores com emojis kawaii
export const MOOD_OPTIONS: MoodOption[] = [
  // Positivos
  { id: 'feliz', label: 'Feliz', emoji: '😊', color: '#FFB800', bgColor: '#FFF9E6', category: 'positive' },
  { id: 'animada', label: 'Animada', emoji: '🤩', color: '#FF6B9D', bgColor: '#FFE8F0', category: 'positive' },
  { id: 'grata', label: 'Grata', emoji: '🥰', color: '#FF7EB3', bgColor: '#FFE4EE', category: 'positive' },
  { id: 'apaixonada', label: 'Apaixonada', emoji: '😍', color: '#FF4D6D', bgColor: '#FFE0E6', category: 'positive' },
  { id: 'confiante', label: 'Confiante', emoji: '😎', color: '#7C4DFF', bgColor: '#EDE7FF', category: 'positive' },
  { id: 'energetica', label: 'Com energia', emoji: '⚡', color: '#FF9100', bgColor: '#FFF3E0', category: 'positive' },
  
  // Neutros
  { id: 'calma', label: 'Calma', emoji: '😌', color: '#4FC3F7', bgColor: '#E1F5FE', category: 'neutral' },
  { id: 'em_paz', label: 'Em paz', emoji: '☺️', color: '#81C784', bgColor: '#E8F5E9', category: 'neutral' },
  { id: 'normal', label: 'Normal', emoji: '🙂', color: '#90A4AE', bgColor: '#ECEFF1', category: 'neutral' },
  { id: 'pensativa', label: 'Pensativa', emoji: '🤔', color: '#9575CD', bgColor: '#EDE7F6', category: 'neutral' },
  { id: 'sonolenta', label: 'Sonolenta', emoji: '😪', color: '#78909C', bgColor: '#ECEFF1', category: 'neutral' },
  { id: 'cansada', label: 'Cansada', emoji: '😴', color: '#7986CB', bgColor: '#E8EAF6', category: 'neutral' },
  
  // Negativos
  { id: 'triste', label: 'Triste', emoji: '😢', color: '#42A5F5', bgColor: '#E3F2FD', category: 'negative' },
  { id: 'ansiosa', label: 'Ansiosa', emoji: '😰', color: '#FF8A65', bgColor: '#FBE9E7', category: 'negative' },
  { id: 'estressada', label: 'Estressada', emoji: '😤', color: '#EF5350', bgColor: '#FFEBEE', category: 'negative' },
  { id: 'nervosa', label: 'Nervosa', emoji: '😬', color: '#FFB74D', bgColor: '#FFF3E0', category: 'negative' },
  { id: 'preocupada', label: 'Preocupada', emoji: '😟', color: '#A1887F', bgColor: '#EFEBE9', category: 'negative' },
  { id: 'irritada', label: 'Irritada', emoji: '😠', color: '#E53935', bgColor: '#FFEBEE', category: 'negative' },
  { id: 'desmotivada', label: 'Desmotivada', emoji: '😞', color: '#78909C', bgColor: '#ECEFF1', category: 'negative' },
  { id: 'doente', label: 'Doente', emoji: '🤒', color: '#8D6E63', bgColor: '#EFEBE9', category: 'negative' },
];

interface MoodState {
  entries: MoodEntry[];
  isLoading: boolean;
  isModalOpen: boolean;
  editingDate: string | null;
  
  // Actions
  initialize: () => Promise<void>;
  saveMood: (moodId: string, dateKey?: string, notes?: string) => Promise<void>;
  getTodayMood: () => MoodEntry | null;
  getMoodByDate: (dateKey: string) => MoodEntry | null;
  getEntriesForLastDays: (days: number) => MoodEntry[];
  getTodayMoodLabel: () => string;
  getMoodStats: () => { positive: number; neutral: number; negative: number; mostFrequent: MoodOption | null };
  openModal: (dateKey?: string) => void;
  closeModal: () => void;
}

// Helper para gerar UUID
const generateId = () => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

// Helper para obter data no formato YYYY-MM-DD
const getDateKey = (date: Date = new Date()) => {
  return date.toISOString().split('T')[0];
};

// IndexedDB
const DB_NAME = 'vida-organizada-mood';
const STORE_NAME = 'mood';

const openDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
  });
};

export const useMoodStore = create<MoodState>((set, get) => ({
  entries: [],
  isLoading: true,
  isModalOpen: false,
  editingDate: null,

  initialize: async () => {
    try {
      const db = await openDB();
      const transaction = db.transaction(STORE_NAME, 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.getAll();
      
      request.onsuccess = () => {
        set({ entries: request.result || [], isLoading: false });
      };
      request.onerror = () => {
        set({ isLoading: false });
      };
    } catch (error) {
      console.error('Error initializing mood store:', error);
      set({ isLoading: false });
    }
  },

  saveMood: async (moodId: string, dateKey?: string, notes?: string) => {
    const targetDate = dateKey || getDateKey();
    const moodOption = MOOD_OPTIONS.find(m => m.id === moodId);
    if (!moodOption) return;

    const existing = get().entries.find(e => e.dateKey === targetDate);
    const now = new Date().toISOString();

    const entry: MoodEntry = existing ? {
      ...existing,
      moodId,
      label: moodOption.label,
      emoji: moodOption.emoji,
      color: moodOption.color,
      notes: notes || existing.notes,
      updatedAt: now,
    } : {
      id: generateId(),
      dateKey: targetDate,
      moodId,
      label: moodOption.label,
      emoji: moodOption.emoji,
      color: moodOption.color,
      notes,
      createdAt: now,
      updatedAt: now,
    };

    try {
      const db = await openDB();
      const transaction = db.transaction(STORE_NAME, 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      store.put(entry);

      set(state => ({
        entries: existing
          ? state.entries.map(e => e.dateKey === targetDate ? entry : e)
          : [...state.entries, entry],
        isModalOpen: false,
        editingDate: null,
      }));
    } catch (error) {
      console.error('Error saving mood:', error);
    }
  },

  getTodayMood: () => {
    const today = getDateKey();
    return get().entries.find(e => e.dateKey === today) || null;
  },

  getMoodByDate: (dateKey: string) => {
    return get().entries.find(e => e.dateKey === dateKey) || null;
  },

  getEntriesForLastDays: (days: number) => {
    const entries = get().entries;
    const result: MoodEntry[] = [];
    
    for (let i = 0; i < days; i++) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateKey = getDateKey(date);
      const entry = entries.find(e => e.dateKey === dateKey);
      if (entry) {
        result.push(entry);
      }
    }
    
    return result;
  },

  getTodayMoodLabel: () => {
    const today = get().getTodayMood();
    if (!today) return '—';
    return `${today.emoji} ${today.label}`;
  },

  getMoodStats: () => {
    const entries = get().entries;
    const thisMonth = new Date().toISOString().slice(0, 7);
    const monthEntries = entries.filter(e => e.dateKey.startsWith(thisMonth));
    
    let positive = 0, neutral = 0, negative = 0;
    const counts: Record<string, number> = {};
    
    monthEntries.forEach(entry => {
      const mood = MOOD_OPTIONS.find(m => m.id === entry.moodId);
      if (mood) {
        if (mood.category === 'positive') positive++;
        else if (mood.category === 'neutral') neutral++;
        else negative++;
        
        counts[entry.moodId] = (counts[entry.moodId] || 0) + 1;
      }
    });
    
    let mostFrequent: MoodOption | null = null;
    let maxCount = 0;
    Object.entries(counts).forEach(([moodId, count]) => {
      if (count > maxCount) {
        maxCount = count;
        mostFrequent = MOOD_OPTIONS.find(m => m.id === moodId) || null;
      }
    });
    
    return { positive, neutral, negative, mostFrequent };
  },

  openModal: (dateKey?: string) => {
    set({ isModalOpen: true, editingDate: dateKey || getDateKey() });
  },

  closeModal: () => {
    set({ isModalOpen: false, editingDate: null });
  },
}));
