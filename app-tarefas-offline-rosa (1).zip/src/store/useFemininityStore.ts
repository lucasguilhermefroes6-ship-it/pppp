import { create } from 'zustand';

export interface FemininityQuestion {
  id: string;
  text: string;
  icon: string;
  color: string;
}

export interface FemininityDailyLog {
  id: string;
  dateKey: string; // YYYY-MM-DD
  answers: Record<string, boolean>; // q1..q20 -> true/false
  createdAt: string;
  updatedAt: string;
}

// 20 perguntas fixas
export const FEMININITY_QUESTIONS: FemininityQuestion[] = [
  { id: 'q1', text: 'Hoje falei baixo e suavemente?', icon: 'volume', color: '#E91E63' },
  { id: 'q2', text: 'Hoje falei de forma doce?', icon: 'heart', color: '#C2185B' },
  { id: 'q3', text: 'Hoje falei devagar?', icon: 'clock', color: '#E91E63' },
  { id: 'q4', text: 'Hoje não menti?', icon: 'check', color: '#9C27B0' },
  { id: 'q5', text: 'Hoje fiz um exame de consciência?', icon: 'brain', color: '#7B1FA2' },
  { id: 'q6', text: 'Hoje procurei andar devagar?', icon: 'footprints', color: '#F06292' },
  { id: 'q7', text: 'Hoje falei pouco e ouvi mais?', icon: 'ear', color: '#7E57C2' },
  { id: 'q8', text: 'Me senti feminina hoje?', icon: 'sparkles', color: '#EC407A' },
  { id: 'q9', text: 'Fui delicada nos meus gestos?', icon: 'hand', color: '#BA68C8' },
  { id: 'q10', text: 'Fui paciente e compreensiva?', icon: 'smile', color: '#42A5F5' },
  { id: 'q11', text: 'Fui gentil com as pessoas?', icon: 'users', color: '#5C6BC0' },
  { id: 'q12', text: 'Mantive meu espaço organizado?', icon: 'home', color: '#F06292' },
  { id: 'q13', text: 'Cuidei da minha aparência?', icon: 'mirror', color: '#EF5350' },
  { id: 'q14', text: 'Fui educada e cortês?', icon: 'star', color: '#E91E63' },
  { id: 'q15', text: 'Falei de forma calma?', icon: 'feather', color: '#AB47BC' },
  { id: 'q16', text: 'Evitei fofoca hoje?', icon: 'lock', color: '#9575CD' },
  { id: 'q17', text: 'Não perdi a paciência hoje?', icon: 'leaf', color: '#4CAF50' },
  { id: 'q18', text: 'Fiz um autocuidado (skincare/banho/perfume)?', icon: 'droplet', color: '#E91E63' },
  { id: 'q19', text: 'Pratiquei gratidão hoje?', icon: 'sun', color: '#FFB300' },
  { id: 'q20', text: 'Fui amorosa comigo mesma?', icon: 'heart-handshake', color: '#E91E63' },
];

interface FemininityState {
  logs: FemininityDailyLog[];
  isLoading: boolean;
  
  // Actions
  initialize: () => Promise<void>;
  getTodayLog: () => FemininityDailyLog | null;
  createOrGetTodayLog: () => FemininityDailyLog;
  toggleAnswer: (questionId: string) => void;
  getTodayProgress: () => { completed: number; total: number };
  getProgressLabel: () => string;
  getLast7Days: () => Array<{ date: string; completed: number; total: number }>;
  getStreak: () => number;
}

const DB_NAME = 'femininity-db';
const STORE_NAME = 'logs';

// IndexedDB helper
const openDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        store.createIndex('dateKey', 'dateKey', { unique: true });
      }
    };
  });
};

const getDateKey = (date: Date = new Date()): string => {
  return date.toISOString().split('T')[0];
};

const generateId = () => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

export const useFemininityStore = create<FemininityState>((set, get) => ({
  logs: [],
  isLoading: true,

  initialize: async () => {
    try {
      const db = await openDB();
      const transaction = db.transaction(STORE_NAME, 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.getAll();
      
      request.onsuccess = () => {
        set({ logs: request.result || [], isLoading: false });
      };
      request.onerror = () => {
        set({ isLoading: false });
      };
    } catch (error) {
      console.error('Error initializing femininity store:', error);
      set({ isLoading: false });
    }
  },

  getTodayLog: () => {
    const { logs } = get();
    const todayKey = getDateKey();
    return logs.find(log => log.dateKey === todayKey) || null;
  },

  createOrGetTodayLog: () => {
    const { logs } = get();
    const todayKey = getDateKey();
    let todayLog = logs.find(log => log.dateKey === todayKey);
    
    if (!todayLog) {
      // Create new log for today
      const initialAnswers: Record<string, boolean> = {};
      FEMININITY_QUESTIONS.forEach(q => {
        initialAnswers[q.id] = false;
      });
      
      todayLog = {
        id: generateId(),
        dateKey: todayKey,
        answers: initialAnswers,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      
      // Save to state and DB
      set({ logs: [...logs, todayLog] });
      
      // Persist to IndexedDB
      openDB().then(db => {
        const transaction = db.transaction(STORE_NAME, 'readwrite');
        const store = transaction.objectStore(STORE_NAME);
        store.add(todayLog);
      });
    }
    
    return todayLog;
  },

  toggleAnswer: (questionId: string) => {
    const { logs } = get();
    const todayKey = getDateKey();
    let todayLog = logs.find(log => log.dateKey === todayKey);
    
    if (!todayLog) {
      // Create if not exists
      todayLog = get().createOrGetTodayLog();
    }
    
    // Toggle the answer
    const updatedLog = {
      ...todayLog,
      answers: {
        ...todayLog.answers,
        [questionId]: !todayLog.answers[questionId],
      },
      updatedAt: new Date().toISOString(),
    };
    
    // Update state
    const newLogs = logs.map(log => 
      log.dateKey === todayKey ? updatedLog : log
    );
    
    // If log wasn't in the list, add it
    if (!logs.find(log => log.dateKey === todayKey)) {
      newLogs.push(updatedLog);
    }
    
    set({ logs: newLogs });
    
    // Persist to IndexedDB
    openDB().then(db => {
      const transaction = db.transaction(STORE_NAME, 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      store.put(updatedLog);
    });
  },

  getTodayProgress: () => {
    const todayLog = get().getTodayLog();
    if (!todayLog) {
      return { completed: 0, total: FEMININITY_QUESTIONS.length };
    }
    
    const completed = Object.values(todayLog.answers).filter(Boolean).length;
    return { completed, total: FEMININITY_QUESTIONS.length };
  },

  getProgressLabel: () => {
    const { completed, total } = get().getTodayProgress();
    if (completed === 0) return 'Registro diário';
    return `Hoje: ${completed}/${total}`;
  },

  getLast7Days: () => {
    const { logs } = get();
    const result: Array<{ date: string; completed: number; total: number }> = [];
    
    for (let i = 0; i < 7; i++) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateKey = getDateKey(date);
      
      const log = logs.find(l => l.dateKey === dateKey);
      const completed = log 
        ? Object.values(log.answers).filter(Boolean).length 
        : 0;
      
      result.push({
        date: dateKey,
        completed,
        total: FEMININITY_QUESTIONS.length,
      });
    }
    
    return result;
  },

  getStreak: () => {
    const { logs } = get();
    let streak = 0;
    
    for (let i = 0; i < 365; i++) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateKey = getDateKey(date);
      
      const log = logs.find(l => l.dateKey === dateKey);
      const completed = log 
        ? Object.values(log.answers).filter(Boolean).length 
        : 0;
      
      // Consider a day complete if at least 50% is done
      if (completed >= FEMININITY_QUESTIONS.length / 2) {
        streak++;
      } else if (i > 0) {
        // Don't break on today if nothing done yet
        break;
      }
    }
    
    return streak;
  },
}));
