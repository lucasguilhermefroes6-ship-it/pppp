import { create } from 'zustand';

// ==================== TYPES ====================

export interface Folder {
  id: string;
  name: string;
  description?: string;
  colorHex: string;
  iconName: string;
  createdAt: string;
  updatedAt: string;
  sortOrder: number;
}

export interface ChecklistItem {
  text: string;
  done: boolean;
}

export type FolderItemType = 'NOTE' | 'LINK' | 'CHECKLIST';

export interface FolderItem {
  id: string;
  folderId: string;
  type: FolderItemType;
  title: string;
  content?: string; // NOTE: texto, LINK: url
  checklistItems?: ChecklistItem[]; // CHECKLIST
  pinned: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface FolderItemWithFolder extends FolderItem {
  folderName: string;
  folderColorHex: string;
  folderIconName: string;
}

// Sugestões de pastas
export const SUGGESTED_FOLDERS: Array<{ name: string; icon: string; color: string }> = [
  { name: 'Autocuidado', icon: 'Sparkles', color: '#E91E63' },
  { name: 'Rotina da Manhã', icon: 'Sun', color: '#FF9800' },
  { name: 'Rotina da Noite', icon: 'Moon', color: '#9C27B0' },
  { name: 'Estudos', icon: 'GraduationCap', color: '#2196F3' },
  { name: 'Trabalho', icon: 'Briefcase', color: '#607D8B' },
  { name: 'Casa & Organização', icon: 'Home', color: '#4CAF50' },
  { name: 'Receitas', icon: 'ChefHat', color: '#FF5722' },
  { name: 'Treino', icon: 'Dumbbell', color: '#F44336' },
  { name: 'Finanças', icon: 'Wallet', color: '#009688' },
  { name: 'Lista de Desejos', icon: 'Heart', color: '#E91E63' },
  { name: 'Viagens', icon: 'Plane', color: '#03A9F4' },
  { name: 'Leituras', icon: 'BookOpen', color: '#795548' },
];

// ==================== STORE ====================

interface FolderStore {
  folders: Folder[];
  items: FolderItem[];
  isLoading: boolean;
  showSuggestionsModal: boolean;
  
  // Folder CRUD
  loadFolders: () => Promise<void>;
  createFolder: (folder: Omit<Folder, 'id' | 'createdAt' | 'updatedAt' | 'sortOrder'>) => Promise<Folder>;
  updateFolder: (id: string, data: Partial<Folder>) => Promise<void>;
  deleteFolder: (id: string) => Promise<void>;
  
  // Item CRUD
  loadItems: (folderId?: string) => Promise<void>;
  createItem: (item: Omit<FolderItem, 'id' | 'createdAt' | 'updatedAt' | 'pinned'>) => Promise<FolderItem>;
  updateItem: (id: string, data: Partial<FolderItem>) => Promise<void>;
  deleteItem: (id: string) => Promise<void>;
  togglePinned: (id: string) => Promise<void>;
  
  // Queries
  getFolderById: (id: string) => Folder | undefined;
  getItemById: (id: string) => FolderItem | undefined;
  getItemsByFolder: (folderId: string, filterType?: FolderItemType) => FolderItem[];
  getPinnedItems: (limit?: number) => FolderItemWithFolder[];
  countFolders: () => number;
  countItems: (folderId?: string) => number;
  countPinnedItems: () => number;
  search: (query: string) => FolderItemWithFolder[];
  
  // Suggestions
  setShowSuggestionsModal: (show: boolean) => void;
  createSuggestedFolders: () => Promise<void>;
}

// IndexedDB helpers
const DB_NAME = 'bella-vida-db';
const DB_VERSION = 6;
const FOLDERS_STORE = 'folders';
const FOLDER_ITEMS_STORE = 'folder-items';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(FOLDERS_STORE)) {
        db.createObjectStore(FOLDERS_STORE, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(FOLDER_ITEMS_STORE)) {
        db.createObjectStore(FOLDER_ITEMS_STORE, { keyPath: 'id' });
      }
    };
  });
}

async function getAllFromStore<T>(storeName: string): Promise<T[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readonly');
    const store = transaction.objectStore(storeName);
    const request = store.getAll();
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result || []);
  });
}

async function putToStore<T>(storeName: string, item: T): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readwrite');
    const store = transaction.objectStore(storeName);
    const request = store.put(item);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve();
  });
}

async function deleteFromStore(storeName: string, id: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readwrite');
    const store = transaction.objectStore(storeName);
    const request = store.delete(id);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve();
  });
}

function generateId(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

export const useFolderStore = create<FolderStore>((set, get) => ({
  folders: [],
  items: [],
  isLoading: false,
  showSuggestionsModal: false,
  
  loadFolders: async () => {
    set({ isLoading: true });
    try {
      const folders = await getAllFromStore<Folder>(FOLDERS_STORE);
      const items = await getAllFromStore<FolderItem>(FOLDER_ITEMS_STORE);
      
      // Ordenar por sortOrder e updatedAt
      folders.sort((a, b) => a.sortOrder - b.sortOrder || 
        new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
      
      // Mostrar modal de sugestões se não houver pastas
      const showSuggestions = folders.length === 0;
      
      set({ folders, items, isLoading: false, showSuggestionsModal: showSuggestions });
    } catch (error) {
      console.error('Error loading folders:', error);
      set({ isLoading: false });
    }
  },
  
  createFolder: async (folderData) => {
    const now = new Date().toISOString();
    const folders = get().folders;
    const folder: Folder = {
      ...folderData,
      id: generateId(),
      createdAt: now,
      updatedAt: now,
      sortOrder: folders.length,
    };
    
    await putToStore(FOLDERS_STORE, folder);
    set({ folders: [...folders, folder] });
    return folder;
  },
  
  updateFolder: async (id, data) => {
    const folders = get().folders;
    const index = folders.findIndex(f => f.id === id);
    if (index === -1) return;
    
    const updated: Folder = {
      ...folders[index],
      ...data,
      updatedAt: new Date().toISOString(),
    };
    
    await putToStore(FOLDERS_STORE, updated);
    const newFolders = [...folders];
    newFolders[index] = updated;
    set({ folders: newFolders });
  },
  
  deleteFolder: async (id) => {
    // Deletar pasta e todos os itens
    await deleteFromStore(FOLDERS_STORE, id);
    
    const items = get().items.filter(item => item.folderId === id);
    for (const item of items) {
      await deleteFromStore(FOLDER_ITEMS_STORE, item.id);
    }
    
    set({ 
      folders: get().folders.filter(f => f.id !== id),
      items: get().items.filter(i => i.folderId !== id),
    });
  },
  
  loadItems: async (folderId?: string) => {
    try {
      const items = await getAllFromStore<FolderItem>(FOLDER_ITEMS_STORE);
      if (folderId) {
        set({ items: items.filter(i => i.folderId === folderId) });
      } else {
        set({ items });
      }
    } catch (error) {
      console.error('Error loading items:', error);
    }
  },
  
  createItem: async (itemData) => {
    const now = new Date().toISOString();
    const item: FolderItem = {
      ...itemData,
      id: generateId(),
      pinned: false,
      createdAt: now,
      updatedAt: now,
    };
    
    await putToStore(FOLDER_ITEMS_STORE, item);
    set({ items: [...get().items, item] });
    return item;
  },
  
  updateItem: async (id, data) => {
    const items = get().items;
    const index = items.findIndex(i => i.id === id);
    if (index === -1) return;
    
    const updated: FolderItem = {
      ...items[index],
      ...data,
      updatedAt: new Date().toISOString(),
    };
    
    await putToStore(FOLDER_ITEMS_STORE, updated);
    const newItems = [...items];
    newItems[index] = updated;
    set({ items: newItems });
  },
  
  deleteItem: async (id) => {
    await deleteFromStore(FOLDER_ITEMS_STORE, id);
    set({ items: get().items.filter(i => i.id !== id) });
  },
  
  togglePinned: async (id) => {
    const items = get().items;
    const item = items.find(i => i.id === id);
    if (!item) return;
    
    await get().updateItem(id, { pinned: !item.pinned });
  },
  
  getFolderById: (id) => get().folders.find(f => f.id === id),
  
  getItemById: (id) => get().items.find(i => i.id === id),
  
  getItemsByFolder: (folderId, filterType) => {
    let items = get().items.filter(i => i.folderId === folderId);
    if (filterType) {
      items = items.filter(i => i.type === filterType);
    }
    // Ordenar: pinned primeiro, depois por updatedAt
    return items.sort((a, b) => {
      if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
      return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
    });
  },
  
  getPinnedItems: (limit = 5) => {
    const items = get().items.filter(i => i.pinned);
    const folders = get().folders;
    
    return items
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
      .slice(0, limit)
      .map(item => {
        const folder = folders.find(f => f.id === item.folderId);
        return {
          ...item,
          folderName: folder?.name || '',
          folderColorHex: folder?.colorHex || '#E91E63',
          folderIconName: folder?.iconName || 'Folder',
        };
      });
  },
  
  countFolders: () => get().folders.length,
  
  countItems: (folderId) => {
    if (folderId) {
      return get().items.filter(i => i.folderId === folderId).length;
    }
    return get().items.length;
  },
  
  countPinnedItems: () => get().items.filter(i => i.pinned).length,
  
  search: (query) => {
    const q = query.toLowerCase().trim();
    if (!q) return [];
    
    const folders = get().folders;
    const items = get().items;
    const results: FolderItemWithFolder[] = [];
    
    // Buscar em pastas
    const matchingFolderIds = folders
      .filter(f => f.name.toLowerCase().includes(q))
      .map(f => f.id);
    
    // Buscar em itens
    for (const item of items) {
      const folder = folders.find(f => f.id === item.folderId);
      if (!folder) continue;
      
      let matches = false;
      
      // Título
      if (item.title.toLowerCase().includes(q)) matches = true;
      
      // Conteúdo (NOTE/LINK)
      if (item.content?.toLowerCase().includes(q)) matches = true;
      
      // Checklist
      if (item.checklistItems?.some(ci => ci.text.toLowerCase().includes(q))) matches = true;
      
      // Pasta
      if (matchingFolderIds.includes(item.folderId)) matches = true;
      
      if (matches) {
        results.push({
          ...item,
          folderName: folder.name,
          folderColorHex: folder.colorHex,
          folderIconName: folder.iconName,
        });
      }
    }
    
    // Ordenar: pinned primeiro
    return results.sort((a, b) => {
      if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
      return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
    });
  },
  
  setShowSuggestionsModal: (show) => set({ showSuggestionsModal: show }),
  
  createSuggestedFolders: async () => {
    const { createFolder } = get();
    
    for (const suggestion of SUGGESTED_FOLDERS) {
      await createFolder({
        name: suggestion.name,
        colorHex: suggestion.color,
        iconName: suggestion.icon,
      });
    }
    
    set({ showSuggestionsModal: false });
  },
}));
