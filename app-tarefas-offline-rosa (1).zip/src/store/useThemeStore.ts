import { create } from 'zustand';

// ============================================
// THEME STORE
// ============================================

export type ThemeMode = 'light' | 'dark';

interface ThemeState {
  mode: ThemeMode;
  isInitialized: boolean;
}

interface ThemeActions {
  toggleTheme: () => void;
  setTheme: (mode: ThemeMode) => void;
  initialize: () => void;
}

type ThemeStore = ThemeState & ThemeActions;

const STORAGE_KEY = 'theme-mode';

export const useThemeStore = create<ThemeStore>((set, get) => ({
  mode: 'light',
  isInitialized: false,

  initialize: () => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved === 'dark' || saved === 'light') {
      set({ mode: saved, isInitialized: true });
      applyTheme(saved);
    } else {
      // Check system preference
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      const mode = prefersDark ? 'dark' : 'light';
      set({ mode, isInitialized: true });
      applyTheme(mode);
    }
  },

  toggleTheme: () => {
    const newMode = get().mode === 'light' ? 'dark' : 'light';
    localStorage.setItem(STORAGE_KEY, newMode);
    set({ mode: newMode });
    applyTheme(newMode);
  },

  setTheme: (mode: ThemeMode) => {
    localStorage.setItem(STORAGE_KEY, mode);
    set({ mode });
    applyTheme(mode);
  },
}));

// Apply theme to document
function applyTheme(mode: ThemeMode) {
  const root = document.documentElement;
  
  if (mode === 'dark') {
    root.classList.add('dark');
    root.style.setProperty('--bg-primary', '#1a1a2e');
    root.style.setProperty('--bg-secondary', '#16213e');
    root.style.setProperty('--bg-card', '#1f2937');
    root.style.setProperty('--text-primary', '#f8f8f8');
    root.style.setProperty('--text-secondary', '#a0a0a0');
    root.style.setProperty('--pink-primary', '#EC4899');
    root.style.setProperty('--pink-light', '#831843');
    root.style.setProperty('--pink-bg', '#1a1a2e');
  } else {
    root.classList.remove('dark');
    root.style.setProperty('--bg-primary', '#FFF5F8');
    root.style.setProperty('--bg-secondary', '#FFFFFF');
    root.style.setProperty('--bg-card', '#FFFFFF');
    root.style.setProperty('--text-primary', '#2B2B2B');
    root.style.setProperty('--text-secondary', '#7A7A7A');
    root.style.setProperty('--pink-primary', '#E91E63');
    root.style.setProperty('--pink-light', '#FCE4EC');
    root.style.setProperty('--pink-bg', '#FFF5F8');
  }
}
