import { create } from 'zustand';

export interface SleepEntry {
  id: string;
  date: string; // YYYY-MM-DD
  sleepTime: string; // HH:mm (hora de dormir)
  wakeTime: string; // HH:mm (hora de acordar)
  durationMinutes: number;
  quality: 'bad' | 'ok' | 'good' | 'great';
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

interface SleepState {
  entries: SleepEntry[];
  idealHours: number;
  isLoading: boolean;
  
  // Actions
  initialize: () => void;
  addSleep: (entry: Omit<SleepEntry, 'id' | 'durationMinutes' | 'createdAt' | 'updatedAt'>) => void;
  removeSleep: (id: string) => void;
  setIdealHours: (hours: number) => void;
  formatDuration: (minutes: number) => string;
  getLastNightSleep: () => SleepEntry | undefined;
  getWeekData: () => SleepEntry[];
  getAverageHours: () => { hours: number; minutes: number };
}

const STORAGE_KEY = 'vida-rosa-sleep-entries';
const SETTINGS_KEY = 'vida-rosa-sleep-settings';

const loadFromStorage = (): SleepEntry[] => {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    console.log('[SleepStore] Loading from localStorage:', STORAGE_KEY, data);
    const entries = data ? JSON.parse(data) : [];
    console.log('[SleepStore] Parsed entries:', entries);
    return entries;
  } catch (e) {
    console.error('[SleepStore] Error loading:', e);
    return [];
  }
};

const saveToStorage = (entries: SleepEntry[]) => {
  console.log('[SleepStore] Saving to localStorage:', STORAGE_KEY, entries);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
};

const loadSettings = (): { idealHours: number } => {
  try {
    const data = localStorage.getItem(SETTINGS_KEY);
    return data ? JSON.parse(data) : { idealHours: 8 };
  } catch {
    return { idealHours: 8 };
  }
};

const saveSettings = (settings: { idealHours: number }) => {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
};

const calculateDuration = (sleepTime: string, wakeTime: string): number => {
  const [sleepH, sleepM] = sleepTime.split(':').map(Number);
  const [wakeH, wakeM] = wakeTime.split(':').map(Number);
  
  let sleepMinutes = sleepH * 60 + sleepM;
  let wakeMinutes = wakeH * 60 + wakeM;
  
  // If wake time is earlier than sleep time, assume next day
  if (wakeMinutes <= sleepMinutes) {
    wakeMinutes += 24 * 60;
  }
  
  return wakeMinutes - sleepMinutes;
};

// Carregar dados ANTES de criar o store
const loadInitialData = () => {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    console.log('[SleepStore] Auto-loading from localStorage:', data);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    console.error('[SleepStore] Error auto-loading:', e);
    return [];
  }
};

const loadInitialSettings = () => {
  try {
    const data = localStorage.getItem(SETTINGS_KEY);
    return data ? JSON.parse(data) : { idealHours: 8 };
  } catch {
    return { idealHours: 8 };
  }
};

// Carregar dados na inicialização do módulo
const INITIAL_ENTRIES = loadInitialData();
const INITIAL_SETTINGS = loadInitialSettings();

export const useSleepStore = create<SleepState>((set, get) => ({
  entries: INITIAL_ENTRIES,
  idealHours: INITIAL_SETTINGS.idealHours,
  isLoading: false,
  
  initialize: () => {
    console.log('[SleepStore] Initializing...');
    const entries = loadFromStorage();
    const settings = loadSettings();
    console.log('[SleepStore] Loaded entries:', entries.length, 'entries');
    set({ entries, idealHours: settings.idealHours, isLoading: false });
  },
  
  addSleep: (entryData) => {
    const durationMinutes = calculateDuration(entryData.sleepTime, entryData.wakeTime);
    const now = new Date().toISOString();
    
    const entry: SleepEntry = {
      ...entryData,
      id: crypto.randomUUID(),
      durationMinutes,
      createdAt: now,
      updatedAt: now,
    };
    
    // Check if entry for this date already exists - update it
    const existingIndex = get().entries.findIndex(e => e.date === entry.date);
    let newEntries: SleepEntry[];
    
    if (existingIndex >= 0) {
      newEntries = [...get().entries];
      newEntries[existingIndex] = { 
        ...entry, 
        id: get().entries[existingIndex].id, 
        createdAt: get().entries[existingIndex].createdAt 
      };
    } else {
      newEntries = [...get().entries, entry];
    }
    
    // Sort by date descending
    newEntries.sort((a, b) => b.date.localeCompare(a.date));
    
    saveToStorage(newEntries);
    set({ entries: newEntries });
  },
  
  removeSleep: (id: string) => {
    const newEntries = get().entries.filter(e => e.id !== id);
    saveToStorage(newEntries);
    set({ entries: newEntries });
  },
  
  setIdealHours: (hours: number) => {
    saveSettings({ idealHours: hours });
    set({ idealHours: hours });
  },
  
  formatDuration: (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h${mins.toString().padStart(2, '0')}`;
  },
  
  getLastNightSleep: () => {
    const entries = get().entries;
    if (entries.length === 0) return undefined;
    // Already sorted by date descending
    return entries[0];
  },
  
  getWeekData: () => {
    const entries = get().entries;
    const weekEntries: SleepEntry[] = [];
    
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      const entry = entries.find(e => e.date === dateStr);
      if (entry) {
        weekEntries.push(entry);
      }
    }
    
    return weekEntries;
  },
  
  getAverageHours: () => {
    const weekData = get().getWeekData();
    if (weekData.length === 0) return { hours: 0, minutes: 0 };
    
    const totalMinutes = weekData.reduce((sum, e) => sum + e.durationMinutes, 0);
    const avgMinutes = Math.round(totalMinutes / weekData.length);
    
    return {
      hours: Math.floor(avgMinutes / 60),
      minutes: avgMinutes % 60,
    };
  },
}));
