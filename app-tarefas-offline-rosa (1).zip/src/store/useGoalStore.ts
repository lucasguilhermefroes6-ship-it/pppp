import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import { format, startOfWeek, endOfWeek, startOfMonth, endOfMonth, differenceInDays, parseISO, subDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Goal, GoalProgress, RenewalPeriod } from '@/types';

// ========== DATABASE HELPERS ==========
const DB_NAME = 'rosa-goals-db';
const DB_VERSION = 1;

let dbInstance: IDBDatabase | null = null;

const openDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    if (dbInstance) {
      resolve(dbInstance);
      return;
    }
    
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    
    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      dbInstance = request.result;
      resolve(dbInstance);
    };
    
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      
      if (!db.objectStoreNames.contains('goals')) {
        const goalsStore = db.createObjectStore('goals', { keyPath: 'id' });
        goalsStore.createIndex('isActive', 'isActive', { unique: false });
      }
      
      if (!db.objectStoreNames.contains('goalProgress')) {
        const progressStore = db.createObjectStore('goalProgress', { keyPath: 'id' });
        progressStore.createIndex('goalId', 'goalId', { unique: false });
        progressStore.createIndex('date', 'date', { unique: false });
        progressStore.createIndex('goalId_date', ['goalId', 'date'], { unique: true });
      }
    };
  });
};

// ========== PERIOD HELPERS ==========
export const getPeriodBounds = (date: Date, period: RenewalPeriod): { start: Date; end: Date; key: string } => {
  switch (period) {
    case 'DAILY':
      return {
        start: new Date(date.getFullYear(), date.getMonth(), date.getDate()),
        end: new Date(date.getFullYear(), date.getMonth(), date.getDate(), 23, 59, 59, 999),
        key: format(date, 'yyyy-MM-dd')
      };
    case 'WEEKLY':
      return {
        start: startOfWeek(date, { locale: ptBR }),
        end: endOfWeek(date, { locale: ptBR }),
        key: format(startOfWeek(date, { locale: ptBR }), "yyyy-'W'ww")
      };
    case 'MONTHLY':
      return {
        start: startOfMonth(date),
        end: endOfMonth(date),
        key: format(date, 'yyyy-MM')
      };
  }
};

// ========== STREAK CALCULATION ==========
const calculateStreak = (goal: Goal, progress: GoalProgress[], today: Date): { current: number; best: number } => {
  // Sort progress by date descending
  const completedProgress = progress
    .filter(p => p.completed && p.goalId === goal.id)
    .sort((a, b) => b.periodStart.localeCompare(a.periodStart));
  
  if (completedProgress.length === 0) {
    return { current: 0, best: 0 };
  }
  
  let currentStreak = 0;
  let bestStreak = 0;
  let tempStreak = 0;
  let lastDate: Date | null = null;
  
  // Check if today's period is completed
  const todayBounds = getPeriodBounds(today, goal.renewalPeriod);
  const todayProgress = completedProgress.find(p => p.date === todayBounds.key);
  
  if (todayProgress) {
    currentStreak = 1;
    lastDate = parseISO(todayProgress.periodStart);
  } else {
    // Check yesterday/last period
    const checkDate = goal.renewalPeriod === 'DAILY' 
      ? subDays(today, 1) 
      : goal.renewalPeriod === 'WEEKLY'
        ? subDays(today, 7)
        : subDays(today, 30);
    
    const prevBounds = getPeriodBounds(checkDate, goal.renewalPeriod);
    const prevProgress = completedProgress.find(p => p.date === prevBounds.key);
    
    if (prevProgress) {
      currentStreak = 1;
      lastDate = parseISO(prevProgress.periodStart);
    }
  }
  
  // Calculate consecutive streaks
  for (const prog of completedProgress) {
    const progDate = parseISO(prog.periodStart);
    
    if (!lastDate) {
      tempStreak = 1;
      lastDate = progDate;
    } else {
      const expectedDiff = goal.renewalPeriod === 'DAILY' ? 1 
        : goal.renewalPeriod === 'WEEKLY' ? 7 
        : 30;
      
      const actualDiff = Math.abs(differenceInDays(lastDate, progDate));
      
      if (actualDiff <= expectedDiff + 1) {
        tempStreak++;
        if (currentStreak > 0) {
          currentStreak = tempStreak;
        }
      } else {
        tempStreak = 1;
        currentStreak = 0;
      }
      
      lastDate = progDate;
    }
    
    bestStreak = Math.max(bestStreak, tempStreak);
  }
  
  return { current: currentStreak, best: Math.max(bestStreak, goal.bestStreak) };
};

// ========== STORE ==========
interface GoalState {
  goals: Goal[];
  progress: GoalProgress[];
  isLoading: boolean;
  
  // Actions
  initialize: () => Promise<void>;
  refreshData: () => Promise<void>;
  
  // Goal CRUD
  createGoal: (goal: Omit<Goal, 'id' | 'currentStreak' | 'bestStreak' | 'createdAt' | 'updatedAt'>) => Promise<Goal>;
  updateGoal: (goal: Goal) => Promise<Goal>;
  deleteGoal: (id: string) => Promise<void>;
  
  // Progress Actions
  incrementProgress: (goalId: string) => Promise<void>;
  decrementProgress: (goalId: string) => Promise<void>;
  
  // Helpers
  getGoalProgress: (goalId: string) => GoalProgress | undefined;
  getGoalWithStats: (goalId: string) => { goal: Goal; progress: GoalProgress | undefined; streak: { current: number; best: number }; percentage: number } | undefined;
  getActiveGoalsCount: () => number;
  getTodayCompletedCount: () => number;
}

export const useGoalStore = create<GoalState>((set, get) => ({
  goals: [],
  progress: [],
  isLoading: true,
  
  initialize: async () => {
    set({ isLoading: true });
    await openDB();
    await get().refreshData();
    set({ isLoading: false });
  },
  
  refreshData: async () => {
    const db = await openDB();
    
    // Get all goals
    const goalsPromise = new Promise<Goal[]>((resolve, reject) => {
      const transaction = db.transaction('goals', 'readonly');
      const store = transaction.objectStore('goals');
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    
    // Get all progress
    const progressPromise = new Promise<GoalProgress[]>((resolve, reject) => {
      const transaction = db.transaction('goalProgress', 'readonly');
      const store = transaction.objectStore('goalProgress');
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    
    const [goals, progress] = await Promise.all([goalsPromise, progressPromise]);
    
    set({ goals, progress });
  },
  
  createGoal: async (goalData) => {
    const db = await openDB();
    const now = new Date().toISOString();
    
    const goal: Goal = {
      ...goalData,
      id: uuidv4(),
      currentStreak: 0,
      bestStreak: 0,
      createdAt: now,
      updatedAt: now
    };
    
    await new Promise<void>((resolve, reject) => {
      const transaction = db.transaction('goals', 'readwrite');
      const store = transaction.objectStore('goals');
      const request = store.add(goal);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
    
    await get().refreshData();
    return goal;
  },
  
  updateGoal: async (goal) => {
    const db = await openDB();
    const updated = { ...goal, updatedAt: new Date().toISOString() };
    
    await new Promise<void>((resolve, reject) => {
      const transaction = db.transaction('goals', 'readwrite');
      const store = transaction.objectStore('goals');
      const request = store.put(updated);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
    
    await get().refreshData();
    return updated;
  },
  
  deleteGoal: async (id) => {
    const db = await openDB();
    
    // Delete goal
    await new Promise<void>((resolve, reject) => {
      const transaction = db.transaction('goals', 'readwrite');
      const store = transaction.objectStore('goals');
      const request = store.delete(id);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
    
    // Delete related progress
    const { progress } = get();
    const toDelete = progress.filter(p => p.goalId === id);
    
    for (const p of toDelete) {
      await new Promise<void>((resolve, reject) => {
        const transaction = db.transaction('goalProgress', 'readwrite');
        const store = transaction.objectStore('goalProgress');
        const request = store.delete(p.id);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    }
    
    await get().refreshData();
  },
  
  incrementProgress: async (goalId) => {
    const db = await openDB();
    const { goals, progress } = get();
    
    const goal = goals.find(g => g.id === goalId);
    if (!goal) return;
    
    const today = new Date();
    const bounds = getPeriodBounds(today, goal.renewalPeriod);
    
    // Find or create progress for this period
    let currentProgress = progress.find(p => p.goalId === goalId && p.date === bounds.key);
    
    if (currentProgress) {
      // Increment existing
      const newCount = currentProgress.count + 1;
      const completed = newCount >= goal.targetCount;
      
      const updated: GoalProgress = {
        ...currentProgress,
        count: newCount,
        completed,
        completedAt: completed ? new Date().toISOString() : undefined
      };
      
      await new Promise<void>((resolve, reject) => {
        const transaction = db.transaction('goalProgress', 'readwrite');
        const store = transaction.objectStore('goalProgress');
        const request = store.put(updated);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    } else {
      // Create new progress
      const newProgress: GoalProgress = {
        id: uuidv4(),
        goalId,
        date: bounds.key,
        periodStart: format(bounds.start, 'yyyy-MM-dd'),
        periodEnd: format(bounds.end, 'yyyy-MM-dd'),
        count: 1,
        completed: 1 >= goal.targetCount,
        completedAt: 1 >= goal.targetCount ? new Date().toISOString() : undefined
      };
      
      await new Promise<void>((resolve, reject) => {
        const transaction = db.transaction('goalProgress', 'readwrite');
        const store = transaction.objectStore('goalProgress');
        const request = store.add(newProgress);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    }
    
    // Update goal for objective type (accumulative)
    if (goal.type === 'OBJECTIVE') {
      const newTotalProgress = (goal.totalProgress || 0) + 1;
      await get().updateGoal({
        ...goal,
        totalProgress: newTotalProgress,
        lastCompletedDate: format(today, 'yyyy-MM-dd')
      });
    } else {
      // Update streak for habit
      await get().refreshData();
      const updatedProgress = get().progress;
      const streak = calculateStreak(goal, updatedProgress, today);
      
      await get().updateGoal({
        ...goal,
        currentStreak: streak.current,
        bestStreak: streak.best,
        lastCompletedDate: format(today, 'yyyy-MM-dd')
      });
    }
    
    await get().refreshData();
  },
  
  decrementProgress: async (goalId) => {
    const db = await openDB();
    const { goals, progress } = get();
    
    const goal = goals.find(g => g.id === goalId);
    if (!goal) return;
    
    const today = new Date();
    const bounds = getPeriodBounds(today, goal.renewalPeriod);
    
    const currentProgress = progress.find(p => p.goalId === goalId && p.date === bounds.key);
    
    if (currentProgress && currentProgress.count > 0) {
      const newCount = currentProgress.count - 1;
      
      const updated: GoalProgress = {
        ...currentProgress,
        count: newCount,
        completed: newCount >= goal.targetCount,
        completedAt: newCount >= goal.targetCount ? currentProgress.completedAt : undefined
      };
      
      await new Promise<void>((resolve, reject) => {
        const transaction = db.transaction('goalProgress', 'readwrite');
        const store = transaction.objectStore('goalProgress');
        const request = store.put(updated);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
      
      // Update goal for objective type
      if (goal.type === 'OBJECTIVE' && (goal.totalProgress || 0) > 0) {
        await get().updateGoal({
          ...goal,
          totalProgress: (goal.totalProgress || 0) - 1
        });
      }
    }
    
    await get().refreshData();
  },
  
  getGoalProgress: (goalId) => {
    const { goals, progress } = get();
    const goal = goals.find(g => g.id === goalId);
    if (!goal) return undefined;
    
    const today = new Date();
    const bounds = getPeriodBounds(today, goal.renewalPeriod);
    
    return progress.find(p => p.goalId === goalId && p.date === bounds.key);
  },
  
  getGoalWithStats: (goalId) => {
    const { goals, progress } = get();
    const goal = goals.find(g => g.id === goalId);
    if (!goal) return undefined;
    
    const today = new Date();
    const bounds = getPeriodBounds(today, goal.renewalPeriod);
    const currentProgress = progress.find(p => p.goalId === goalId && p.date === bounds.key);
    
    const streak = calculateStreak(goal, progress, today);
    
    let percentage = 0;
    if (goal.type === 'OBJECTIVE' && goal.totalTarget) {
      percentage = Math.min(100, ((goal.totalProgress || 0) / goal.totalTarget) * 100);
    } else {
      const count = currentProgress?.count || 0;
      percentage = Math.min(100, (count / goal.targetCount) * 100);
    }
    
    return {
      goal,
      progress: currentProgress,
      streak,
      percentage
    };
  },
  
  getActiveGoalsCount: () => {
    const { goals } = get();
    return goals.filter(g => g.isActive).length;
  },
  
  getTodayCompletedCount: () => {
    const { goals, progress } = get();
    const today = new Date();
    
    let count = 0;
    for (const goal of goals.filter(g => g.isActive)) {
      const bounds = getPeriodBounds(today, goal.renewalPeriod);
      const prog = progress.find(p => p.goalId === goal.id && p.date === bounds.key);
      if (prog?.completed) count++;
    }
    
    return count;
  }
}));
