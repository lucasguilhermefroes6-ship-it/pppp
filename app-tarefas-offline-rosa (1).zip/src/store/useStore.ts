import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import { format } from 'date-fns';
import {
  Task,
  Subtask,
  ListCategory,
  Tag,
  TaskOccurrence,
  TaskWithRelations,
  Priority,
  OccurrenceStatus,
  ViewMode,
  FilterType
} from '@/types';
import * as db from '@/services/database';
// Removido imports não usados: occursOnDate, parseRecurrenceRule

interface AppState {
  // Data
  tasks: Task[];
  subtasks: Subtask[];
  categories: ListCategory[];
  tags: Tag[];
  occurrences: Map<string, TaskOccurrence>;
  pendingCount: number;
  
  // UI State
  viewMode: ViewMode;
  activeFilter: FilterType;
  selectedDate: string;
  isLoading: boolean;
  
  // Actions
  initialize: () => Promise<void>;
  refreshData: () => Promise<void>;
  
  // Task actions
  createTask: (task: Omit<Task, 'id' | 'createdAt' | 'updatedAt'>, subtaskTitles: string[], tagIds: string[]) => Promise<Task>;
  updateTask: (task: Task, subtaskTitles: string[], tagIds: string[]) => Promise<Task>;
  deleteTask: (id: string) => Promise<void>;
  toggleTaskDone: (task: Task, date: string) => Promise<void>;
  
  // Subtask actions
  toggleSubtaskDone: (subtask: Subtask) => Promise<void>;
  
  // Tag actions
  createTag: (name: string, colorHex: string) => Promise<Tag>;
  
  // UI actions
  setViewMode: (mode: ViewMode) => void;
  setActiveFilter: (filter: FilterType) => void;
  setSelectedDate: (date: string) => void;
  
  // Helpers
  getTasksForDisplay: () => TaskWithRelations[];
  getTaskWithRelations: (taskId: string) => Promise<TaskWithRelations | null>;
}

export const useStore = create<AppState>((set, get) => ({
  tasks: [],
  subtasks: [],
  categories: [],
  tags: [],
  occurrences: new Map(),
  pendingCount: 0,
  viewMode: 'list',
  activeFilter: 'all',
  selectedDate: format(new Date(), 'yyyy-MM-dd'),
  isLoading: true,
  
  initialize: async () => {
    set({ isLoading: true });
    await get().refreshData();
    set({ isLoading: false });
  },
  
  refreshData: async () => {
    const [tasks, categories, tags] = await Promise.all([
      db.getAllTasks(),
      db.getAllCategories(),
      db.getAllTags()
    ]);
    
    // Load all subtasks
    const allSubtasks: Subtask[] = [];
    for (const task of tasks) {
      const subs = await db.getSubtasksByTaskId(task.id);
      allSubtasks.push(...subs);
    }
    
    // Load occurrences for selected date and today
    const today = format(new Date(), 'yyyy-MM-dd');
    const selectedDate = get().selectedDate;
    const dates = [today];
    if (selectedDate !== today) dates.push(selectedDate);
    
    const occMap = new Map<string, TaskOccurrence>();
    for (const date of dates) {
      const occs = await db.getOccurrencesByDate(date);
      for (const occ of occs) {
        occMap.set(`${occ.taskId}-${occ.occurrenceDate}`, occ);
      }
    }
    
    // IMPORTANTE: Carregar occurrences de TODAS as tarefas recorrentes
    // para verificar conclusão no ciclo atual (semana/mês)
    for (const task of tasks) {
      if (task.recurrenceEnabled) {
        // Carregar todas as occurrences desta tarefa recorrente
        const taskOccs = await db.getAllOccurrencesByTaskId(task.id);
        for (const occ of taskOccs) {
          occMap.set(`${occ.taskId}-${occ.occurrenceDate}`, occ);
        }
      } else {
        // Para tarefas não recorrentes, carregar pela data
        const date = task.dueDate || 'no-date';
        const occ = await db.getOccurrenceByTaskAndDate(task.id, date);
        if (occ) {
          occMap.set(`${occ.taskId}-${occ.occurrenceDate}`, occ);
        }
      }
    }
    
    const pendingCount = await db.getPendingTasksCount();
    
    set({
      tasks,
      subtasks: allSubtasks,
      categories,
      tags,
      occurrences: occMap,
      pendingCount
    });
  },
  
  createTask: async (taskData, subtaskTitles, tagIds) => {
    const now = new Date().toISOString();
    const task: Task = {
      ...taskData,
      id: uuidv4(),
      createdAt: now,
      updatedAt: now
    };
    
    await db.createTask(task);
    
    // Create subtasks
    for (let i = 0; i < subtaskTitles.length; i++) {
      const subtask: Subtask = {
        id: uuidv4(),
        taskId: task.id,
        title: subtaskTitles[i],
        done: false,
        sortOrder: i
      };
      await db.createSubtask(subtask);
    }
    
    // Create tags
    await db.setTaskTags(task.id, tagIds);
    
    await get().refreshData();
    return task;
  },
  
  updateTask: async (task, subtaskTitles, tagIds) => {
    const updated = await db.updateTask(task);
    
    // Delete existing subtasks
    const existingSubtasks = await db.getSubtasksByTaskId(task.id);
    for (const st of existingSubtasks) {
      await db.deleteSubtask(st.id);
    }
    
    // Create new subtasks
    for (let i = 0; i < subtaskTitles.length; i++) {
      const subtask: Subtask = {
        id: uuidv4(),
        taskId: task.id,
        title: subtaskTitles[i],
        done: false,
        sortOrder: i
      };
      await db.createSubtask(subtask);
    }
    
    // Update tags
    await db.setTaskTags(task.id, tagIds);
    
    await get().refreshData();
    return updated;
  },
  
  deleteTask: async (id) => {
    await db.deleteTask(id);
    await get().refreshData();
  },
  
  toggleTaskDone: async (task, date) => {
    if (!task.recurrenceEnabled) {
      // Non-recurrent task
      await db.toggleNonRecurrentTaskDone(task);
    } else {
      // Recurrent task - toggle occurrence for specific date
      const occurrence = await db.getOccurrenceByTaskAndDate(task.id, date);
      if (occurrence?.status === OccurrenceStatus.DONE) {
        await db.markOccurrencePending(task.id, date);
      } else {
        await db.markOccurrenceDone(task.id, date);
      }
    }
    await get().refreshData();
  },
  
  toggleSubtaskDone: async (subtask) => {
    const updated = { ...subtask, done: !subtask.done };
    await db.updateSubtask(updated);
    await get().refreshData();
  },
  
  createTag: async (name, colorHex) => {
    const tag: Tag = {
      id: uuidv4(),
      name,
      colorHex
    };
    await db.createTag(tag);
    await get().refreshData();
    return tag;
  },
  
  setViewMode: (mode) => set({ viewMode: mode }),
  setActiveFilter: (filter) => set({ activeFilter: filter }),
  setSelectedDate: async (date) => {
    set({ selectedDate: date });
    await get().refreshData();
  },
  
  getTasksForDisplay: () => {
    const { tasks, subtasks, occurrences, activeFilter } = get();
    const today = format(new Date(), 'yyyy-MM-dd');
    const todayDate = new Date();
    
    // ========== FUNÇÕES DE CICLO ==========
    
    // Obter início da semana (segunda-feira)
    const getWeekStart = (date: Date): Date => {
      const d = new Date(date);
      const day = d.getDay();
      const diff = d.getDate() - day + (day === 0 ? -6 : 1);
      d.setDate(diff);
      d.setHours(0, 0, 0, 0);
      return d;
    };
    
    // Obter fim da semana (domingo 23:59)
    const getWeekEnd = (date: Date): Date => {
      const start = getWeekStart(date);
      const end = new Date(start);
      end.setDate(end.getDate() + 6);
      end.setHours(23, 59, 59, 999);
      return end;
    };
    
    // Gerar chave do ciclo
    const getCycleKey = (type: string, date: Date): string => {
      if (type === 'WEEKLY') {
        const weekStart = getWeekStart(date);
        const year = weekStart.getFullYear();
        const startOfYear = new Date(year, 0, 1);
        const days = Math.floor((weekStart.getTime() - startOfYear.getTime()) / 86400000);
        const weekNum = Math.ceil((days + startOfYear.getDay() + 1) / 7);
        return `${year}-W${String(weekNum).padStart(2, '0')}`;
      } else if (type === 'MONTHLY') {
        return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      } else if (type === 'BIWEEKLY') {
        const biweek = date.getDate() <= 15 ? 1 : 2;
        return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-Q${biweek}`;
      }
      return '';
    };
    
    // Verificar se tarefa está no ciclo atual e calcular status
    const getRecurrenceStatus = (task: Task): { inCycle: boolean; status: 'pending' | 'overdue' | 'completed'; cycleKey: string } | null => {
      if (!task.recurrenceEnabled || !task.recurrenceRuleJson) return null;
      
      try {
        const rule = JSON.parse(task.recurrenceRuleJson);
        
        // TAREFAS DIÁRIAS - não usa sistema de ciclos, usa o sistema simples
        if (rule.type === 'DAILY') {
          return null; // Tarefas diárias usam lógica simples de occurrence
        }
        
        const cycleKey = getCycleKey(rule.type, todayDate);
        
        if (!cycleKey) return null;
        
        // Verificar se já foi concluída neste ciclo
        let isCompletedInCycle = false;
        occurrences.forEach((occ) => {
          if (occ.taskId === task.id && occ.status === OccurrenceStatus.DONE) {
            const occDate = new Date(occ.occurrenceDate);
            const occCycleKey = getCycleKey(rule.type, occDate);
            if (occCycleKey === cycleKey) {
              isCompletedInCycle = true;
            }
          }
        });
        
        if (isCompletedInCycle) {
          return { inCycle: true, status: 'completed', cycleKey };
        }
        
        // Calcular data alvo dentro do ciclo
        let targetDate: Date | null = null;
        
        if (rule.type === 'WEEKLY' && rule.weekdays && rule.weekdays.length > 0) {
          const dayMap: Record<string, number> = { 
            'SUN': 0, 'MON': 1, 'TUE': 2, 'WED': 3, 'THU': 4, 'FRI': 5, 'SAT': 6 
          };
          const targetDayNum = dayMap[rule.weekdays[0]] ?? 1;
          const weekStart = getWeekStart(todayDate);
          targetDate = new Date(weekStart);
          // Calcular qual dia da semana
          const daysToAdd = targetDayNum === 0 ? 6 : targetDayNum - 1;
          targetDate.setDate(weekStart.getDate() + daysToAdd);
        } else if (rule.type === 'MONTHLY') {
          const targetDay = rule.dayOfMonth || 1;
          targetDate = new Date(todayDate.getFullYear(), todayDate.getMonth(), targetDay);
        } else if (rule.type === 'BIWEEKLY') {
          const targetDay = rule.biweeklyDay || 1;
          const biweekStart = todayDate.getDate() <= 15 ? 1 : 16;
          targetDate = new Date(todayDate.getFullYear(), todayDate.getMonth(), biweekStart + targetDay - 1);
        }
        
        // Determinar se está atrasada
        const isOverdue = targetDate ? todayDate > targetDate : false;
        
        return { inCycle: true, status: isOverdue ? 'overdue' : 'pending', cycleKey };
        
      } catch (e) {
        console.error('Erro ao processar regra de recorrência:', e);
        return null;
      }
    };
    
    // ========== FIM FUNÇÕES DE CICLO ==========
    
    const result: TaskWithRelations[] = [];
    
    for (const task of tasks) {
      const taskSubtasks = subtasks.filter(st => st.taskId === task.id);
      const taskTags: Tag[] = []; // Would need to load from DB
      
      let shouldShow = false;
      let occurrenceForDisplay: TaskOccurrence | undefined;
      let cycleStatus: 'pending' | 'overdue' | 'completed' | undefined;
      
      if (!task.recurrenceEnabled) {
        // Non-recurrent task
        const occDate = task.dueDate || 'no-date';
        occurrenceForDisplay = occurrences.get(`${task.id}-${occDate}`);
        
        // Show based on filter
        if (activeFilter === 'today') {
          shouldShow = task.dueDate === today;
        } else if (activeFilter === 'pending') {
          shouldShow = occurrenceForDisplay?.status !== OccurrenceStatus.DONE;
        } else if (activeFilter === 'completed') {
          shouldShow = occurrenceForDisplay?.status === OccurrenceStatus.DONE;
        } else if (activeFilter === 'high') {
          shouldShow = task.priority === Priority.HIGH;
        } else if (activeFilter === 'medium') {
          shouldShow = task.priority === Priority.MEDIUM;
        } else if (activeFilter === 'low') {
          shouldShow = task.priority === Priority.LOW;
        } else {
          shouldShow = true; // 'all'
        }
      } else {
        // Recurrent task
        if (task.recurrenceRuleJson) {
          try {
            const rule = JSON.parse(task.recurrenceRuleJson);
            
            // TAREFAS DIÁRIAS - lógica simples
            if (rule.type === 'DAILY') {
              // Buscar occurrence de hoje
              occurrenceForDisplay = occurrences.get(`${task.id}-${today}`);
              const isDone = occurrenceForDisplay?.status === OccurrenceStatus.DONE;
              
              // Aplicar filtros
              if (activeFilter === 'today') {
                shouldShow = !isDone;
              } else if (activeFilter === 'pending') {
                shouldShow = !isDone;
              } else if (activeFilter === 'completed') {
                shouldShow = isDone;
              } else if (activeFilter === 'high') {
                shouldShow = task.priority === Priority.HIGH && !isDone;
              } else if (activeFilter === 'medium') {
                shouldShow = task.priority === Priority.MEDIUM && !isDone;
              } else if (activeFilter === 'low') {
                shouldShow = task.priority === Priority.LOW && !isDone;
              } else {
                shouldShow = true; // 'all'
              }
            } else {
              // TAREFAS SEMANAIS/MENSAIS/QUINZENAIS - lógica de ciclo
              const recurrenceInfo = getRecurrenceStatus(task);
              
              if (recurrenceInfo && recurrenceInfo.inCycle) {
                cycleStatus = recurrenceInfo.status;
                
                // Pegar ocorrência do ciclo atual (se existir)
                occurrences.forEach((occ) => {
                  if (occ.taskId === task.id) {
                    const occDate = new Date(occ.occurrenceDate);
                    try {
                      const occCycleKey = getCycleKey(rule.type, occDate);
                      if (occCycleKey === recurrenceInfo.cycleKey) {
                        occurrenceForDisplay = occ;
                      }
                    } catch (e) {}
                  }
                });
                
                // Aplicar filtros
                if (activeFilter === 'today') {
                  shouldShow = recurrenceInfo.status !== 'completed';
                } else if (activeFilter === 'pending') {
                  shouldShow = recurrenceInfo.status !== 'completed';
                } else if (activeFilter === 'completed') {
                  shouldShow = recurrenceInfo.status === 'completed';
                } else if (activeFilter === 'high') {
                  shouldShow = task.priority === Priority.HIGH && recurrenceInfo.status !== 'completed';
                } else if (activeFilter === 'medium') {
                  shouldShow = task.priority === Priority.MEDIUM && recurrenceInfo.status !== 'completed';
                } else if (activeFilter === 'low') {
                  shouldShow = task.priority === Priority.LOW && recurrenceInfo.status !== 'completed';
                } else {
                  shouldShow = true; // 'all'
                }
              }
            }
          } catch (e) {
            console.error('Erro ao processar regra:', e);
          }
        }
      }
      
      if (shouldShow) {
        result.push({
          ...task,
          subtasks: taskSubtasks,
          tags: taskTags,
          occurrence: occurrenceForDisplay,
          cycleStatus // Adicionar status do ciclo para exibição
        } as TaskWithRelations);
      }
    }
    
    // Remover variáveis não usadas
    void getWeekEnd;
    
    return result;
  },
  
  getTaskWithRelations: async (taskId) => {
    const task = await db.getTaskById(taskId);
    if (!task) return null;
    
    const subtasks = await db.getSubtasksByTaskId(taskId);
    const tags = await db.getTagsByTaskId(taskId);
    
    return {
      ...task,
      subtasks,
      tags
    };
  }
}));
