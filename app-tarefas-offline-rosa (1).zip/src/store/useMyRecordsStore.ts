import { create } from 'zustand';
import { DailyHealthRecord, MyRecordsGoals, WeeklyMyRecordsSummary, DailyHealthRecordWithStatus } from '../types';

// Usando localStorage para persistência mais confiável
const RECORDS_KEY = 'vida-rosa-my-records';
const GOALS_KEY = 'vida-rosa-my-records-goals';

// Helpers para datas
export const formatDateKey = (date: Date): string => {
  return date.toISOString().split('T')[0];
};

export const startOfWeek = (date: Date): Date => {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1); // Segunda-feira
  d.setDate(diff);
  d.setHours(0, 0, 0, 0);
  return d;
};

export const addDays = (date: Date, days: number): Date => {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
};

export const getDayName = (date: Date): string => {
  const days = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
  return days[date.getDay()];
};

// Calcular duração do jejum
export const computeFastingMinutes = (startHHmm: string, endHHmm: string): number | null => {
  if (!startHHmm || !endHHmm) return null;
  
  const [startH, startM] = startHHmm.split(':').map(Number);
  const [endH, endM] = endHHmm.split(':').map(Number);
  
  const startMinutes = startH * 60 + startM;
  const endMinutes = endH * 60 + endM;
  
  // Start é no dia atual, end é no dia seguinte
  const duration = (24 * 60 - startMinutes) + endMinutes;
  
  // Validação: entre 1 minuto e 23h59
  if (duration <= 0 || duration > 24 * 60 - 1) return null;
  
  return duration;
};

// Função RANGE: verifica se calorias estão dentro do intervalo
export const isInCaloriesRange = (calories: number, min: number, max: number): boolean => {
  return min <= calories && calories <= max;
};

// Função MIN: verifica se jejum atingiu o mínimo
export const isAboveFastingTarget = (durationMinutes: number, targetMinutes: number): boolean => {
  return durationMinutes >= targetMinutes;
};

// Decide se o dia bateu a meta de calorias
export const checkCaloriesGoal = (
  caloriesKcal: number | null | undefined,
  minKcal: number | null | undefined,
  maxKcal: number | null | undefined
): boolean | null => {
  if (caloriesKcal === null || caloriesKcal === undefined) return null;
  if (minKcal === null || minKcal === undefined || maxKcal === null || maxKcal === undefined) return null;
  return isInCaloriesRange(caloriesKcal, minKcal, maxKcal);
};

// Decide se o dia bateu a meta de jejum
export const checkFastingGoal = (
  durationMinutes: number | null | undefined,
  targetMinutes: number | null | undefined
): boolean | null => {
  if (durationMinutes === null || durationMinutes === undefined) return null;
  if (targetMinutes === null || targetMinutes === undefined) return null;
  return isAboveFastingTarget(durationMinutes, targetMinutes);
};

// Formatar minutos para "14h30"
export const formatMinutesToHhMm = (minutes: number | null | undefined): string => {
  if (minutes === null || minutes === undefined) return '—';
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${h}h${m.toString().padStart(2, '0')}`;
};

// Load/Save helpers
const loadRecords = (): DailyHealthRecord[] => {
  try {
    const data = localStorage.getItem(RECORDS_KEY);
    console.log('[MyRecords] Loading records:', data);
    const records = data ? JSON.parse(data) : [];
    console.log('[MyRecords] Parsed records:', records);
    return records;
  } catch (e) {
    console.error('[MyRecords] Error loading records:', e);
    return [];
  }
};

const saveRecords = (records: DailyHealthRecord[]) => {
  console.log('[MyRecords] Saving records:', records);
  localStorage.setItem(RECORDS_KEY, JSON.stringify(records));
  console.log('[MyRecords] Records saved successfully');
};

const loadGoals = (): MyRecordsGoals | null => {
  try {
    const data = localStorage.getItem(GOALS_KEY);
    return data ? JSON.parse(data) : null;
  } catch {
    return null;
  }
};

const saveGoalsToStorage = (goals: MyRecordsGoals) => {
  localStorage.setItem(GOALS_KEY, JSON.stringify(goals));
};

interface MyRecordsState {
  records: DailyHealthRecord[];
  goals: MyRecordsGoals | null;
  isLoading: boolean;
  
  initDB: () => Promise<void>;
  getRecord: (dateKey: string) => DailyHealthRecord | undefined;
  upsertRecord: (record: Omit<DailyHealthRecord, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => Promise<void>;
  deleteRecord: (id: string) => Promise<void>;
  getGoals: () => MyRecordsGoals | null;
  saveGoals: (goals: Partial<MyRecordsGoals>) => Promise<void>;
  getWeeklySummary: (weekStart: Date) => WeeklyMyRecordsSummary;
  getTodayLabel: () => string;
}

export const useMyRecordsStore = create<MyRecordsState>((set, get) => ({
  records: [],
  goals: null,
  isLoading: true,
  
  initDB: async () => {
    const records = loadRecords();
    const goals = loadGoals();
    set({ records, goals, isLoading: false });
  },
  
  getRecord: (dateKey: string) => {
    return get().records.find(r => r.dateKey === dateKey);
  },
  
  upsertRecord: async (recordData) => {
    console.log('[MyRecords] upsertRecord called with:', recordData);
    const now = new Date().toISOString();
    const existingRecord = get().records.find(r => r.dateKey === recordData.dateKey);
    console.log('[MyRecords] Existing record:', existingRecord);
    
    // Calcular duração do jejum
    let fastingDurationMinutes: number | undefined;
    if (recordData.fastingStartTime && recordData.fastingEndTime) {
      const duration = computeFastingMinutes(recordData.fastingStartTime, recordData.fastingEndTime);
      if (duration !== null) {
        fastingDurationMinutes = duration;
      }
    }
    
    const record: DailyHealthRecord = {
      id: existingRecord?.id || recordData.id || crypto.randomUUID(),
      dateKey: recordData.dateKey,
      caloriesKcal: recordData.caloriesKcal,
      fastingStartTime: recordData.fastingStartTime,
      fastingEndTime: recordData.fastingEndTime,
      fastingDurationMinutes,
      note: recordData.note,
      createdAt: existingRecord?.createdAt || now,
      updatedAt: now,
    };
    
    // Update local state
    const newRecords = existingRecord 
      ? get().records.map(r => r.id === record.id ? record : r)
      : [...get().records, record];
    
    saveRecords(newRecords);
    set({ records: newRecords });
  },
  
  deleteRecord: async (id: string) => {
    const newRecords = get().records.filter(r => r.id !== id);
    saveRecords(newRecords);
    set({ records: newRecords });
  },
  
  getGoals: () => get().goals,
  
  saveGoals: async (goalsData) => {
    const now = new Date().toISOString();
    const existingGoals = get().goals;
    
    const goals: MyRecordsGoals = {
      id: 'default',
      calorieMinKcal: goalsData.calorieMinKcal ?? existingGoals?.calorieMinKcal,
      calorieMaxKcal: goalsData.calorieMaxKcal ?? existingGoals?.calorieMaxKcal,
      fastingTargetMinutes: goalsData.fastingTargetMinutes ?? existingGoals?.fastingTargetMinutes,
      createdAt: existingGoals?.createdAt || now,
      updatedAt: now,
    };
    
    saveGoalsToStorage(goals);
    set({ goals });
  },
  
  getWeeklySummary: (weekStart: Date) => {
    const { records, goals } = get();
    const dailyRecords: DailyHealthRecordWithStatus[] = [];
    
    let totalCalories = 0;
    let caloriesDays = 0;
    let totalFasting = 0;
    let fastingDays = 0;
    let daysCaloriesHitGoal = 0;
    let daysFastingHitGoal = 0;
    
    for (let i = 0; i < 7; i++) {
      const date = addDays(weekStart, i);
      const dateKey = formatDateKey(date);
      const dayName = getDayName(date);
      const record = records.find(r => r.dateKey === dateKey) || null;
      
      // Check calories goal
      const caloriesHitGoal = checkCaloriesGoal(
        record?.caloriesKcal,
        goals?.calorieMinKcal,
        goals?.calorieMaxKcal
      );
      if (caloriesHitGoal === true) daysCaloriesHitGoal++;
      
      // Check fasting goal
      const fastingHitGoal = checkFastingGoal(
        record?.fastingDurationMinutes,
        goals?.fastingTargetMinutes
      );
      if (fastingHitGoal === true) daysFastingHitGoal++;
      
      // Sum for averages
      if (record?.caloriesKcal !== undefined && record?.caloriesKcal !== null) {
        totalCalories += record.caloriesKcal;
        caloriesDays++;
      }
      if (record?.fastingDurationMinutes !== undefined && record?.fastingDurationMinutes !== null) {
        totalFasting += record.fastingDurationMinutes;
        fastingDays++;
      }
      
      dailyRecords.push({
        date: dateKey,
        dayName,
        record,
        caloriesHitGoal,
        fastingHitGoal,
      });
    }
    
    return {
      avgCalories: caloriesDays > 0 ? Math.round(totalCalories / caloriesDays) : null,
      avgFastingMinutes: fastingDays > 0 ? Math.round(totalFasting / fastingDays) : null,
      daysCaloriesHitGoal,
      daysCaloriesWithData: caloriesDays,
      daysFastingHitGoal,
      daysFastingWithData: fastingDays,
      dailyRecords,
    };
  },
  
  getTodayLabel: () => {
    const today = formatDateKey(new Date());
    const record = get().records.find(r => r.dateKey === today);
    
    if (record?.caloriesKcal !== undefined) {
      return `${record.caloriesKcal} kcal`;
    }
    if (record?.fastingDurationMinutes !== undefined) {
      return `Jejum: ${formatMinutesToHhMm(record.fastingDurationMinutes)}`;
    }
    return '—';
  },
}));
