import { create } from 'zustand';
import { NotepadNote } from '../types';

const STORAGE_KEY = 'vida-rosa-notepad';

interface NotepadState {
  notes: NotepadNote[];
  isLoading: boolean;
  searchQuery: string;
  
  // Actions
  loadNotes: () => void;
  createNote: (note: Omit<NotepadNote, 'id' | 'createdAt' | 'updatedAt'>) => NotepadNote;
  updateNote: (id: string, updates: Partial<NotepadNote>) => void;
  deleteNote: (id: string) => void;
  togglePinned: (id: string) => void;
  setSearchQuery: (query: string) => void;
  countNotes: () => number;
  
  // Filtered
  getFilteredNotes: () => NotepadNote[];
}

const loadFromStorage = (): NotepadNote[] => {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
};

const saveToStorage = (notes: NotepadNote[]) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
};

const generateId = () => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

const sortNotes = (notes: NotepadNote[]): NotepadNote[] => {
  return [...notes].sort((a, b) => {
    if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
    return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
  });
};

export const useNotepadStore = create<NotepadState>((set, get) => ({
  notes: [],
  isLoading: false,
  searchQuery: '',

  loadNotes: () => {
    const notes = loadFromStorage();
    set({ notes: sortNotes(notes), isLoading: false });
  },

  createNote: (noteData) => {
    const now = new Date().toISOString();
    const note: NotepadNote = {
      id: generateId(),
      ...noteData,
      pinned: noteData.pinned ?? false,
      createdAt: now,
      updatedAt: now,
    };

    const newNotes = sortNotes([...get().notes, note]);
    saveToStorage(newNotes);
    set({ notes: newNotes });
    return note;
  },

  updateNote: (id, updates) => {
    const notes = get().notes;
    const noteIndex = notes.findIndex(n => n.id === id);
    if (noteIndex === -1) return;

    const updatedNote: NotepadNote = {
      ...notes[noteIndex],
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    const newNotes = [...notes];
    newNotes[noteIndex] = updatedNote;
    const sortedNotes = sortNotes(newNotes);
    
    saveToStorage(sortedNotes);
    set({ notes: sortedNotes });
  },

  deleteNote: (id) => {
    const newNotes = get().notes.filter(n => n.id !== id);
    saveToStorage(newNotes);
    set({ notes: newNotes });
  },

  togglePinned: (id) => {
    const notes = get().notes;
    const note = notes.find(n => n.id === id);
    if (!note) return;

    get().updateNote(id, { pinned: !note.pinned });
  },

  setSearchQuery: (query) => {
    set({ searchQuery: query });
  },

  countNotes: () => {
    return get().notes.length;
  },

  getFilteredNotes: () => {
    const { notes, searchQuery } = get();
    if (!searchQuery.trim()) return notes;

    const query = searchQuery.toLowerCase();
    return notes.filter(note => 
      note.title.toLowerCase().includes(query) ||
      note.content.toLowerCase().includes(query)
    );
  },
}));
