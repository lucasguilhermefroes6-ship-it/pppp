import { create } from 'zustand';
import { MeasurementEntry, MeasurementField, MeasurementPeriod, DeltaStyle, DECREASE_IS_GOOD_FIELDS, INCREASE_IS_GOOD_FIELDS } from '../types';

const DB_NAME = 'rosa-app-db';
const STORE_NAME = 'measurements';

// IndexedDB helpers
const openDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 5);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
  });
};

const getAllFromStore = async <T>(storeName: string): Promise<T[]> => {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readonly');
    const store = transaction.objectStore(storeName);
    const request = store.getAll();
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
  });
};

const putInStore = async <T>(storeName: string, item: T): Promise<void> => {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readwrite');
    const store = transaction.objectStore(storeName);
    const request = store.put(item);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve();
  });
};

const deleteFromStore = async (storeName: string, id: string): Promise<void> => {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, 'readwrite');
    const store = transaction.objectStore(storeName);
    const request = store.delete(id);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve();
  });
};

// Field labels and units - ATUALIZADO com Coxa
// Cores rosa/lilás harmoniosas (sem vermelho)
export const MEASUREMENT_FIELDS: { key: MeasurementField; label: string; unit: string; icon: string; color: string }[] = [
  { key: 'weightKg', label: 'Peso', unit: 'kg', icon: 'scale', color: '#E84393' },      // Rosa magenta (não vermelho)
  { key: 'waistCm', label: 'Cintura', unit: 'cm', icon: 'ruler', color: '#9B59B6' },    // Roxo/Lilás
  { key: 'bustCm', label: 'Busto', unit: 'cm', icon: 'heart', color: '#FD79A8' },       // Rosa suave
  { key: 'armCm', label: 'Braço', unit: 'cm', icon: 'arm', color: '#E17055' },          // Coral
  { key: 'hipCm', label: 'Quadril', unit: 'cm', icon: 'sparkle', color: '#A29BFE' },    // Lilás claro
  { key: 'thighCm', label: 'Coxa', unit: 'cm', icon: 'leg', color: '#74B9FF' },         // Azul suave
];

// Helper para calcular o estilo do delta
export const getDeltaStyle = (field: MeasurementField, current: number | undefined, previous: number | undefined): DeltaStyle | null => {
  if (current === undefined || previous === undefined) return null;
  
  const delta = current - previous;
  if (delta === 0) {
    return {
      color: '#9E9E9E', // cinza
      icon: '→',
      text: '0',
      isGood: true, // neutro
    };
  }
  
  const isDecreaseGood = DECREASE_IS_GOOD_FIELDS.includes(field);
  const isIncreaseGood = INCREASE_IS_GOOD_FIELDS.includes(field);
  
  let isGood = false;
  
  if (delta < 0) {
    // Diminuiu
    isGood = isDecreaseGood;
  } else {
    // Aumentou
    isGood = isIncreaseGood;
  }
  
  const fieldInfo = MEASUREMENT_FIELDS.find(f => f.key === field);
  
  return {
    color: isGood ? '#4CAF50' : '#BE185D', // verde ou rosa escuro
    icon: delta > 0 ? '↑' : '↓',
    text: `${Math.abs(delta).toFixed(1)} ${fieldInfo?.unit || ''}`,
    isGood,
  };
};

// Helper para calcular "falta para a meta"
export const getGoalProgress = (
  field: MeasurementField,
  current: number | undefined,
  target: number | undefined
): { falta: number; atingida: boolean; text: string } | null => {
  if (current === undefined || target === undefined) return null;
  
  const isDecreaseGood = DECREASE_IS_GOOD_FIELDS.includes(field);
  const fieldInfo = MEASUREMENT_FIELDS.find(f => f.key === field);
  const unit = fieldInfo?.unit || '';
  
  if (isDecreaseGood) {
    // Para Peso/Cintura/Braço/Busto/Coxa - precisa diminuir
    if (current <= target) {
      return { falta: 0, atingida: true, text: '✅ Meta atingida!' };
    }
    const falta = current - target;
    return { falta, atingida: false, text: `Falta: ${falta.toFixed(1)} ${unit}` };
  } else {
    // Para Quadril - precisa aumentar
    if (current >= target) {
      return { falta: 0, atingida: true, text: '✅ Meta atingida!' };
    }
    const falta = target - current;
    return { falta, atingida: false, text: `Falta: ${falta.toFixed(1)} ${unit}` };
  }
};

interface MeasurementsState {
  entries: MeasurementEntry[];
  isLoading: boolean;
  
  // Actions
  loadEntries: () => Promise<void>;
  addEntry: (entry: Omit<MeasurementEntry, 'id' | 'createdAt' | 'updatedAt'>) => Promise<void>;
  updateEntry: (id: string, updates: Partial<MeasurementEntry>) => Promise<void>;
  deleteEntry: (id: string) => Promise<void>;
  getEntryByDate: (dateKey: string) => MeasurementEntry | undefined;
  getEntryById: (id: string) => MeasurementEntry | undefined;
  
  // Queries
  getLatestEntry: () => MeasurementEntry | undefined;
  getPreviousEntry: () => MeasurementEntry | undefined;
  getEntriesInRange: (startDate: string, endDate: string) => MeasurementEntry[];
  getSeriesForField: (field: MeasurementField, period: MeasurementPeriod) => { date: string; value: number }[];
  getHomeLabel: () => string;
  
  // Export/Import
  exportData: () => string;
  importData: (jsonString: string) => Promise<{ success: boolean; message: string }>;
}

export const useMeasurementsStore = create<MeasurementsState>((set, get) => ({
  entries: [],
  isLoading: false,
  
  loadEntries: async () => {
    set({ isLoading: true });
    try {
      const entries = await getAllFromStore<MeasurementEntry>(STORE_NAME);
      // Sort by date descending
      entries.sort((a, b) => b.dateKey.localeCompare(a.dateKey));
      set({ entries, isLoading: false });
    } catch (error) {
      console.error('Error loading measurements:', error);
      set({ isLoading: false });
    }
  },
  
  addEntry: async (entryData) => {
    const now = new Date().toISOString();
    const entry: MeasurementEntry = {
      ...entryData,
      id: crypto.randomUUID(),
      createdAt: now,
      updatedAt: now,
    };
    
    await putInStore(STORE_NAME, entry);
    
    const entries = [...get().entries, entry];
    entries.sort((a, b) => b.dateKey.localeCompare(a.dateKey));
    set({ entries });
  },
  
  updateEntry: async (id, updates) => {
    const entry = get().entries.find(e => e.id === id);
    if (!entry) return;
    
    const updatedEntry: MeasurementEntry = {
      ...entry,
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    
    await putInStore(STORE_NAME, updatedEntry);
    
    const entries = get().entries.map(e => e.id === id ? updatedEntry : e);
    entries.sort((a, b) => b.dateKey.localeCompare(a.dateKey));
    set({ entries });
  },
  
  deleteEntry: async (id) => {
    await deleteFromStore(STORE_NAME, id);
    set({ entries: get().entries.filter(e => e.id !== id) });
  },
  
  getEntryByDate: (dateKey) => {
    return get().entries.find(e => e.dateKey === dateKey);
  },
  
  getEntryById: (id) => {
    return get().entries.find(e => e.id === id);
  },
  
  getLatestEntry: () => {
    const entries = get().entries;
    return entries.length > 0 ? entries[0] : undefined;
  },
  
  getPreviousEntry: () => {
    const entries = get().entries;
    return entries.length > 1 ? entries[1] : undefined;
  },
  
  getEntriesInRange: (startDate, endDate) => {
    return get().entries.filter(e => 
      e.dateKey >= startDate && e.dateKey <= endDate
    );
  },
  
  getSeriesForField: (field, period) => {
    const entries = get().entries;
    const now = new Date();
    let startDate: Date;
    
    switch (period) {
      case '30days':
        startDate = new Date(now);
        startDate.setDate(startDate.getDate() - 30);
        break;
      case '3months':
        startDate = new Date(now);
        startDate.setMonth(startDate.getMonth() - 3);
        break;
      case '6months':
        startDate = new Date(now);
        startDate.setMonth(startDate.getMonth() - 6);
        break;
      case '1year':
        startDate = new Date(now);
        startDate.setFullYear(startDate.getFullYear() - 1);
        break;
      case 'all':
      default:
        startDate = new Date(2000, 0, 1); // Very old date
        break;
    }
    
    const startDateKey = startDate.toISOString().split('T')[0];
    
    return entries
      .filter(e => e.dateKey >= startDateKey && e[field] !== undefined && e[field] !== null)
      .map(e => ({
        date: e.dateKey,
        value: e[field] as number,
      }))
      .sort((a, b) => a.date.localeCompare(b.date));
  },
  
  getHomeLabel: () => {
    const latest = get().getLatestEntry();
    if (latest?.weightKg) {
      return `Último: ${latest.weightKg.toFixed(1)} kg`;
    }
    return 'Acompanhamento';
  },
  
  exportData: () => {
    const entries = get().entries;
    return JSON.stringify({ entries, exportedAt: new Date().toISOString() }, null, 2);
  },
  
  importData: async (jsonString: string) => {
    try {
      const data = JSON.parse(jsonString);
      const importedEntries = data.entries as MeasurementEntry[];
      
      if (!Array.isArray(importedEntries)) {
        return { success: false, message: 'Formato inválido' };
      }
      
      let imported = 0;
      for (const entry of importedEntries) {
        // Garantir compatibilidade com backups antigos (sem thighCm)
        const normalizedEntry: MeasurementEntry = {
          id: entry.id || crypto.randomUUID(),
          dateKey: entry.dateKey,
          weightKg: entry.weightKg,
          waistCm: entry.waistCm,
          bustCm: entry.bustCm,
          armCm: entry.armCm,
          hipCm: entry.hipCm,
          thighCm: entry.thighCm, // Pode ser undefined em backups antigos
          note: entry.note,
          createdAt: entry.createdAt || new Date().toISOString(),
          updatedAt: entry.updatedAt || new Date().toISOString(),
        };
        
        await putInStore(STORE_NAME, normalizedEntry);
        imported++;
      }
      
      await get().loadEntries();
      return { success: true, message: `${imported} registro(s) importado(s)` };
    } catch (error) {
      return { success: false, message: 'Erro ao importar dados' };
    }
  },
}));
