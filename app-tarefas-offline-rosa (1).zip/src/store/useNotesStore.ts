import { create } from 'zustand';

// Types
export interface Note {
  id: string;
  title: string;
  content: string;
  category: NoteCategory;
  tags: string[];
  colorHex: string;
  createdAt: string;
  updatedAt: string;
}

export type NoteCategory = 'Estudo' | 'Trabalho' | 'Pessoal' | 'Ideias' | 'Tarefas' | 'Reuniões';

export const NOTE_CATEGORIES: NoteCategory[] = [
  'Estudo',
  'Trabalho', 
  'Pessoal',
  'Ideias',
  'Tarefas',
  'Reuniões'
];

export const NOTE_COLORS = [
  '#E91E63', // Pink (default)
  '#2196F3', // Blue
  '#F44336', // Red
  '#4CAF50', // Green
  '#9C27B0', // Purple
  '#FF9800', // Orange
  '#009688', // Teal
  '#FFEB3B', // Yellow
  '#FF5722', // Deep Orange
  '#795548', // Brown
];

export const CATEGORY_ICONS: Record<NoteCategory, string> = {
  'Estudo': '📚',
  'Trabalho': '💼',
  'Pessoal': '💕',
  'Ideias': '💡',
  'Tarefas': '✅',
  'Reuniões': '👥'
};

// Database
const DB_NAME = 'vida-rosa-notes-db';
const STORE_NAME = 'notes';

const openDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        store.createIndex('category', 'category', { unique: false });
        store.createIndex('createdAt', 'createdAt', { unique: false });
      }
    };
  });
};

// Helper to get relative time
export function getRelativeTime(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffSecs = Math.floor(diffMs / 1000);
  const diffMins = Math.floor(diffSecs / 60);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffSecs < 60) return 'Agora';
  if (diffMins < 60) return `${diffMins} min`;
  if (diffHours < 24) return `${diffHours}h`;
  if (diffDays === 1) return 'Ontem';
  if (diffDays < 7) return `${diffDays} dias`;
  if (diffDays < 30) return `${Math.floor(diffDays / 7)} sem`;
  return `${Math.floor(diffDays / 30)} mês`;
}

interface NotesStore {
  notes: Note[];
  isLoading: boolean;
  searchQuery: string;
  
  // Actions
  initialize: () => Promise<void>;
  addNote: (note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'>) => Promise<void>;
  updateNote: (id: string, updates: Partial<Note>) => Promise<void>;
  deleteNote: (id: string) => Promise<void>;
  getNoteById: (id: string) => Note | undefined;
  setSearchQuery: (query: string) => void;
  getFilteredNotes: () => Note[];
  countNotes: () => number;
}

export const useNotesStore = create<NotesStore>((set, get) => ({
  notes: [],
  isLoading: true,
  searchQuery: '',

  initialize: async () => {
    try {
      const db = await openDB();
      const transaction = db.transaction(STORE_NAME, 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.getAll();

      request.onsuccess = () => {
        const notes = request.result as Note[];
        // Sort by updatedAt descending
        notes.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
        set({ notes, isLoading: false });
      };
      request.onerror = () => {
        set({ isLoading: false });
      };
    } catch (error) {
      console.error('Error initializing notes:', error);
      set({ isLoading: false });
    }
  },

  addNote: async (noteData) => {
    const note: Note = {
      ...noteData,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    try {
      const db = await openDB();
      const transaction = db.transaction(STORE_NAME, 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      store.add(note);

      set((state) => ({
        notes: [note, ...state.notes],
      }));
    } catch (error) {
      console.error('Error adding note:', error);
    }
  },

  updateNote: async (id, updates) => {
    const { notes } = get();
    const noteIndex = notes.findIndex((n) => n.id === id);
    if (noteIndex === -1) return;

    const updatedNote: Note = {
      ...notes[noteIndex],
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    try {
      const db = await openDB();
      const transaction = db.transaction(STORE_NAME, 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      store.put(updatedNote);

      const newNotes = [...notes];
      newNotes[noteIndex] = updatedNote;
      // Re-sort by updatedAt
      newNotes.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
      set({ notes: newNotes });
    } catch (error) {
      console.error('Error updating note:', error);
    }
  },

  deleteNote: async (id) => {
    try {
      const db = await openDB();
      const transaction = db.transaction(STORE_NAME, 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      store.delete(id);

      set((state) => ({
        notes: state.notes.filter((n) => n.id !== id),
      }));
    } catch (error) {
      console.error('Error deleting note:', error);
    }
  },

  getNoteById: (id) => {
    return get().notes.find((n) => n.id === id);
  },

  setSearchQuery: (query) => {
    set({ searchQuery: query });
  },

  getFilteredNotes: () => {
    const { notes, searchQuery } = get();
    if (!searchQuery.trim()) return notes;

    const query = searchQuery.toLowerCase();
    return notes.filter((note) => 
      note.title.toLowerCase().includes(query) ||
      note.content.toLowerCase().includes(query) ||
      note.category.toLowerCase().includes(query) ||
      note.tags.some((tag) => tag.toLowerCase().includes(query))
    );
  },

  countNotes: () => {
    return get().notes.length;
  },
}));
