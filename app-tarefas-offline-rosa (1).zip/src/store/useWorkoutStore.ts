import { create } from 'zustand';

// Tipos
export type WorkoutIntensity = 'NONE' | 'LIGHT' | 'MEDIUM' | 'INTENSE';
export type WorkoutType = 'NONE' | 'CARDIO' | 'STRENGTH' | 'YOGA' | 'STRETCHING' | 'FUNCTIONAL' | 'HIIT' | 'DANCE' | 'OTHER';

export interface WorkoutDay {
  id: string;
  dateKey: string; // YYYY-MM-DD
  intensity: WorkoutIntensity;
  workoutTypes: WorkoutType[]; // Múltiplos tipos permitidos
  duration?: number; // em minutos
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

// Labels em português
export const intensityLabels: Record<WorkoutIntensity, string> = {
  NONE: 'Nenhum',
  LIGHT: 'Leve',
  MEDIUM: 'Médio',
  INTENSE: 'Intenso'
};

export const workoutTypeLabels: Record<WorkoutType, string> = {
  NONE: 'Nenhum',
  CARDIO: 'Cardio',
  STRENGTH: 'Musculação',
  YOGA: 'Yoga',
  STRETCHING: 'Alongamento',
  FUNCTIONAL: 'Funcional',
  HIIT: 'HIIT',
  DANCE: 'Dança',
  OTHER: 'Outro'
};

// Ícones e cores para cada tipo
export const workoutTypeConfig: Record<WorkoutType, { emoji: string; color: string; bgColor: string }> = {
  NONE: { emoji: '🚫', color: '#9CA3AF', bgColor: '#F3F4F6' },
  CARDIO: { emoji: '🏃‍♀️', color: '#EF4444', bgColor: '#FEE2E2' },
  STRENGTH: { emoji: '💪', color: '#8B5CF6', bgColor: '#EDE9FE' },
  YOGA: { emoji: '🧘‍♀️', color: '#10B981', bgColor: '#D1FAE5' },
  STRETCHING: { emoji: '🤸‍♀️', color: '#06B6D4', bgColor: '#CFFAFE' },
  FUNCTIONAL: { emoji: '🏋️‍♀️', color: '#F59E0B', bgColor: '#FEF3C7' },
  HIIT: { emoji: '⚡', color: '#EC4899', bgColor: '#FCE7F3' },
  DANCE: { emoji: '💃', color: '#F472B6', bgColor: '#FCE7F3' },
  OTHER: { emoji: '🎯', color: '#6B7280', bgColor: '#F3F4F6' }
};

export const intensityConfig: Record<WorkoutIntensity, { emoji: string; color: string; bgColor: string; gradient: string }> = {
  NONE: { emoji: '😴', color: '#9CA3AF', bgColor: '#F3F4F6', gradient: 'from-gray-100 to-gray-200' },
  LIGHT: { emoji: '🚶‍♀️', color: '#10B981', bgColor: '#D1FAE5', gradient: 'from-green-300 to-emerald-400' },
  MEDIUM: { emoji: '🏃‍♀️', color: '#F59E0B', bgColor: '#FEF3C7', gradient: 'from-amber-300 to-orange-400' },
  INTENSE: { emoji: '🔥', color: '#EF4444', bgColor: '#FEE2E2', gradient: 'from-red-400 to-pink-500' }
};

interface WorkoutStore {
  workouts: WorkoutDay[];
  isLoading: boolean;
  
  // Actions
  initialize: () => void;
  saveWorkout: (workout: Omit<WorkoutDay, 'id' | 'createdAt' | 'updatedAt'>) => Promise<void>;
  getTodayWorkout: () => WorkoutDay | null;
  getWorkoutByDate: (dateKey: string) => WorkoutDay | null;
  getWorkoutsInRange: (startDate: string, endDate: string) => WorkoutDay[];
  getTodayLabel: () => string;
  getWeekStats: () => { totalWorkouts: number; totalMinutes: number; streak: number };
}

const STORAGE_KEY = 'vida-rosa-workout-entries';

const loadFromStorage = (): WorkoutDay[] => {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
};

const saveToStorage = (workouts: WorkoutDay[]) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(workouts));
};

const generateId = () => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

const getTodayKey = () => {
  return new Date().toISOString().split('T')[0];
};

export const useWorkoutStore = create<WorkoutStore>((set, get) => ({
  workouts: [],
  isLoading: false, // Start as false since localStorage is synchronous
  
  initialize: () => {
    const workouts = loadFromStorage();
    set({ workouts, isLoading: false });
  },
  
  saveWorkout: async (workoutData) => {
    const existing = get().workouts.find(w => w.dateKey === workoutData.dateKey);
    const now = new Date().toISOString();
    
    const workout: WorkoutDay = {
      id: existing?.id || generateId(),
      ...workoutData,
      createdAt: existing?.createdAt || now,
      updatedAt: now
    };
    
    let newWorkouts: WorkoutDay[];
    if (existing) {
      newWorkouts = get().workouts.map(w => w.id === workout.id ? workout : w);
    } else {
      newWorkouts = [...get().workouts, workout];
    }
    
    saveToStorage(newWorkouts);
    set({ workouts: newWorkouts });
  },
  
  getTodayWorkout: () => {
    const todayKey = getTodayKey();
    return get().workouts.find(w => w.dateKey === todayKey) || null;
  },
  
  getWorkoutByDate: (dateKey) => {
    return get().workouts.find(w => w.dateKey === dateKey) || null;
  },
  
  getWorkoutsInRange: (startDate, endDate) => {
    return get().workouts.filter(w => w.dateKey >= startDate && w.dateKey <= endDate);
  },
  
  getTodayLabel: () => {
    const today = get().getTodayWorkout();
    if (!today || today.intensity === 'NONE') return 'Nenhum';
    
    const types = today.workoutTypes.filter(t => t !== 'NONE');
    if (types.length === 0) return intensityLabels[today.intensity];
    
    const typeLabels = types.map(t => workoutTypeLabels[t]).join(', ');
    return `${typeLabels} • ${intensityLabels[today.intensity]}`;
  },
  
  getWeekStats: () => {
    const today = new Date();
    const weekAgo = new Date(today);
    weekAgo.setDate(weekAgo.getDate() - 7);
    
    const startDate = weekAgo.toISOString().split('T')[0];
    const endDate = today.toISOString().split('T')[0];
    
    const weekWorkouts = get().getWorkoutsInRange(startDate, endDate)
      .filter(w => w.intensity !== 'NONE');
    
    const totalWorkouts = weekWorkouts.length;
    const totalMinutes = weekWorkouts.reduce((sum, w) => sum + (w.duration || 0), 0);
    
    // Calculate streak
    let streak = 0;
    const allWorkouts = [...get().workouts].sort((a, b) => b.dateKey.localeCompare(a.dateKey));
    
    for (let i = 0; i < 365; i++) {
      const checkDate = new Date(today);
      checkDate.setDate(checkDate.getDate() - i);
      const dateKey = checkDate.toISOString().split('T')[0];
      
      const workout = allWorkouts.find(w => w.dateKey === dateKey);
      if (workout && workout.intensity !== 'NONE') {
        streak++;
      } else if (i > 0) {
        break;
      }
    }
    
    return { totalWorkouts, totalMinutes, streak };
  }
}));
