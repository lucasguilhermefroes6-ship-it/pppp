import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';

export type TransactionType = 'INCOME' | 'EXPENSE';

export interface Transaction {
  id: string;
  type: TransactionType;
  amountCents: number; // value in cents
  description?: string;
  category: string;
  date: string; // YYYY-MM-DD
  createdAt: string;
  updatedAt: string;
  isFixed: boolean;
}

// Categorias personalizadas
export interface CustomCategory {
  id: string;
  name: string;
  color: string;
  icon?: string;
  type: 'INCOME' | 'EXPENSE' | 'BOTH';
  createdAt: string;
}

export const DEFAULT_CATEGORIES = [
  'Alimentação',
  'Transporte',
  'Moradia',
  'Saúde',
  'Educação',
  'Lazer',
  'Vestuário',
  'Contas',
  'Outros'
] as const;

// Mantemos CATEGORIES para compatibilidade
export const CATEGORIES = DEFAULT_CATEGORIES;

export type Category = typeof CATEGORIES[number];

// ========== DATABASE HELPERS ==========
const DB_NAME = 'rosa-finance-db';
const DB_VERSION = 1;

let dbInstance: IDBDatabase | null = null;

const openDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    if (dbInstance) {
      resolve(dbInstance);
      return;
    }
    
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    
    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      dbInstance = request.result;
      resolve(dbInstance);
    };
    
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      
      if (!db.objectStoreNames.contains('transactions')) {
        const store = db.createObjectStore('transactions', { keyPath: 'id' });
        store.createIndex('date', 'date', { unique: false });
        store.createIndex('type', 'type', { unique: false });
        store.createIndex('category', 'category', { unique: false });
        store.createIndex('isFixed', 'isFixed', { unique: false });
      }
    };
  });
};

// ========== STORE ==========
interface FinanceState {
  transactions: Transaction[];
  customCategories: CustomCategory[];
  isLoading: boolean;
  selectedMonth: Date;
  
  // Actions
  initialize: () => Promise<void>;
  refreshData: () => Promise<void>;
  
  // Transaction CRUD
  createTransaction: (data: Omit<Transaction, 'id' | 'createdAt' | 'updatedAt'>) => Promise<Transaction>;
  updateTransaction: (transaction: Transaction) => Promise<Transaction>;
  deleteTransaction: (id: string) => Promise<void>;
  getTransactionById: (id: string) => Transaction | undefined;
  
  // Category CRUD
  createCategory: (data: { name: string; color?: string; icon?: string; type?: 'INCOME' | 'EXPENSE' | 'BOTH' }) => Promise<CustomCategory>;
  deleteCategory: (id: string) => Promise<void>;
  getAllCategories: () => string[];
  
  // Navigation
  setSelectedMonth: (date: Date) => void;
  nextMonth: () => void;
  prevMonth: () => void;
  
  // Calculations
  getMonthTransactions: () => Transaction[];
  sumIncomeForMonth: () => number;
  sumExpenseForMonth: () => number;
  getBalance: () => number;
  getFixedTransactions: () => Transaction[];
}

export const useFinanceStore = create<FinanceState>((set, get) => ({
  transactions: [],
  customCategories: [],
  isLoading: true,
  selectedMonth: new Date(),
  
  initialize: async () => {
    set({ isLoading: true });
    await openDB();
    await get().refreshData();
    set({ isLoading: false });
  },
  
  refreshData: async () => {
    const db = await openDB();
    
    const transactions = await new Promise<Transaction[]>((resolve, reject) => {
      const transaction = db.transaction('transactions', 'readonly');
      const store = transaction.objectStore('transactions');
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    
    // Load custom categories from localStorage
    const savedCategories = localStorage.getItem('vida-rosa-custom-categories');
    const customCategories: CustomCategory[] = savedCategories ? JSON.parse(savedCategories) : [];
    
    set({ transactions, customCategories });
  },
  
  createTransaction: async (data) => {
    const db = await openDB();
    const now = new Date().toISOString();
    
    const transaction: Transaction = {
      ...data,
      id: uuidv4(),
      createdAt: now,
      updatedAt: now
    };
    
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction('transactions', 'readwrite');
      const store = tx.objectStore('transactions');
      const request = store.add(transaction);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
    
    await get().refreshData();
    return transaction;
  },
  
  updateTransaction: async (transaction) => {
    const db = await openDB();
    const updated = { ...transaction, updatedAt: new Date().toISOString() };
    
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction('transactions', 'readwrite');
      const store = tx.objectStore('transactions');
      const request = store.put(updated);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
    
    await get().refreshData();
    return updated;
  },
  
  deleteTransaction: async (id) => {
    const db = await openDB();
    
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction('transactions', 'readwrite');
      const store = tx.objectStore('transactions');
      const request = store.delete(id);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
    
    await get().refreshData();
  },
  
  getTransactionById: (id) => {
    const { transactions } = get();
    return transactions.find(t => t.id === id);
  },
  
  // Category CRUD
  createCategory: async (data) => {
    const { customCategories } = get();
    const now = new Date().toISOString();
    
    const newCategory: CustomCategory = {
      id: uuidv4(),
      name: data.name.trim(),
      color: data.color || '#EC4899',
      icon: data.icon,
      type: data.type || 'BOTH',
      createdAt: now
    };
    
    const updatedCategories = [...customCategories, newCategory];
    localStorage.setItem('vida-rosa-custom-categories', JSON.stringify(updatedCategories));
    set({ customCategories: updatedCategories });
    
    return newCategory;
  },
  
  deleteCategory: async (id) => {
    const { customCategories } = get();
    const updatedCategories = customCategories.filter(c => c.id !== id);
    localStorage.setItem('vida-rosa-custom-categories', JSON.stringify(updatedCategories));
    set({ customCategories: updatedCategories });
  },
  
  getAllCategories: () => {
    const { customCategories } = get();
    const defaultCats = [...DEFAULT_CATEGORIES];
    const customCats = customCategories.map(c => c.name);
    return [...defaultCats, ...customCats];
  },
  
  setSelectedMonth: (date) => set({ selectedMonth: date }),
  
  nextMonth: () => {
    const { selectedMonth } = get();
    const next = new Date(selectedMonth);
    next.setMonth(next.getMonth() + 1);
    set({ selectedMonth: next });
  },
  
  prevMonth: () => {
    const { selectedMonth } = get();
    const prev = new Date(selectedMonth);
    prev.setMonth(prev.getMonth() - 1);
    set({ selectedMonth: prev });
  },
  
  getMonthTransactions: () => {
    const { transactions, selectedMonth } = get();
    const year = selectedMonth.getFullYear();
    const month = selectedMonth.getMonth();
    
    return transactions.filter(t => {
      const date = new Date(t.date);
      return date.getFullYear() === year && date.getMonth() === month;
    }).sort((a, b) => b.date.localeCompare(a.date));
  },
  
  sumIncomeForMonth: () => {
    const monthTransactions = get().getMonthTransactions();
    return monthTransactions
      .filter(t => t.type === 'INCOME')
      .reduce((sum, t) => sum + t.amountCents, 0);
  },
  
  sumExpenseForMonth: () => {
    const monthTransactions = get().getMonthTransactions();
    return monthTransactions
      .filter(t => t.type === 'EXPENSE')
      .reduce((sum, t) => sum + t.amountCents, 0);
  },
  
  getBalance: () => {
    const income = get().sumIncomeForMonth();
    const expense = get().sumExpenseForMonth();
    return income - expense;
  },
  
  getFixedTransactions: () => {
    const { transactions } = get();
    return transactions.filter(t => t.isFixed);
  }
}));

// Helper function to format currency
export const formatCurrency = (cents: number): string => {
  const value = cents / 100;
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(value);
};

// Helper function to parse currency input
export const parseCurrencyInput = (input: string): number => {
  // Remove non-numeric characters except comma and dot
  const cleaned = input.replace(/[^\d,.-]/g, '');
  // Replace comma with dot for parsing
  const normalized = cleaned.replace(',', '.');
  const value = parseFloat(normalized) || 0;
  // Convert to cents
  return Math.round(value * 100);
};
