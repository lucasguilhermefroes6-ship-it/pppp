import { create } from 'zustand';

export type PomodoroMode = 'focus' | 'shortBreak' | 'longBreak';

interface PomodoroSession {
  id: string;
  startedAt: string;
  completedAt: string;
  mode: PomodoroMode;
  duration: number; // in seconds
}

interface PomodoroState {
  // Timer state
  mode: PomodoroMode;
  timeRemaining: number; // in seconds
  isRunning: boolean;
  
  // Session tracking
  sessionsToday: number;
  totalFocusTime: number; // in minutes
  currentStreak: number;
  
  // Settings (in minutes)
  focusDuration: number;
  shortBreakDuration: number;
  longBreakDuration: number;
  sessionsUntilLongBreak: number;
  
  // History
  sessions: PomodoroSession[];
  
  // Actions
  setMode: (mode: PomodoroMode) => void;
  start: () => void;
  pause: () => void;
  reset: () => void;
  tick: () => void;
  skip: () => void;
  completeSession: () => void;
}

const FOCUS_DURATION = 25 * 60; // 25 minutes
// SHORT_BREAK_DURATION and LONG_BREAK_DURATION are calculated from settings

export const usePomodoroStore = create<PomodoroState>((set, get) => ({
  mode: 'focus',
  timeRemaining: FOCUS_DURATION,
  isRunning: false,
  
  sessionsToday: 0,
  totalFocusTime: 0,
  currentStreak: 0,
  
  focusDuration: 25,
  shortBreakDuration: 5,
  longBreakDuration: 15,
  sessionsUntilLongBreak: 4,
  
  sessions: [],
  
  setMode: (mode) => {
    const { focusDuration, shortBreakDuration, longBreakDuration } = get();
    let duration: number;
    
    switch (mode) {
      case 'focus':
        duration = focusDuration * 60;
        break;
      case 'shortBreak':
        duration = shortBreakDuration * 60;
        break;
      case 'longBreak':
        duration = longBreakDuration * 60;
        break;
    }
    
    set({ mode, timeRemaining: duration, isRunning: false });
  },
  
  start: () => set({ isRunning: true }),
  
  pause: () => set({ isRunning: false }),
  
  reset: () => {
    const { mode, focusDuration, shortBreakDuration, longBreakDuration } = get();
    let duration: number;
    
    switch (mode) {
      case 'focus':
        duration = focusDuration * 60;
        break;
      case 'shortBreak':
        duration = shortBreakDuration * 60;
        break;
      case 'longBreak':
        duration = longBreakDuration * 60;
        break;
    }
    
    set({ timeRemaining: duration, isRunning: false });
  },
  
  tick: () => {
    const { timeRemaining, isRunning } = get();
    
    if (!isRunning) return;
    
    if (timeRemaining <= 0) {
      get().completeSession();
      return;
    }
    
    set({ timeRemaining: timeRemaining - 1 });
  },
  
  skip: () => {
    const { mode, sessionsToday, sessionsUntilLongBreak, shortBreakDuration, longBreakDuration, focusDuration } = get();
    
    if (mode === 'focus') {
      // Skip to break
      const shouldLongBreak = (sessionsToday + 1) % sessionsUntilLongBreak === 0;
      const nextMode = shouldLongBreak ? 'longBreak' : 'shortBreak';
      const duration = shouldLongBreak ? longBreakDuration * 60 : shortBreakDuration * 60;
      set({ mode: nextMode, timeRemaining: duration, isRunning: false });
    } else {
      // Skip to focus
      set({ mode: 'focus', timeRemaining: focusDuration * 60, isRunning: false });
    }
  },
  
  completeSession: () => {
    const { 
      mode, 
      sessionsToday, 
      totalFocusTime,
      currentStreak,
      focusDuration,
      shortBreakDuration,
      longBreakDuration,
      sessionsUntilLongBreak,
      sessions
    } = get();
    
    const now = new Date().toISOString();
    
    if (mode === 'focus') {
      // Completed a focus session
      const newSessionsToday = sessionsToday + 1;
      const newTotalFocusTime = totalFocusTime + focusDuration;
      
      const session: PomodoroSession = {
        id: `session-${Date.now()}`,
        startedAt: now,
        completedAt: now,
        mode: 'focus',
        duration: focusDuration * 60
      };
      
      // Determine next mode
      const shouldLongBreak = newSessionsToday % sessionsUntilLongBreak === 0;
      const nextMode = shouldLongBreak ? 'longBreak' : 'shortBreak';
      const duration = shouldLongBreak ? longBreakDuration * 60 : shortBreakDuration * 60;
      
      set({
        mode: nextMode,
        timeRemaining: duration,
        isRunning: false,
        sessionsToday: newSessionsToday,
        totalFocusTime: newTotalFocusTime,
        currentStreak: currentStreak + 1,
        sessions: [...sessions, session]
      });
    } else {
      // Completed a break
      set({
        mode: 'focus',
        timeRemaining: focusDuration * 60,
        isRunning: false
      });
    }
  }
}));
