import { create } from 'zustand';

// Types
export interface HouseTask {
  id: string;
  title: string;
  description?: string;
  room: string;
  category: string;
  priority: 'LOW' | 'MEDIUM' | 'HIGH';
  dueDate?: string;
  dueTime?: string;
  reminderEnabled: boolean;
  recurrenceEnabled: boolean;
  recurrenceRule?: RecurrenceRule;
  createdAt: string;
  updatedAt: string;
}

export interface RecurrenceRule {
  type: 'DAILY' | 'WEEKLY' | 'MONTHLY';
  interval: number;
  weekdays?: string[];
  dayOfMonth?: number;
}

export interface TaskOccurrence {
  id: string;
  taskId: string;
  date: string;
  completed: boolean;
  completedAt?: string;
}

export interface ShoppingItem {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  category: string;
  purchased: boolean;
  price?: number;
  createdAt: string;
}

export interface MaintenanceItem {
  id: string;
  title: string;
  description?: string;
  room: string;
  dueDate?: string;
  completed: boolean;
  priority: 'LOW' | 'MEDIUM' | 'HIGH';
  cost?: number;
  createdAt: string;
}

export interface HouseBill {
  id: string;
  title: string;
  amount: number;
  dueDate: string;
  category: string;
  paid: boolean;
  paidAt?: string;
  recurrent: boolean;
  createdAt: string;
}

export interface InventoryItem {
  id: string;
  name: string;
  quantity: number;
  room: string;
  category: string;
  minQuantity?: number;
  expiryDate?: string;
  notes?: string;
  createdAt: string;
}

interface HouseStore {
  // Tasks
  tasks: HouseTask[];
  occurrences: Map<string, TaskOccurrence>;
  
  // Shopping
  shoppingItems: ShoppingItem[];
  
  // Maintenance
  maintenanceItems: MaintenanceItem[];
  
  // Bills
  bills: HouseBill[];
  
  // Inventory
  inventoryItems: InventoryItem[];
  
  // Task Actions
  addTask: (task: Omit<HouseTask, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateTask: (id: string, updates: Partial<HouseTask>) => void;
  deleteTask: (id: string) => void;
  toggleTaskOccurrence: (taskId: string, date: string) => void;
  
  // Shopping Actions
  addShoppingItem: (item: Omit<ShoppingItem, 'id' | 'createdAt'>) => void;
  updateShoppingItem: (id: string, updates: Partial<ShoppingItem>) => void;
  deleteShoppingItem: (id: string) => void;
  toggleShoppingItem: (id: string) => void;
  
  // Maintenance Actions
  addMaintenanceItem: (item: Omit<MaintenanceItem, 'id' | 'createdAt'>) => void;
  updateMaintenanceItem: (id: string, updates: Partial<MaintenanceItem>) => void;
  deleteMaintenanceItem: (id: string) => void;
  
  // Bills Actions
  addBill: (bill: Omit<HouseBill, 'id' | 'createdAt'>) => void;
  updateBill: (id: string, updates: Partial<HouseBill>) => void;
  deleteBill: (id: string) => void;
  toggleBillPaid: (id: string) => void;
  
  // Inventory Actions
  addInventoryItem: (item: Omit<InventoryItem, 'id' | 'createdAt'>) => void;
  updateInventoryItem: (id: string, updates: Partial<InventoryItem>) => void;
  deleteInventoryItem: (id: string) => void;
  
  // Helpers
  getTasksForDate: (date: string) => HouseTask[];
  getTasksForRoom: (room: string) => HouseTask[];
  isTaskCompletedOnDate: (taskId: string, date: string) => boolean;
  occursOnDate: (task: HouseTask, date: string) => boolean;
  
  // Persistence
  loadData: () => void;
  saveData: () => void;
}

const generateId = () => Math.random().toString(36).substr(2, 9) + Date.now().toString(36);

// const getToday = () => new Date().toISOString().split('T')[0];

const getDayOfWeek = (dateStr: string): string => {
  const date = new Date(dateStr);
  const days = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
  return days[date.getDay()];
};

export const useHouseStore = create<HouseStore>((set, get) => ({
  tasks: [],
  occurrences: new Map(),
  shoppingItems: [],
  maintenanceItems: [],
  bills: [],
  inventoryItems: [],

  // Task Actions
  addTask: (task) => {
    const newTask: HouseTask = {
      ...task,
      id: generateId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    set((state) => {
      const newTasks = [...state.tasks, newTask];
      localStorage.setItem('house-tasks', JSON.stringify(newTasks));
      return { tasks: newTasks };
    });
  },

  updateTask: (id, updates) => {
    set((state) => {
      const newTasks = state.tasks.map((t) =>
        t.id === id ? { ...t, ...updates, updatedAt: new Date().toISOString() } : t
      );
      localStorage.setItem('house-tasks', JSON.stringify(newTasks));
      return { tasks: newTasks };
    });
  },

  deleteTask: (id) => {
    set((state) => {
      const newTasks = state.tasks.filter((t) => t.id !== id);
      localStorage.setItem('house-tasks', JSON.stringify(newTasks));
      return { tasks: newTasks };
    });
  },

  toggleTaskOccurrence: (taskId, date) => {
    set((state) => {
      const key = `${taskId}-${date}`;
      const newOccurrences = new Map(state.occurrences);
      
      if (newOccurrences.has(key)) {
        const occ = newOccurrences.get(key)!;
        if (occ.completed) {
          newOccurrences.delete(key);
        } else {
          newOccurrences.set(key, {
            ...occ,
            completed: true,
            completedAt: new Date().toISOString(),
          });
        }
      } else {
        newOccurrences.set(key, {
          id: generateId(),
          taskId,
          date,
          completed: true,
          completedAt: new Date().toISOString(),
        });
      }
      
      const occArray = Array.from(newOccurrences.values());
      localStorage.setItem('house-occurrences', JSON.stringify(occArray));
      return { occurrences: newOccurrences };
    });
  },

  // Shopping Actions
  addShoppingItem: (item) => {
    const newItem: ShoppingItem = {
      ...item,
      id: generateId(),
      createdAt: new Date().toISOString(),
    };
    set((state) => {
      const newItems = [...state.shoppingItems, newItem];
      localStorage.setItem('house-shopping', JSON.stringify(newItems));
      return { shoppingItems: newItems };
    });
  },

  updateShoppingItem: (id, updates) => {
    set((state) => {
      const newItems = state.shoppingItems.map((i) =>
        i.id === id ? { ...i, ...updates } : i
      );
      localStorage.setItem('house-shopping', JSON.stringify(newItems));
      return { shoppingItems: newItems };
    });
  },

  deleteShoppingItem: (id) => {
    set((state) => {
      const newItems = state.shoppingItems.filter((i) => i.id !== id);
      localStorage.setItem('house-shopping', JSON.stringify(newItems));
      return { shoppingItems: newItems };
    });
  },

  toggleShoppingItem: (id) => {
    set((state) => {
      const newItems = state.shoppingItems.map((i) =>
        i.id === id ? { ...i, purchased: !i.purchased } : i
      );
      localStorage.setItem('house-shopping', JSON.stringify(newItems));
      return { shoppingItems: newItems };
    });
  },

  // Maintenance Actions
  addMaintenanceItem: (item) => {
    const newItem: MaintenanceItem = {
      ...item,
      id: generateId(),
      createdAt: new Date().toISOString(),
    };
    set((state) => {
      const newItems = [...state.maintenanceItems, newItem];
      localStorage.setItem('house-maintenance', JSON.stringify(newItems));
      return { maintenanceItems: newItems };
    });
  },

  updateMaintenanceItem: (id, updates) => {
    set((state) => {
      const newItems = state.maintenanceItems.map((i) =>
        i.id === id ? { ...i, ...updates } : i
      );
      localStorage.setItem('house-maintenance', JSON.stringify(newItems));
      return { maintenanceItems: newItems };
    });
  },

  deleteMaintenanceItem: (id) => {
    set((state) => {
      const newItems = state.maintenanceItems.filter((i) => i.id !== id);
      localStorage.setItem('house-maintenance', JSON.stringify(newItems));
      return { maintenanceItems: newItems };
    });
  },

  // Bills Actions
  addBill: (bill) => {
    const newBill: HouseBill = {
      ...bill,
      id: generateId(),
      createdAt: new Date().toISOString(),
    };
    set((state) => {
      const newBills = [...state.bills, newBill];
      localStorage.setItem('house-bills', JSON.stringify(newBills));
      return { bills: newBills };
    });
  },

  updateBill: (id, updates) => {
    set((state) => {
      const newBills = state.bills.map((b) =>
        b.id === id ? { ...b, ...updates } : b
      );
      localStorage.setItem('house-bills', JSON.stringify(newBills));
      return { bills: newBills };
    });
  },

  deleteBill: (id) => {
    set((state) => {
      const newBills = state.bills.filter((b) => b.id !== id);
      localStorage.setItem('house-bills', JSON.stringify(newBills));
      return { bills: newBills };
    });
  },

  toggleBillPaid: (id) => {
    set((state) => {
      const newBills = state.bills.map((b) =>
        b.id === id ? { ...b, paid: !b.paid, paidAt: !b.paid ? new Date().toISOString() : undefined } : b
      );
      localStorage.setItem('house-bills', JSON.stringify(newBills));
      return { bills: newBills };
    });
  },

  // Inventory Actions
  addInventoryItem: (item) => {
    const newItem: InventoryItem = {
      ...item,
      id: generateId(),
      createdAt: new Date().toISOString(),
    };
    set((state) => {
      const newItems = [...state.inventoryItems, newItem];
      localStorage.setItem('house-inventory', JSON.stringify(newItems));
      return { inventoryItems: newItems };
    });
  },

  updateInventoryItem: (id, updates) => {
    set((state) => {
      const newItems = state.inventoryItems.map((i) =>
        i.id === id ? { ...i, ...updates } : i
      );
      localStorage.setItem('house-inventory', JSON.stringify(newItems));
      return { inventoryItems: newItems };
    });
  },

  deleteInventoryItem: (id) => {
    set((state) => {
      const newItems = state.inventoryItems.filter((i) => i.id !== id);
      localStorage.setItem('house-inventory', JSON.stringify(newItems));
      return { inventoryItems: newItems };
    });
  },

  // Helpers
  occursOnDate: (task, date) => {
    if (!task.recurrenceEnabled || !task.recurrenceRule) {
      return task.dueDate === date;
    }

    const rule = task.recurrenceRule;
    const taskStartDate = task.dueDate || task.createdAt.split('T')[0];
    
    if (date < taskStartDate) return false;

    if (rule.type === 'DAILY') {
      const start = new Date(taskStartDate);
      const target = new Date(date);
      const diffDays = Math.floor((target.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
      return diffDays >= 0 && diffDays % rule.interval === 0;
    }

    if (rule.type === 'WEEKLY' && rule.weekdays) {
      const dayOfWeek = getDayOfWeek(date);
      return rule.weekdays.includes(dayOfWeek);
    }

    if (rule.type === 'MONTHLY' && rule.dayOfMonth) {
      const targetDate = new Date(date);
      return targetDate.getDate() === rule.dayOfMonth;
    }

    return false;
  },

  getTasksForDate: (date) => {
    const { tasks, occursOnDate } = get();
    return tasks.filter((task) => occursOnDate(task, date));
  },

  getTasksForRoom: (room) => {
    const { tasks } = get();
    return tasks.filter((task) => task.room === room);
  },

  isTaskCompletedOnDate: (taskId, date) => {
    const { occurrences } = get();
    const key = `${taskId}-${date}`;
    const occ = occurrences.get(key);
    return occ?.completed || false;
  },

  // Persistence
  loadData: () => {
    try {
      const tasks = JSON.parse(localStorage.getItem('house-tasks') || '[]');
      const occArray = JSON.parse(localStorage.getItem('house-occurrences') || '[]');
      const shoppingItems = JSON.parse(localStorage.getItem('house-shopping') || '[]');
      const maintenanceItems = JSON.parse(localStorage.getItem('house-maintenance') || '[]');
      const bills = JSON.parse(localStorage.getItem('house-bills') || '[]');
      const inventoryItems = JSON.parse(localStorage.getItem('house-inventory') || '[]');
      
      const occurrences = new Map<string, TaskOccurrence>();
      occArray.forEach((occ: TaskOccurrence) => {
        occurrences.set(`${occ.taskId}-${occ.date}`, occ);
      });
      
      set({ tasks, occurrences, shoppingItems, maintenanceItems, bills, inventoryItems });
    } catch (error) {
      console.error('Error loading house data:', error);
    }
  },

  saveData: () => {
    const state = get();
    localStorage.setItem('house-tasks', JSON.stringify(state.tasks));
    localStorage.setItem('house-shopping', JSON.stringify(state.shoppingItems));
    localStorage.setItem('house-maintenance', JSON.stringify(state.maintenanceItems));
    localStorage.setItem('house-bills', JSON.stringify(state.bills));
    localStorage.setItem('house-inventory', JSON.stringify(state.inventoryItems));
    
    const occArray = Array.from(state.occurrences.values());
    localStorage.setItem('house-occurrences', JSON.stringify(occArray));
  },
}));
