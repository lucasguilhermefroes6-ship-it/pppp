import { create } from 'zustand';
import { DiaryEntry, SecretDiarySettings } from '../types';

const ENTRIES_KEY = 'vida-rosa-secret-diary-entries';
const SETTINGS_KEY = 'vida-rosa-secret-diary-settings';

interface SecretDiaryState {
  entries: DiaryEntry[];
  settings: SecretDiarySettings;
  isLoading: boolean;
  isUnlocked: boolean;
  searchQuery: string;
  
  // Auth Actions
  loadSettings: () => void;
  createPin: (pin: string) => void;
  verifyPin: (pin: string) => boolean;
  changePin: (oldPin: string, newPin: string) => boolean;
  toggleBiometry: () => void;
  lock: () => void;
  unlock: () => void;
  recordFailedAttempt: () => void;
  resetFailedAttempts: () => void;
  isLocked: () => boolean;
  
  // CRUD Actions
  loadEntries: () => void;
  createEntry: (entry: Partial<DiaryEntry>) => DiaryEntry;
  updateEntry: (id: string, updates: Partial<DiaryEntry>) => void;
  deleteEntry: (id: string) => void;
  getEntryByDate: (dateKey: string) => DiaryEntry | undefined;
  getEntryById: (id: string) => DiaryEntry | undefined;
  setSearchQuery: (query: string) => void;
  countEntries: () => number;
  
  // Filtered
  getFilteredEntries: () => DiaryEntry[];
}

// Simple hash function for PIN
const hashPin = (pin: string): string => {
  let hash = 0;
  for (let i = 0; i < pin.length; i++) {
    const char = pin.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return hash.toString(36);
};

const loadEntriesFromStorage = (): DiaryEntry[] => {
  try {
    const data = localStorage.getItem(ENTRIES_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
};

const saveEntriesToStorage = (entries: DiaryEntry[]) => {
  localStorage.setItem(ENTRIES_KEY, JSON.stringify(entries));
};

const loadSettingsFromStorage = (): SecretDiarySettings => {
  try {
    const data = localStorage.getItem(SETTINGS_KEY);
    return data ? JSON.parse(data) : {
      hasPin: false,
      biometryEnabled: false,
      failedAttempts: 0,
    };
  } catch {
    return {
      hasPin: false,
      biometryEnabled: false,
      failedAttempts: 0,
    };
  }
};

const saveSettingsToStorage = (settings: SecretDiarySettings) => {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
};

const generateId = () => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

const sortEntries = (entries: DiaryEntry[]): DiaryEntry[] => {
  return [...entries].sort((a, b) => 
    new Date(b.dateKey).getTime() - new Date(a.dateKey).getTime()
  );
};

export const useSecretDiaryStore = create<SecretDiaryState>((set, get) => ({
  entries: [],
  settings: {
    hasPin: false,
    biometryEnabled: false,
    failedAttempts: 0,
  },
  isLoading: false,
  isUnlocked: false,
  searchQuery: '',

  loadSettings: () => {
    const settings = loadSettingsFromStorage();
    set({ settings });
  },

  createPin: (pin: string) => {
    const settings: SecretDiarySettings = {
      hasPin: true,
      pinHash: hashPin(pin),
      biometryEnabled: false,
      failedAttempts: 0,
    };
    saveSettingsToStorage(settings);
    set({ settings, isUnlocked: true });
  },

  verifyPin: (pin: string) => {
    const { settings } = get();
    if (!settings.pinHash) return false;
    
    const isValid = hashPin(pin) === settings.pinHash;
    if (isValid) {
      get().resetFailedAttempts();
      set({ isUnlocked: true });
    }
    return isValid;
  },

  changePin: (oldPin: string, newPin: string) => {
    const { settings } = get();
    if (!settings.pinHash || hashPin(oldPin) !== settings.pinHash) {
      return false;
    }
    
    const newSettings: SecretDiarySettings = {
      ...settings,
      pinHash: hashPin(newPin),
    };
    saveSettingsToStorage(newSettings);
    set({ settings: newSettings });
    return true;
  },

  toggleBiometry: () => {
    const { settings } = get();
    const newSettings: SecretDiarySettings = {
      ...settings,
      biometryEnabled: !settings.biometryEnabled,
    };
    saveSettingsToStorage(newSettings);
    set({ settings: newSettings });
  },

  lock: () => {
    set({ isUnlocked: false });
  },

  unlock: () => {
    set({ isUnlocked: true });
  },

  recordFailedAttempt: () => {
    const { settings } = get();
    const failedAttempts = settings.failedAttempts + 1;
    let lockedUntil: string | undefined;
    
    if (failedAttempts >= 3) {
      lockedUntil = new Date(Date.now() + 10000).toISOString(); // 10 seconds
    }
    
    const newSettings: SecretDiarySettings = {
      ...settings,
      failedAttempts,
      lockedUntil,
    };
    saveSettingsToStorage(newSettings);
    set({ settings: newSettings });
  },

  resetFailedAttempts: () => {
    const { settings } = get();
    const newSettings: SecretDiarySettings = {
      ...settings,
      failedAttempts: 0,
      lockedUntil: undefined,
    };
    saveSettingsToStorage(newSettings);
    set({ settings: newSettings });
  },

  isLocked: () => {
    const { settings } = get();
    if (!settings.lockedUntil) return false;
    return new Date() < new Date(settings.lockedUntil);
  },

  loadEntries: () => {
    const entries = loadEntriesFromStorage();
    set({ entries: sortEntries(entries), isLoading: false });
  },

  createEntry: (entryData) => {
    const now = new Date().toISOString();
    const dateKey = entryData.dateKey || new Date().toISOString().split('T')[0];
    
    // IMPORTANTE: Cada entrada tem um ID único, NÃO sobrescrevemos por dateKey
    // Isso permite múltiplos diários no mesmo dia
    const entry: DiaryEntry = {
      id: generateId(),
      title: entryData.title || '',
      content: entryData.content || '',
      dateKey,
      createdAt: now,
      updatedAt: now,
    };

    const newEntries = sortEntries([...get().entries, entry]);
    saveEntriesToStorage(newEntries);
    set({ entries: newEntries });
    
    console.log('Diary entry created:', entry.id, 'Total:', newEntries.length);
    return entry;
  },

  updateEntry: (id, updates) => {
    const entries = get().entries;
    const entryIndex = entries.findIndex(e => e.id === id);
    
    if (entryIndex === -1) {
      console.error('Entry not found for update:', id);
      return;
    }

    const updatedEntry: DiaryEntry = {
      ...entries[entryIndex],
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    const newEntries = [...entries];
    newEntries[entryIndex] = updatedEntry;
    const sortedEntries = sortEntries(newEntries);
    
    saveEntriesToStorage(sortedEntries);
    set({ entries: sortedEntries });
    
    console.log('Diary entry updated:', id);
  },

  deleteEntry: (id) => {
    const newEntries = get().entries.filter(e => e.id !== id);
    saveEntriesToStorage(newEntries);
    set({ entries: newEntries });
    console.log('Diary entry deleted:', id);
  },

  getEntryByDate: (dateKey: string) => {
    // Retorna a primeira entrada para essa data (a mais recente se houver múltiplas)
    return get().entries.find(e => e.dateKey === dateKey);
  },

  getEntryById: (id: string) => {
    return get().entries.find(e => e.id === id);
  },

  setSearchQuery: (query) => {
    set({ searchQuery: query });
  },

  countEntries: () => {
    return get().entries.length;
  },

  getFilteredEntries: () => {
    const { entries, searchQuery } = get();
    if (!searchQuery.trim()) return entries;

    const query = searchQuery.toLowerCase();
    return entries.filter(entry => 
      entry.title.toLowerCase().includes(query) ||
      entry.content.toLowerCase().includes(query)
    );
  },
}));
