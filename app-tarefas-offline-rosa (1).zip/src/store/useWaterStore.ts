import { create } from 'zustand';

export interface WaterEntry {
  id: string;
  amount: number; // in ml
  time: string; // HH:mm
  date: string; // YYYY-MM-DD
  createdAt: string;
}

interface WaterState {
  entries: WaterEntry[];
  dailyGoal: number; // in ml
  isLoading: boolean;
  
  // Actions
  initialize: () => void;
  addWater: (amount: number) => void;
  removeEntry: (id: string) => void;
  setDailyGoal: (goal: number) => void;
  getTodayTotal: () => number;
  getTodayEntries: () => WaterEntry[];
  getEntriesForDate: (date: string) => WaterEntry[];
  getTotalForDate: (date: string) => number;
  getWeekData: () => { date: string; total: number; goal: number }[];
}

const STORAGE_KEY = 'vida-rosa-water-entries';
const SETTINGS_KEY = 'vida-rosa-water-settings';

const getToday = () => new Date().toISOString().split('T')[0];
const getCurrentTime = () => new Date().toTimeString().slice(0, 5);

const loadFromStorage = (): WaterEntry[] => {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
};

const saveToStorage = (entries: WaterEntry[]) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
};

const loadSettings = (): { dailyGoal: number } => {
  try {
    const data = localStorage.getItem(SETTINGS_KEY);
    return data ? JSON.parse(data) : { dailyGoal: 2000 };
  } catch {
    return { dailyGoal: 2000 };
  }
};

const saveSettings = (settings: { dailyGoal: number }) => {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
};

export const useWaterStore = create<WaterState>((set, get) => ({
  entries: [],
  dailyGoal: 2000,
  isLoading: false, // Start as false since localStorage is synchronous
  
  initialize: () => {
    const entries = loadFromStorage();
    const settings = loadSettings();
    set({ entries, dailyGoal: settings.dailyGoal, isLoading: false });
  },
  
  addWater: (amount: number) => {
    const entry: WaterEntry = {
      id: crypto.randomUUID(),
      amount,
      time: getCurrentTime(),
      date: getToday(),
      createdAt: new Date().toISOString(),
    };
    
    const newEntries = [...get().entries, entry];
    saveToStorage(newEntries);
    set({ entries: newEntries });
  },
  
  removeEntry: (id: string) => {
    const newEntries = get().entries.filter(e => e.id !== id);
    saveToStorage(newEntries);
    set({ entries: newEntries });
  },
  
  setDailyGoal: (goal: number) => {
    saveSettings({ dailyGoal: goal });
    set({ dailyGoal: goal });
  },
  
  getTodayTotal: () => {
    const today = getToday();
    return get().entries
      .filter(e => e.date === today)
      .reduce((sum, e) => sum + e.amount, 0);
  },
  
  getTodayEntries: () => {
    const today = getToday();
    return get().entries
      .filter(e => e.date === today)
      .sort((a, b) => b.time.localeCompare(a.time));
  },
  
  getEntriesForDate: (date: string) => {
    return get().entries
      .filter(e => e.date === date)
      .sort((a, b) => b.time.localeCompare(a.time));
  },
  
  getTotalForDate: (date: string) => {
    return get().entries
      .filter(e => e.date === date)
      .reduce((sum, e) => sum + e.amount, 0);
  },
  
  getWeekData: () => {
    const data = [];
    const goal = get().dailyGoal;
    
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      const total = get().getTotalForDate(dateStr);
      data.push({ date: dateStr, total, goal });
    }
    
    return data;
  },
}));
