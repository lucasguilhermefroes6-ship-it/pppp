import { useState } from 'react';
import { Screen } from '../types/screens';
import { useFinanceStore } from '../store/useFinanceStore';

interface FinanceStatsScreenProps {
  onNavigate: (screen: Screen) => void;
}

// Cores padrão por categoria
const DEFAULT_CATEGORY_COLORS: Record<string, string> = {
  'Alimentação': '#FF7043',
  'Transporte': '#42A5F5',
  'Moradia': '#AB47BC',
  'Saúde': '#66BB6A',
  'Educação': '#FFA726',
  'Lazer': '#EC407A',
  'Vestuário': '#7E57C2',
  'Contas': '#26A69A',
  'Outros': '#BDBDBD'
};

// Ícones padrão por categoria
const DEFAULT_CATEGORY_ICONS: Record<string, string> = {
  'Alimentação': '🍔',
  'Transporte': '🚗',
  'Moradia': '🏠',
  'Saúde': '💊',
  'Educação': '📚',
  'Lazer': '🎮',
  'Vestuário': '👕',
  'Contas': '📄',
  'Outros': '📦'
};

const MONTHS = [
  'janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho',
  'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'
];

const MONTHS_SHORT = [
  'jan', 'fev', 'mar', 'abr', 'mai', 'jun',
  'jul', 'ago', 'set', 'out', 'nov', 'dez'
];

export default function FinanceStatsScreen({ onNavigate }: FinanceStatsScreenProps) {
  const { transactions, customCategories } = useFinanceStore();
  const [selectedDate, setSelectedDate] = useState(new Date());

  // Função para obter a cor de uma categoria (personalizada ou padrão)
  const getCategoryColor = (categoryName: string): string => {
    // Primeiro verifica se é uma categoria personalizada
    const customCategory = customCategories.find(c => c.name === categoryName);
    if (customCategory) {
      return customCategory.color;
    }
    // Se não, usa a cor padrão
    return DEFAULT_CATEGORY_COLORS[categoryName] || '#9E9E9E';
  };

  // Função para obter o ícone de uma categoria (personalizada ou padrão)
  const getCategoryIcon = (categoryName: string): string => {
    // Categorias personalizadas usam ícone genérico
    const customCategory = customCategories.find(c => c.name === categoryName);
    if (customCategory) {
      return '🏷️';
    }
    // Se não, usa o ícone padrão
    return DEFAULT_CATEGORY_ICONS[categoryName] || '📦';
  };

  const currentMonth = selectedDate.getMonth();
  const currentYear = selectedDate.getFullYear();

  // Navegação de mês
  const prevMonth = () => {
    setSelectedDate(new Date(currentYear, currentMonth - 1, 1));
  };

  const nextMonth = () => {
    setSelectedDate(new Date(currentYear, currentMonth + 1, 1));
  };

  // Filtrar transações do mês
  const monthTransactions = transactions.filter(t => {
    const date = new Date(t.date);
    return date.getMonth() === currentMonth && date.getFullYear() === currentYear;
  });

  // Calcular totais
  const totalIncome = monthTransactions
    .filter(t => t.type === 'INCOME')
    .reduce((sum, t) => sum + t.amountCents, 0);

  const totalExpense = monthTransactions
    .filter(t => t.type === 'EXPENSE')
    .reduce((sum, t) => sum + t.amountCents, 0);

  // Gastos por categoria
  const expensesByCategory: Record<string, number> = {};
  monthTransactions
    .filter(t => t.type === 'EXPENSE')
    .forEach(t => {
      expensesByCategory[t.category] = (expensesByCategory[t.category] || 0) + t.amountCents;
    });

  // Top categorias ordenadas
  const topCategories = Object.entries(expensesByCategory)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5);

  const maxCategoryValue = topCategories.length > 0 ? topCategories[0][1] : 0;

  // Evolução dos últimos 6 meses
  const monthlyEvolution = [];
  for (let i = 5; i >= 0; i--) {
    const date = new Date(currentYear, currentMonth - i, 1);
    const month = date.getMonth();
    const year = date.getFullYear();
    
    const monthExpenses = transactions
      .filter(t => {
        const tDate = new Date(t.date);
        return tDate.getMonth() === month && tDate.getFullYear() === year && t.type === 'EXPENSE';
      })
      .reduce((sum, t) => sum + t.amountCents, 0);
    
    monthlyEvolution.push({
      month: MONTHS_SHORT[month],
      year,
      value: monthExpenses,
      isCurrentMonth: month === currentMonth && year === currentYear
    });
  }

  const maxMonthlyValue = Math.max(...monthlyEvolution.map(m => m.value), 1);

  // Formatar valor
  const formatCurrency = (cents: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(cents / 100);
  };

  // Calcular porcentagem para o gráfico de pizza
  const totalExpenseForPie = Object.values(expensesByCategory).reduce((a, b) => a + b, 0);

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#FFF5F8' }}>
      {/* Header - Rosa Magenta com Gradiente */}
      <div 
        className="px-5 pt-12 pb-6"
        style={{ 
          background: 'linear-gradient(135deg, #EC4899 0%, #DB2777 50%, #BE185D 100%)'
        }}
      >
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() => onNavigate({ name: 'home' })}
            className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center"
          >
            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          
          <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
            <span className="text-lg">📊</span>
          </div>
        </div>

        <h1 className="text-3xl font-bold text-white">
          Estatísticas
        </h1>
        <p className="text-sm mt-1 text-white/80">
          Análises detalhadas das suas finanças
        </p>
      </div>

      <div className="px-5 pb-8 space-y-5">
        {/* Seletor de Mês */}
        <div 
          className="flex items-center justify-center gap-4 py-3 px-4 rounded-2xl bg-white"
          style={{ 
            border: '1.5px solid #F3C6D6',
            boxShadow: '0 2px 8px rgba(233, 30, 99, 0.08)'
          }}
        >
          <button
            onClick={prevMonth}
            className="w-9 h-9 rounded-full flex items-center justify-center"
            style={{ backgroundColor: '#FCE4EC' }}
          >
            <svg className="w-5 h-5" fill="none" stroke="#E91E63" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          
          <span className="text-lg font-semibold capitalize min-w-[180px] text-center" style={{ color: '#2B1B2B' }}>
            {MONTHS[currentMonth]} {currentYear}
          </span>
          
          <button
            onClick={nextMonth}
            className="w-9 h-9 rounded-full flex items-center justify-center"
            style={{ backgroundColor: '#FCE4EC' }}
          >
            <svg className="w-5 h-5" fill="none" stroke="#E91E63" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>

        {/* Cards Receitas e Despesas */}
        <div className="grid grid-cols-2 gap-4">
          {/* Receitas */}
          <div 
            className="p-4 rounded-2xl bg-white"
            style={{ 
              border: '1.5px solid #C8E6C9',
              boxShadow: '0 2px 8px rgba(76, 175, 80, 0.1)'
            }}
          >
            <div className="flex items-center gap-2 mb-2">
              <div 
                className="w-8 h-8 rounded-lg flex items-center justify-center"
                style={{ backgroundColor: '#E8F5E9' }}
              >
                <svg className="w-4 h-4" fill="none" stroke="#4CAF50" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
                </svg>
              </div>
              <span className="text-sm font-medium" style={{ color: '#666' }}>Receitas</span>
            </div>
            <p className="text-xl font-bold" style={{ color: '#4CAF50' }}>
              {formatCurrency(totalIncome)}
            </p>
          </div>

          {/* Despesas */}
          <div 
            className="p-4 rounded-2xl bg-white"
            style={{ 
              border: '1.5px solid #FFCDD2',
              boxShadow: '0 2px 8px rgba(244, 67, 54, 0.1)'
            }}
          >
            <div className="flex items-center gap-2 mb-2">
              <div 
                className="w-8 h-8 rounded-lg flex items-center justify-center"
                style={{ backgroundColor: '#FFEBEE' }}
              >
                <svg className="w-4 h-4" fill="none" stroke="#F44336" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                </svg>
              </div>
              <span className="text-sm font-medium" style={{ color: '#666' }}>Despesas</span>
            </div>
            <p className="text-xl font-bold" style={{ color: '#F44336' }}>
              {formatCurrency(totalExpense)}
            </p>
          </div>
        </div>

        {/* Saldo */}
        <div 
          className="p-4 rounded-2xl bg-white"
          style={{ 
            border: '1.5px solid #BBDEFB',
            boxShadow: '0 2px 8px rgba(33, 150, 243, 0.1)'
          }}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div 
                className="w-8 h-8 rounded-lg flex items-center justify-center"
                style={{ backgroundColor: '#E3F2FD' }}
              >
                <svg className="w-4 h-4" fill="none" stroke="#2196F3" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                </svg>
              </div>
              <span className="text-sm font-medium" style={{ color: '#666' }}>Saldo do Mês</span>
            </div>
            <p className="text-xl font-bold" style={{ color: totalIncome - totalExpense >= 0 ? '#4CAF50' : '#F44336' }}>
              {formatCurrency(totalIncome - totalExpense)}
            </p>
          </div>
        </div>

        {/* Distribuição de Gastos */}
        <div 
          className="p-5 rounded-2xl bg-white"
          style={{ 
            border: '2px solid #F5D46A',
            boxShadow: '0 4px 12px rgba(245, 212, 106, 0.2)'
          }}
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold" style={{ color: '#2B1B2B' }}>
              Distribuição de Gastos
            </h3>
            <span className="text-xl">📊</span>
          </div>

          {totalExpenseForPie > 0 ? (
            <>
              {/* Gráfico de Donut */}
              <div className="flex justify-center mb-5">
                <div className="relative w-52 h-52">
                  <svg viewBox="0 0 100 100" className="transform -rotate-90">
                    {(() => {
                      let currentAngle = 0;
                      const categories = Object.entries(expensesByCategory).sort(([,a], [,b]) => b - a);
                      const outerRadius = 45;
                      const innerRadius = 28;
                      
                      return categories.map(([category, value]) => {
                        const percentage = value / totalExpenseForPie;
                        const angle = percentage * 360;
                        const largeArcFlag = angle > 180 ? 1 : 0;
                        
                        // Outer arc
                        const outerStartX = 50 + outerRadius * Math.cos((currentAngle * Math.PI) / 180);
                        const outerStartY = 50 + outerRadius * Math.sin((currentAngle * Math.PI) / 180);
                        const outerEndX = 50 + outerRadius * Math.cos(((currentAngle + angle) * Math.PI) / 180);
                        const outerEndY = 50 + outerRadius * Math.sin(((currentAngle + angle) * Math.PI) / 180);
                        
                        // Inner arc
                        const innerStartX = 50 + innerRadius * Math.cos(((currentAngle + angle) * Math.PI) / 180);
                        const innerStartY = 50 + innerRadius * Math.sin(((currentAngle + angle) * Math.PI) / 180);
                        const innerEndX = 50 + innerRadius * Math.cos((currentAngle * Math.PI) / 180);
                        const innerEndY = 50 + innerRadius * Math.sin((currentAngle * Math.PI) / 180);
                        
                        const path = `
                          M ${outerStartX} ${outerStartY}
                          A ${outerRadius} ${outerRadius} 0 ${largeArcFlag} 1 ${outerEndX} ${outerEndY}
                          L ${innerStartX} ${innerStartY}
                          A ${innerRadius} ${innerRadius} 0 ${largeArcFlag} 0 ${innerEndX} ${innerEndY}
                          Z
                        `;
                        
                        currentAngle += angle;
                        
                        return (
                          <path
                            key={category}
                            d={path}
                            fill={getCategoryColor(category)}
                          />
                        );
                      });
                    })()}
                  </svg>
                  {/* Total no centro do donut */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-xs font-medium" style={{ color: '#7A5A73' }}>Total</p>
                      <p className="text-lg font-bold" style={{ color: '#DB2777' }}>
                        {formatCurrency(totalExpenseForPie)}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Legenda */}
              <div className="space-y-2">
                {Object.entries(expensesByCategory)
                  .sort(([,a], [,b]) => b - a)
                  .map(([category, value]) => (
                    <div key={category} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: getCategoryColor(category) }}
                        />
                        <span className="text-sm" style={{ color: '#666' }}>
                          {getCategoryIcon(category)} {category}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium" style={{ color: '#2B1B2B' }}>
                          {formatCurrency(value)}
                        </span>
                        <span className="text-xs px-2 py-0.5 rounded-full" style={{ backgroundColor: '#FCE4EC', color: '#E91E63' }}>
                          {Math.round((value / totalExpenseForPie) * 100)}%
                        </span>
                      </div>
                    </div>
                  ))}
              </div>
            </>
          ) : (
            <div className="py-8 text-center">
              <span className="text-4xl mb-3 block">📭</span>
              <p className="text-sm" style={{ color: '#7A5A73' }}>
                Sem despesas neste mês
              </p>
            </div>
          )}
        </div>

        {/* Top Categorias */}
        <div 
          className="p-5 rounded-2xl bg-white"
          style={{ 
            border: '2px solid #F5D46A',
            boxShadow: '0 4px 12px rgba(245, 212, 106, 0.2)'
          }}
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold" style={{ color: '#2B1B2B' }}>
              Top Categorias
            </h3>
            <span className="text-xl">🏆</span>
          </div>

          {topCategories.length > 0 ? (
            <div className="space-y-4">
              {topCategories.map(([category, value], index) => (
                <div key={category}>
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <span className="text-lg font-bold" style={{ color: getCategoryColor(category) }}>
                        {index + 1}º
                      </span>
                      <span className="text-sm" style={{ color: '#666' }}>
                        {getCategoryIcon(category)} {category}
                      </span>
                    </div>
                    <span className="text-sm font-bold" style={{ color: '#2B1B2B' }}>
                      {formatCurrency(value)}
                    </span>
                  </div>
                  <div 
                    className="h-2 rounded-full overflow-hidden"
                    style={{ backgroundColor: '#F5F5F5' }}
                  >
                    <div 
                      className="h-full rounded-full transition-all duration-500"
                      style={{ 
                        width: `${(value / maxCategoryValue) * 100}%`,
                        backgroundColor: getCategoryColor(category)
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-8 text-center">
              <span className="text-4xl mb-3 block">📭</span>
              <p className="text-sm" style={{ color: '#7A5A73' }}>
                Sem dados neste mês
              </p>
            </div>
          )}
        </div>

        {/* Evolução Mensal */}
        <div 
          className="p-5 rounded-2xl bg-white"
          style={{ 
            border: '1.5px solid #F3C6D6',
            boxShadow: '0 2px 8px rgba(233, 30, 99, 0.08)'
          }}
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold" style={{ color: '#2B1B2B' }}>
              Evolução Mensal
            </h3>
            <span className="text-xl">📈</span>
          </div>

          {/* Container do gráfico com altura fixa */}
          <div className="flex items-end justify-between gap-2 mb-4" style={{ height: '140px' }}>
            {monthlyEvolution.map((month, index) => {
              // Calcular altura proporcional em pixels
              const maxHeight = 120; // altura máxima da barra em pixels
              const minHeight = 6; // altura mínima para valores > 0
              
              let barHeight: number;
              if (month.value === 0) {
                barHeight = 4; // barra mínima para zero
              } else if (maxMonthlyValue === 0) {
                barHeight = minHeight;
              } else {
                // Calcular proporcionalmente
                const ratio = month.value / maxMonthlyValue;
                barHeight = Math.max(ratio * maxHeight, minHeight);
              }
              
              return (
                <div key={index} className="flex-1 flex flex-col items-center justify-end h-full">
                  {/* Valor acima da barra */}
                  <span 
                    className="text-[10px] font-medium mb-1 text-center" 
                    style={{ color: month.isCurrentMonth ? '#E91E63' : '#666' }}
                  >
                    {month.value > 0 ? formatCurrency(month.value).replace('R$', '').trim() : '-'}
                  </span>
                  {/* Barra com altura calculada em pixels */}
                  <div 
                    className="w-full rounded-t-lg transition-all duration-500"
                    style={{ 
                      height: `${barHeight}px`,
                      backgroundColor: month.isCurrentMonth ? '#E91E63' : '#6AA9FF',
                      opacity: month.value === 0 ? 0.3 : 1
                    }}
                  />
                </div>
              );
            })}
          </div>

          {/* Labels dos meses */}
          <div className="flex justify-between">
            {monthlyEvolution.map((month, index) => (
              <div 
                key={index} 
                className="flex-1 text-center text-xs font-medium"
                style={{ color: month.isCurrentMonth ? '#E91E63' : '#666' }}
              >
                {month.month}
              </div>
            ))}
          </div>

          {/* Média */}
          <div 
            className="mt-4 p-3 rounded-xl flex items-center justify-between"
            style={{ backgroundColor: '#FFF5F8' }}
          >
            <span className="text-sm" style={{ color: '#666' }}>Média mensal:</span>
            <span className="text-sm font-bold" style={{ color: '#E91E63' }}>
              {formatCurrency(
                monthlyEvolution.reduce((sum, m) => sum + m.value, 0) / 
                monthlyEvolution.filter(m => m.value > 0).length || 0
              )}
            </span>
          </div>
        </div>

        {/* Card Resumo */}
        <div 
          className="p-5 rounded-2xl"
          style={{ 
            background: 'linear-gradient(135deg, #E91E63 0%, #F48FB1 100%)',
            boxShadow: '0 4px 12px rgba(233, 30, 99, 0.3)'
          }}
        >
          <div className="flex items-center gap-2 mb-3">
            <span className="text-xl">💡</span>
            <h3 className="text-lg font-bold text-white">Resumo do Mês</h3>
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between text-white/90">
              <span className="text-sm">Total de transações:</span>
              <span className="text-sm font-semibold">{monthTransactions.length}</span>
            </div>
            <div className="flex justify-between text-white/90">
              <span className="text-sm">Receitas:</span>
              <span className="text-sm font-semibold text-green-200">{formatCurrency(totalIncome)}</span>
            </div>
            <div className="flex justify-between text-white/90">
              <span className="text-sm">Despesas:</span>
              <span className="text-sm font-semibold text-red-200">{formatCurrency(totalExpense)}</span>
            </div>
            <div className="border-t border-white/20 pt-2 mt-2 flex justify-between text-white">
              <span className="text-sm font-medium">Saldo final:</span>
              <span className="text-lg font-bold">{formatCurrency(totalIncome - totalExpense)}</span>
            </div>
          </div>

          {/* Insight */}
          {topCategories.length > 0 && (
            <div className="mt-4 p-3 rounded-xl bg-white/20 text-white text-sm">
              💰 Sua maior despesa foi com <strong>{topCategories[0][0]}</strong>, 
              representando <strong>{Math.round((topCategories[0][1] / totalExpenseForPie) * 100)}%</strong> dos seus gastos.
            </div>
          )}
        </div>

        {/* Botões de ação - Rosa Magenta */}
        <div className="flex gap-3">
          <button
            onClick={() => onNavigate({ name: 'expenses' })}
            className="flex-1 py-3 rounded-xl text-sm font-semibold text-white"
            style={{ 
              background: 'linear-gradient(135deg, #EC4899 0%, #DB2777 100%)'
            }}
          >
            Ver Transações
          </button>
          <button
            onClick={() => onNavigate({ name: 'new-transaction' })}
            className="flex-1 py-3 rounded-xl text-sm font-semibold text-white"
            style={{ 
              background: 'linear-gradient(135deg, #DB2777 0%, #BE185D 100%)'
            }}
          >
            + Nova Transação
          </button>
        </div>
      </div>
    </div>
  );
}
