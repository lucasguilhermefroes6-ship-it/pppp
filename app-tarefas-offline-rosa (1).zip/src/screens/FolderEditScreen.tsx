import { useState, useEffect } from 'react';
import { 
  ArrowLeft, Check, Folder, Sparkles, Sun, Moon, GraduationCap,
  Briefcase, Home, ChefHat, Dumbbell, Wallet, Heart, Plane, BookOpen,
  Star, Music, Camera, Gift, Coffee, Flower2
} from 'lucide-react';
import { Screen } from '../types/screens';
import { useFolderStore } from '../store/useFolderStore';

interface FolderEditScreenProps {
  onNavigate: (screen: Screen) => void;
  folderId?: string;
}

// Cores disponíveis
const COLORS = [
  '#E91E63', '#F44336', '#FF9800', '#FFEB3B', '#4CAF50',
  '#009688', '#2196F3', '#3F51B5', '#9C27B0', '#795548',
];

// Ícones disponíveis
const ICONS = [
  { name: 'Folder', icon: Folder },
  { name: 'Sparkles', icon: Sparkles },
  { name: 'Sun', icon: Sun },
  { name: 'Moon', icon: Moon },
  { name: 'GraduationCap', icon: GraduationCap },
  { name: 'Briefcase', icon: Briefcase },
  { name: 'Home', icon: Home },
  { name: 'ChefHat', icon: ChefHat },
  { name: 'Dumbbell', icon: Dumbbell },
  { name: 'Wallet', icon: Wallet },
  { name: 'Heart', icon: Heart },
  { name: 'Plane', icon: Plane },
  { name: 'BookOpen', icon: BookOpen },
  { name: 'Star', icon: Star },
  { name: 'Music', icon: Music },
  { name: 'Camera', icon: Camera },
  { name: 'Gift', icon: Gift },
  { name: 'Coffee', icon: Coffee },
  { name: 'Flower2', icon: Flower2 },
];

export default function FolderEditScreen({ onNavigate, folderId }: FolderEditScreenProps) {
  const { getFolderById, createFolder, updateFolder } = useFolderStore();
  const existingFolder = folderId ? getFolderById(folderId) : null;
  
  const [name, setName] = useState(existingFolder?.name || '');
  const [description, setDescription] = useState(existingFolder?.description || '');
  const [colorHex, setColorHex] = useState(existingFolder?.colorHex || '#E91E63');
  const [iconName, setIconName] = useState(existingFolder?.iconName || 'Folder');
  
  const isEditing = !!existingFolder;
  const SelectedIcon = ICONS.find(i => i.name === iconName)?.icon || Folder;
  
  useEffect(() => {
    if (existingFolder) {
      setName(existingFolder.name);
      setDescription(existingFolder.description || '');
      setColorHex(existingFolder.colorHex);
      setIconName(existingFolder.iconName);
    }
  }, [existingFolder]);
  
  const handleSave = async () => {
    if (!name.trim()) {
      alert('Digite um nome para a pasta');
      return;
    }
    
    if (isEditing && folderId) {
      await updateFolder(folderId, { name, description, colorHex, iconName });
    } else {
      await createFolder({ name, description, colorHex, iconName });
    }
    
    onNavigate({ name: 'folders' });
  };
  
  return (
    <div className="min-h-screen bg-[#FFF5F8]">
      {/* Header */}
      <div className="bg-gradient-to-r from-pink-400 to-pink-500 pt-12 pb-6 px-4">
        <div className="flex items-center justify-between">
          <button 
            onClick={() => onNavigate({ name: 'folders' })}
            className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <h1 className="text-xl font-bold text-white font-['Poppins']">
            {isEditing ? 'Editar Pasta' : 'Nova Pasta'}
          </h1>
          <button 
            onClick={handleSave}
            className="bg-white text-pink-500 px-4 py-2 rounded-full font-semibold flex items-center gap-1"
          >
            <Check className="w-4 h-4" />
            Salvar
          </button>
        </div>
      </div>
      
      <div className="px-4 py-6">
        {/* Preview Card */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-pink-100 mb-6">
          <div className="flex items-center gap-4">
            <div 
              className="w-16 h-16 rounded-xl flex items-center justify-center"
              style={{ backgroundColor: `${colorHex}20` }}
            >
              <SelectedIcon className="w-8 h-8" style={{ color: colorHex }} />
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-800 font-['Poppins']">
                {name || 'Nome da pasta'}
              </h2>
              <p className="text-gray-500 text-sm">
                {description || 'Descrição opcional'}
              </p>
            </div>
          </div>
        </div>
        
        {/* Nome */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100 mb-4">
          <label className="text-lg font-bold text-gray-800 font-['Poppins'] mb-3 block">
            Nome da Pasta *
          </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Ex: Autocuidado, Estudos..."
            className="w-full px-4 py-3 rounded-xl border border-pink-200 focus:border-pink-400 focus:outline-none"
          />
        </div>
        
        {/* Descrição */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100 mb-4">
          <label className="text-lg font-bold text-gray-800 font-['Poppins'] mb-3 block">
            Descrição (opcional)
          </label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Uma breve descrição..."
            rows={2}
            className="w-full px-4 py-3 rounded-xl border border-pink-200 focus:border-pink-400 focus:outline-none resize-none"
          />
        </div>
        
        {/* Cor */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100 mb-4">
          <label className="text-lg font-bold text-gray-800 font-['Poppins'] mb-3 block">
            Cor
          </label>
          <div className="grid grid-cols-5 gap-3">
            {COLORS.map((color) => (
              <button
                key={color}
                onClick={() => setColorHex(color)}
                className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all ${
                  colorHex === color ? 'ring-2 ring-offset-2 ring-pink-500 scale-110' : ''
                }`}
                style={{ backgroundColor: color }}
              >
                {colorHex === color && <Check className="w-5 h-5 text-white" />}
              </button>
            ))}
          </div>
        </div>
        
        {/* Ícone */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
          <label className="text-lg font-bold text-gray-800 font-['Poppins'] mb-3 block">
            Ícone
          </label>
          <div className="grid grid-cols-5 gap-3">
            {ICONS.map(({ name: iName, icon: Icon }) => (
              <button
                key={iName}
                onClick={() => setIconName(iName)}
                className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all ${
                  iconName === iName 
                    ? 'bg-pink-100 ring-2 ring-pink-500' 
                    : 'bg-gray-50 hover:bg-pink-50'
                }`}
              >
                <Icon 
                  className="w-6 h-6" 
                  style={{ color: iconName === iName ? colorHex : '#6B7280' }} 
                />
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
