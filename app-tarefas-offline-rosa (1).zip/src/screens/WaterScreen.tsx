import { useEffect, useState } from 'react';
import { 
  ArrowLeft, Droplets, Plus, Minus, Target, 
  Trash2, Clock, TrendingUp, Award, Settings, Sparkles
} from 'lucide-react';
import { Screen } from '@/types/screens';
import { useWaterStore } from '@/store/useWaterStore';

interface WaterScreenProps {
  onNavigate: (screen: Screen) => void;
}

const quickAmounts = [100, 150, 200, 250, 300, 500];

const motivationalMessages = [
  "Continue assim! Seu corpo agradece 💖",
  "Cada gota conta! Você está no caminho certo 🌊",
  "Hidratação é autocuidado! ✨",
  "Você está radiante hoje! Continue bebendo água 💧",
  "Meta quase lá! Você consegue! 🎯",
];

export default function WaterScreen({ onNavigate }: WaterScreenProps) {
  const { 
    entries, dailyGoal, initialize, 
    addWater, removeEntry, setDailyGoal,
    getTodayTotal, getTodayEntries, getWeekData
  } = useWaterStore();
  
  const [customAmount, setCustomAmount] = useState(250);
  const [showSettings, setShowSettings] = useState(false);
  const [newGoal, setNewGoal] = useState(dailyGoal);
  
  useEffect(() => {
    initialize();
  }, [initialize]);
  
  useEffect(() => {
    setNewGoal(dailyGoal);
  }, [dailyGoal]);
  
  const todayTotal = getTodayTotal();
  const todayEntries = getTodayEntries();
  const weekData = getWeekData();
  const progress = Math.min((todayTotal / dailyGoal) * 100, 100);
  const remaining = Math.max(dailyGoal - todayTotal, 0);
  
  const goalReached = todayTotal >= dailyGoal;
  const randomMessage = motivationalMessages[Math.floor(Math.random() * motivationalMessages.length)];
  
  // Streak calculation
  const calculateStreak = () => {
    let streak = 0;
    const today = new Date();
    
    for (let i = 0; i < 30; i++) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      const total = entries
        .filter(e => e.date === dateStr)
        .reduce((sum, e) => sum + e.amount, 0);
      
      if (total >= dailyGoal) {
        streak++;
      } else if (i > 0) {
        break;
      }
    }
    
    return streak;
  };
  
  const streak = calculateStreak();
  
  const handleAddWater = async (amount: number) => {
    await addWater(amount);
  };
  
  const handleSaveGoal = async () => {
    await setDailyGoal(newGoal);
    setShowSettings(false);
  };
  
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr + 'T12:00:00');
    const days = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
    return days[date.getDay()];
  };
  
  // localStorage is synchronous, so no loading needed
  
  return (
    <div className="min-h-screen bg-[#FFF5F8]">
      {/* Header */}
      <div className="bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-300 px-4 pt-8 pb-6">
        <div className="flex items-center justify-between mb-4">
          <button 
            onClick={() => onNavigate({ name: 'home' })}
            className="w-10 h-10 bg-white/20 backdrop-blur rounded-xl flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <h1 className="text-xl font-bold text-white font-['Poppins']">Água</h1>
          <button 
            onClick={() => setShowSettings(true)}
            className="w-10 h-10 bg-white/20 backdrop-blur rounded-xl flex items-center justify-center"
          >
            <Settings className="w-5 h-5 text-white" />
          </button>
        </div>
        
        {/* Main Progress Circle */}
        <div className="flex flex-col items-center">
          <div className="relative w-48 h-48">
            {/* Background circle */}
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="96"
                cy="96"
                r="88"
                stroke="rgba(255,255,255,0.3)"
                strokeWidth="12"
                fill="none"
              />
              <circle
                cx="96"
                cy="96"
                r="88"
                stroke="white"
                strokeWidth="12"
                fill="none"
                strokeDasharray={2 * Math.PI * 88}
                strokeDashoffset={2 * Math.PI * 88 * (1 - progress / 100)}
                strokeLinecap="round"
                className="transition-all duration-500"
              />
            </svg>
            
            {/* Center content */}
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <Droplets className="w-8 h-8 text-white mb-1" />
              <span className="text-3xl font-bold text-white font-['Poppins']">
                {todayTotal}
              </span>
              <span className="text-white/80 text-sm">de {dailyGoal} ml</span>
            </div>
          </div>
          
          {/* Progress percentage */}
          <div className="mt-4 text-center">
            {goalReached ? (
              <div className="flex items-center gap-2 bg-white/20 backdrop-blur px-4 py-2 rounded-full">
                <Award className="w-5 h-5 text-yellow-300" />
                <span className="text-white font-semibold">Meta atingida! 🎉</span>
              </div>
            ) : (
              <p className="text-white/90">Faltam <span className="font-bold">{remaining} ml</span></p>
            )}
          </div>
        </div>
      </div>
      
      <div className="px-4 -mt-4 pb-8 space-y-4">
        {/* Quick Add Card */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
          <h3 className="text-sm font-semibold text-gray-700 mb-3 font-['Poppins']">Adicionar Água</h3>
          
          {/* Quick amounts */}
          <div className="grid grid-cols-3 gap-2 mb-4">
            {quickAmounts.map(amount => (
              <button
                key={amount}
                onClick={() => handleAddWater(amount)}
                className="bg-gradient-to-r from-cyan-50 to-blue-50 hover:from-cyan-100 hover:to-blue-100 
                  text-cyan-600 font-semibold py-3 rounded-xl transition-all flex flex-col items-center"
              >
                <Droplets className="w-4 h-4 mb-1" />
                <span>{amount} ml</span>
              </button>
            ))}
          </div>
          
          {/* Custom amount */}
          <div className="flex items-center gap-3 bg-gray-50 rounded-xl p-2">
            <button
              onClick={() => setCustomAmount(Math.max(50, customAmount - 50))}
              className="w-10 h-10 bg-white rounded-lg flex items-center justify-center shadow-sm"
            >
              <Minus className="w-4 h-4 text-gray-600" />
            </button>
            <div className="flex-1 text-center">
              <input
                type="number"
                value={customAmount}
                onChange={e => setCustomAmount(Number(e.target.value))}
                className="w-20 text-center text-lg font-bold text-gray-800 bg-transparent outline-none"
              />
              <span className="text-gray-500 ml-1">ml</span>
            </div>
            <button
              onClick={() => setCustomAmount(customAmount + 50)}
              className="w-10 h-10 bg-white rounded-lg flex items-center justify-center shadow-sm"
            >
              <Plus className="w-4 h-4 text-gray-600" />
            </button>
            <button
              onClick={() => handleAddWater(customAmount)}
              className="bg-gradient-to-r from-cyan-400 to-blue-500 text-white px-4 py-2 rounded-xl font-semibold"
            >
              Adicionar
            </button>
          </div>
        </div>
        
        {/* Stats Row */}
        <div className="grid grid-cols-3 gap-3">
          {/* Streak */}
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100 text-center">
            <div className="w-10 h-10 bg-orange-100 rounded-xl flex items-center justify-center mx-auto mb-2">
              <span className="text-xl">🔥</span>
            </div>
            <p className="text-2xl font-bold text-gray-800 font-['Poppins']">{streak}</p>
            <p className="text-xs text-gray-500">dias seguidos</p>
          </div>
          
          {/* Today */}
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100 text-center">
            <div className="w-10 h-10 bg-cyan-100 rounded-xl flex items-center justify-center mx-auto mb-2">
              <Droplets className="w-5 h-5 text-cyan-500" />
            </div>
            <p className="text-2xl font-bold text-gray-800 font-['Poppins']">{todayTotal}</p>
            <p className="text-xs text-gray-500">ml hoje</p>
          </div>
          
          {/* Goal */}
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100 text-center">
            <div className="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-2">
              <Target className="w-5 h-5 text-green-500" />
            </div>
            <p className="text-2xl font-bold text-gray-800 font-['Poppins']">{Math.round(progress)}%</p>
            <p className="text-xs text-gray-500">da meta</p>
          </div>
        </div>
        
        {/* Week Chart */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-gray-700 font-['Poppins']">Última Semana</h3>
            <TrendingUp className="w-4 h-4 text-cyan-500" />
          </div>
          
          <div className="flex items-end justify-between gap-2 h-32">
            {weekData.map((day, index) => {
              const dayProgress = Math.min((day.total / day.goal) * 100, 100);
              const isToday = day.date === new Date().toISOString().split('T')[0];
              
              return (
                <div key={index} className="flex-1 flex flex-col items-center">
                  <div className="w-full h-24 bg-gray-100 rounded-lg relative overflow-hidden">
                    <div 
                      className={`absolute bottom-0 left-0 right-0 transition-all duration-500 rounded-lg ${
                        dayProgress >= 100 
                          ? 'bg-gradient-to-t from-green-400 to-green-300' 
                          : 'bg-gradient-to-t from-cyan-400 to-blue-300'
                      }`}
                      style={{ height: `${dayProgress}%` }}
                    />
                    {dayProgress >= 100 && (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span className="text-lg">✓</span>
                      </div>
                    )}
                  </div>
                  <p className={`text-xs mt-2 ${isToday ? 'text-cyan-600 font-bold' : 'text-gray-500'}`}>
                    {formatDate(day.date)}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
        
        {/* Today's entries */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
          <h3 className="text-sm font-semibold text-gray-700 mb-3 font-['Poppins']">Registro de Hoje</h3>
          
          {todayEntries.length === 0 ? (
            <div className="text-center py-8">
              <Droplets className="w-12 h-12 text-gray-200 mx-auto mb-3" />
              <p className="text-gray-400">Nenhum registro hoje</p>
              <p className="text-sm text-gray-300">Adicione sua primeira água!</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {todayEntries.map(entry => (
                <div 
                  key={entry.id}
                  className="flex items-center justify-between bg-gray-50 rounded-xl p-3"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-cyan-100 rounded-lg flex items-center justify-center">
                      <Droplets className="w-4 h-4 text-cyan-500" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-800">{entry.amount} ml</p>
                      <p className="text-xs text-gray-500 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {entry.time}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => removeEntry(entry.id)}
                    className="w-8 h-8 bg-red-50 hover:bg-red-100 rounded-lg flex items-center justify-center transition-colors"
                  >
                    <Trash2 className="w-4 h-4 text-red-400" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
        
        {/* Motivational Card */}
        <div className="bg-gradient-to-r from-cyan-400 to-blue-500 rounded-2xl p-4 text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <p className="font-medium flex-1">{randomMessage}</p>
          </div>
        </div>
      </div>
      
      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 bg-black/50 flex items-end justify-center z-50">
          <div className="bg-white rounded-t-3xl w-full max-w-lg p-6 animate-slide-up">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-gray-800 font-['Poppins']">Configurações</h3>
              <button
                onClick={() => setShowSettings(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                ✕
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Meta diária (ml)
                </label>
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => setNewGoal(Math.max(500, newGoal - 250))}
                    className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center"
                  >
                    <Minus className="w-5 h-5 text-gray-600" />
                  </button>
                  <div className="flex-1 text-center">
                    <input
                      type="number"
                      value={newGoal}
                      onChange={e => setNewGoal(Number(e.target.value))}
                      className="w-full text-center text-2xl font-bold text-gray-800 bg-transparent outline-none"
                    />
                    <p className="text-sm text-gray-500">{(newGoal / 1000).toFixed(1)} litros</p>
                  </div>
                  <button
                    onClick={() => setNewGoal(newGoal + 250)}
                    className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center"
                  >
                    <Plus className="w-5 h-5 text-gray-600" />
                  </button>
                </div>
              </div>
              
              {/* Preset goals */}
              <div className="grid grid-cols-4 gap-2">
                {[1500, 2000, 2500, 3000].map(goal => (
                  <button
                    key={goal}
                    onClick={() => setNewGoal(goal)}
                    className={`py-2 rounded-xl text-sm font-medium transition-all ${
                      newGoal === goal 
                        ? 'bg-cyan-500 text-white' 
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {goal / 1000}L
                  </button>
                ))}
              </div>
              
              <button
                onClick={handleSaveGoal}
                className="w-full bg-gradient-to-r from-cyan-400 to-blue-500 text-white py-4 rounded-xl font-semibold"
              >
                Salvar
              </button>
            </div>
          </div>
        </div>
      )}
      
      <style>{`
        @keyframes slide-up {
          from { transform: translateY(100%); }
          to { transform: translateY(0); }
        }
        .animate-slide-up {
          animation: slide-up 0.3s ease-out;
        }
      `}</style>
    </div>
  );
}
