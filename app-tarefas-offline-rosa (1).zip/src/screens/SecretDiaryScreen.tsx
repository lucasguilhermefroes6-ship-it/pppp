import React, { useEffect, useState } from 'react';
import { Screen } from '../types/screens';
import { useSecretDiaryStore } from '../store/useSecretDiaryStore';

interface Props {
  setScreen: (screen: Screen) => void;
}

// Format date helper
const formatDate = (dateStr: string): string => {
  const date = new Date(dateStr + 'T12:00:00');
  return date.toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  });
};

const formatDateLong = (dateStr: string): string => {
  const date = new Date(dateStr + 'T12:00:00');
  return date.toLocaleDateString('pt-BR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });
};

const getRelativeTime = (dateStr: string): string => {
  const date = new Date(dateStr);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  if (diffDays === 0) return 'Hoje';
  if (diffDays === 1) return 'Ontem';
  if (diffDays < 7) return `${diffDays} dias atrás`;
  if (diffDays < 30) return `${Math.floor(diffDays / 7)} sem atrás`;
  return `${Math.floor(diffDays / 30)} mês atrás`;
};
// ==================== GATE SCREEN (PIN) ====================

export const SecretDiaryGateScreen: React.FC<Props> = ({ setScreen }) => {
  const {
    settings,
    loadSettings,
    createPin,
    verifyPin,
    isLocked,
    recordFailedAttempt,
    isUnlocked,
  } = useSecretDiaryStore();

  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [mode, setMode] = useState<'check' | 'create' | 'confirm'>('check');
  const [error, setError] = useState('');
  const [remainingTime, setRemainingTime] = useState(0);

  useEffect(() => {
    loadSettings();
  }, [loadSettings]);

  useEffect(() => {
    if (settings.hasPin) {
      if (isUnlocked) {
        setScreen({ name: 'secret-diary-home' });
      } else {
        setMode('check');
      }
    } else {
      setMode('create');
    }
  }, [settings.hasPin, isUnlocked, setScreen]);

  useEffect(() => {
    if (settings.lockedUntil) {
      const checkLock = () => {
        const remaining = Math.ceil((new Date(settings.lockedUntil!).getTime() - Date.now()) / 1000);
        if (remaining > 0) {
          setRemainingTime(remaining);
        } else {
          setRemainingTime(0);
        }
      };
      checkLock();
      const interval = setInterval(checkLock, 1000);
      return () => clearInterval(interval);
    }
  }, [settings.lockedUntil]);

  const handlePinInput = (digit: string) => {
    if (mode === 'create' && pin.length < 4) {
      setPin(prev => prev + digit);
    } else if (mode === 'confirm' && confirmPin.length < 4) {
      setConfirmPin(prev => prev + digit);
    } else if (mode === 'check' && pin.length < 4) {
      setPin(prev => prev + digit);
    }
    setError('');
  };

  const handleDelete = () => {
    if (mode === 'confirm') {
      setConfirmPin(prev => prev.slice(0, -1));
    } else {
      setPin(prev => prev.slice(0, -1));
    }
  };

  useEffect(() => {
    if (mode === 'create' && pin.length === 4) {
      setMode('confirm');
    } else if (mode === 'confirm' && confirmPin.length === 4) {
      if (pin === confirmPin) {
        createPin(pin);
        setScreen({ name: 'secret-diary-home' });
      } else {
        setError('As senhas não coincidem');
        setConfirmPin('');
      }
    } else if (mode === 'check' && pin.length === 4) {
      if (isLocked()) {
        setError(`Aguarde ${remainingTime}s`);
        setPin('');
      } else if (verifyPin(pin)) {
        setScreen({ name: 'secret-diary-home' });
      } else {
        setError('Senha incorreta');
        recordFailedAttempt();
        setPin('');
      }
    }
  }, [pin, confirmPin, mode, createPin, verifyPin, isLocked, recordFailedAttempt, remainingTime, setScreen]);

  const currentPin = mode === 'confirm' ? confirmPin : pin;

  const handleGoBack = () => {
    setScreen({ name: 'home' });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-pink-50 to-rose-100 flex flex-col">
      <div className="p-4 flex items-center">
        <button
          onClick={handleGoBack}
          className="w-12 h-12 rounded-full bg-white shadow-lg flex items-center justify-center hover:shadow-xl transition-all active:scale-95"
          style={{ boxShadow: '0 4px 15px rgba(233, 30, 99, 0.3)' }}
        >
          <svg className="w-6 h-6 text-pink-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        <h2 className="flex-1 text-center text-lg font-bold text-purple-700 font-['Poppins'] mr-12">
          Diário Secreto
        </h2>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center px-6 -mt-16">
        <div className="w-24 h-24 rounded-full bg-gradient-to-br from-purple-400 to-pink-500 flex items-center justify-center mb-6 shadow-lg">
          <span className="text-5xl">🔐</span>
        </div>

        <h1 className="text-2xl font-bold text-gray-800 mb-2 font-['Poppins']">
          Diário Secreto
        </h1>

        <p className="text-gray-600 text-center mb-8 font-['Poppins']">
          {mode === 'create' && 'Crie uma senha de 4 dígitos'}
          {mode === 'confirm' && 'Confirme sua senha'}
          {mode === 'check' && 'Digite sua senha para entrar'}
        </p>

        <div className="flex gap-4 mb-8">
          {[0, 1, 2, 3].map((i) => (
            <div
              key={i}
              className={`w-4 h-4 rounded-full transition-all ${
                i < currentPin.length
                  ? 'bg-pink-500 scale-110'
                  : 'bg-gray-300'
              }`}
            />
          ))}
        </div>

        {error && (
          <p className="text-red-500 text-sm mb-4 font-['Poppins']">{error}</p>
        )}

        {remainingTime > 0 && (
          <p className="text-orange-500 text-sm mb-4 font-['Poppins']">
            Aguarde {remainingTime} segundos
          </p>
        )}

        <div className="grid grid-cols-3 gap-4">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', '⌫'].map((key) => (
            <button
              key={key}
              onClick={() => {
                if (key === '⌫') handleDelete();
                else if (key) handlePinInput(key);
              }}
              disabled={remainingTime > 0 && mode === 'check'}
              className={`w-16 h-16 rounded-full flex items-center justify-center text-2xl font-semibold transition-all ${
                key === ''
                  ? 'invisible'
                  : key === '⌫'
                  ? 'bg-gray-200 text-gray-600 hover:bg-gray-300'
                  : 'bg-white text-gray-800 shadow-md hover:shadow-lg hover:scale-105'
              } disabled:opacity-50`}
            >
              {key}
            </button>
          ))}
        </div>

        {mode === 'confirm' && (
          <button
            onClick={() => {
              setMode('create');
              setPin('');
              setConfirmPin('');
            }}
            className="mt-6 text-pink-500 font-medium font-['Poppins']"
          >
            Voltar e criar nova senha
          </button>
        )}
      </div>
    </div>
  );
};
// ==================== HOME SCREEN (LIST) ====================

export const SecretDiaryHomeScreen: React.FC<Props> = ({ setScreen }) => {
  const {
    entries,
    isLoading,
    searchQuery,
    loadEntries,
    deleteEntry,
    setSearchQuery,
    getFilteredEntries,
    lock,
    getEntryByDate,
  } = useSecretDiaryStore();

  const [showSearch, setShowSearch] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  useEffect(() => {
    loadEntries();
  }, [loadEntries]);

  const filteredEntries = getFilteredEntries();
  const today = new Date().toISOString().split('T')[0];
  const todayEntry = getEntryByDate(today);

  const handleDelete = async (id: string) => {
    await deleteEntry(id);
    setConfirmDelete(null);
  };

  const handleNewEntry = () => {
    setScreen({ name: 'secret-diary-edit', createNew: true });
  };
  
  const handleContinueWriting = () => {
    if (todayEntry) {
      setScreen({ name: 'secret-diary-edit', entryId: todayEntry.id });
    } else {
      setScreen({ name: 'secret-diary-edit', createNew: true });
    }
  };

  const handleLock = () => {
    lock();
    setScreen({ name: 'secret-diary' });
  };

  const handleGoHome = () => {
    lock();
    setScreen({ name: 'home' });
  };

  const getPreview = (content: string): string => {
    return content.split('\n')[0]?.substring(0, 80) || 'Sem conteúdo';
  };

  return (
    <div className="min-h-screen bg-[#FFF5F8]">
      <div className="bg-gradient-to-br from-purple-200 via-pink-100 to-rose-100 p-6 pb-8">
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={handleGoHome}
            className="w-12 h-12 rounded-full bg-white shadow-lg flex items-center justify-center hover:shadow-xl transition-all active:scale-95"
            style={{ boxShadow: '0 4px 15px rgba(147, 51, 234, 0.3)' }}
          >
            <svg className="w-6 h-6 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          
          <div className="flex gap-2">
            <button
              onClick={handleLock}
              className="w-10 h-10 rounded-full bg-white/80 flex items-center justify-center shadow-sm"
              title="Bloquear diário"
            >
              <span className="text-purple-600 text-lg">🔒</span>
            </button>
            <button
              onClick={() => setShowSearch(!showSearch)}
              className="w-10 h-10 rounded-full bg-white/80 flex items-center justify-center shadow-sm"
            >
              <span className="text-purple-600 text-lg">🔍</span>
            </button>
            <button
              onClick={() => setScreen({ name: 'secret-diary-settings' })}
              className="w-10 h-10 rounded-full bg-white/80 flex items-center justify-center shadow-sm"
            >
              <span className="text-purple-600 text-lg">⚙️</span>
            </button>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-400 to-pink-500 flex items-center justify-center shadow-lg">
            <span className="text-3xl">📔</span>
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-800 font-['Poppins']">Diário Secreto</h1>
            <p className="text-purple-600 font-medium">{entries.length} registro{entries.length !== 1 ? 's' : ''}</p>
          </div>
        </div>

        {showSearch && (
          <div className="mt-4">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar no diário..."
              className="w-full px-4 py-3 rounded-xl bg-white border-2 border-purple-200 focus:border-purple-400 outline-none font-['Poppins']"
              autoFocus
            />
          </div>
        )}
      </div>

      <div className="p-4 -mt-4">
        {todayEntry && (
          <div 
            onClick={handleContinueWriting}
            className="bg-gradient-to-r from-purple-400 to-pink-400 rounded-2xl p-4 shadow-lg mb-3 cursor-pointer hover:shadow-xl transition-shadow"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/80 text-sm font-['Poppins']">Hoje</p>
                <h3 className="text-white font-bold text-lg font-['Poppins']">
                  Continuar escrevendo
                </h3>
                <p className="text-white/80 text-sm mt-1">
                  {todayEntry.title || 'Sem título'} • {formatDateLong(today)}
                </p>
              </div>
              <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
                <span className="text-2xl">✏️</span>
              </div>
            </div>
          </div>
        )}
        
        <div 
          onClick={handleNewEntry}
          className="bg-gradient-to-r from-pink-500 to-rose-500 rounded-2xl p-4 shadow-lg mb-4 cursor-pointer hover:shadow-xl transition-shadow"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white/80 text-sm font-['Poppins']">Novo registro</p>
              <h3 className="text-white font-bold text-lg font-['Poppins']">
                Criar novo diário
              </h3>
              <p className="text-white/80 text-sm mt-1">
                {formatDateLong(today)}
              </p>
            </div>
            <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
              <span className="text-2xl">➕</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3 mb-4">
          <div className="bg-white rounded-xl p-3 shadow-sm border border-purple-100 text-center">
            <span className="text-2xl">📝</span>
            <p className="text-lg font-bold text-gray-800 font-['Poppins']">{entries.length}</p>
            <p className="text-xs text-gray-500">Registros</p>
          </div>
          <div className="bg-white rounded-xl p-3 shadow-sm border border-purple-100 text-center">
            <span className="text-2xl">📅</span>
            <p className="text-lg font-bold text-gray-800 font-['Poppins']">
              {entries.filter(e => {
                const date = new Date(e.dateKey);
                const now = new Date();
                return date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear();
              }).length}
            </p>
            <p className="text-xs text-gray-500">Este mês</p>
          </div>
          <div className="bg-white rounded-xl p-3 shadow-sm border border-purple-100 text-center">
            <span className="text-2xl">🔐</span>
            <p className="text-lg font-bold text-gray-800 font-['Poppins']">100%</p>
            <p className="text-xs text-gray-500">Privado</p>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-4 shadow-sm border border-purple-100">
          <h2 className="font-bold text-gray-800 mb-3 font-['Poppins']">Histórico</h2>
          
          {isLoading ? (
            <div className="text-center py-8 text-gray-500">Carregando...</div>
          ) : filteredEntries.length === 0 ? (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-3xl">📔</span>
              </div>
              <p className="text-gray-500 font-['Poppins']">
                {searchQuery ? 'Nenhum resultado encontrado' : 'Nenhum registro ainda'}
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredEntries.map((entry) => (
                <div key={entry.id} className="relative">
                  <div
                    onClick={() => setScreen({ name: 'secret-diary-edit', entryId: entry.id })}
                    className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl p-4 cursor-pointer hover:from-purple-100 hover:to-pink-100 transition-colors"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-lg">📖</span>
                          <p className="text-sm text-purple-600 font-medium font-['Poppins']">
                            {formatDate(entry.dateKey)}
                          </p>
                          <span className="text-xs text-gray-400">
                            • {getRelativeTime(entry.updatedAt)}
                          </span>
                        </div>
                        <h3 className="font-bold text-gray-800 font-['Poppins']">
                          {entry.title || 'Sem título'}
                        </h3>
                        <p className="text-sm text-gray-600 line-clamp-2 mt-1">
                          {getPreview(entry.content)}
                        </p>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setConfirmDelete(entry.id);
                        }}
                        className="w-8 h-8 rounded-full hover:bg-white/50 flex items-center justify-center text-gray-400"
                      >
                        🗑️
                      </button>
                    </div>
                  </div>

                  {confirmDelete === entry.id && (
                    <div className="absolute inset-0 bg-white/95 rounded-xl flex items-center justify-center p-4">
                      <div className="text-center">
                        <p className="text-gray-700 mb-3 font-medium">Excluir este registro?</p>
                        <div className="flex gap-2 justify-center">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setConfirmDelete(null);
                            }}
                            className="px-4 py-2 rounded-lg bg-gray-100 text-gray-600"
                          >
                            Cancelar
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDelete(entry.id);
                            }}
                            className="px-4 py-2 rounded-lg bg-red-500 text-white"
                          >
                            Excluir
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <button
        onClick={handleNewEntry}
        className="fixed bottom-6 right-6 bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-4 rounded-full shadow-lg flex items-center gap-2 hover:shadow-xl transition-shadow font-['Poppins'] font-semibold"
      >
        <span className="text-xl">+</span>
        <span>Novo Diário</span>
      </button>
    </div>
  );
};
// ==================== EDIT SCREEN (CORRIGIDO!) ====================

interface EditProps {
  setScreen: (screen: Screen) => void;
  entryId?: string;
  createNew?: boolean;
}

export const SecretDiaryEditScreen: React.FC<EditProps> = ({ setScreen, entryId, createNew }) => {
  const { entries, createEntry, updateEntry, getEntryByDate, loadEntries } = useSecretDiaryStore();
  
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [dateKey, setDateKey] = useState(new Date().toISOString().split('T')[0]);
  const [isSaving, setIsSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [currentEntryId, setCurrentEntryId] = useState<string | null>(entryId || null);
  const [isInitialized, setIsInitialized] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  useEffect(() => {
    const init = async () => {
      await loadEntries();
      setIsInitialized(true);
    };
    init();
  }, [loadEntries]);

  useEffect(() => {
    if (!isInitialized) return;
    
    if (createNew) {
      console.log('📝 Criando novo diário - não carregar existente');
      setTitle('');
      setContent('');
      setDateKey(new Date().toISOString().split('T')[0]);
      setCurrentEntryId(null);
      return;
    }
    
    if (entryId) {
      const entry = entries.find(e => e.id === entryId);
      if (entry) {
        setTitle(entry.title);
        setContent(entry.content);
        setDateKey(entry.dateKey);
        setCurrentEntryId(entry.id);
      }
    }
  }, [entryId, entries, getEntryByDate, isInitialized, createNew]);

  const handleSave = async () => {
    if (!content.trim() && !title.trim()) {
      alert('Escreva algo antes de salvar!');
      return;
    }
    
    setIsSaving(true);
    
    try {
      if (currentEntryId) {
        await updateEntry(currentEntryId, { title, content, dateKey });
        console.log('✅ Atualizado:', currentEntryId);
      } else {
        const newEntry = await createEntry({ title, content, dateKey });
        console.log('✅ Criado novo:', newEntry);
        if (newEntry && newEntry.id) {
          setCurrentEntryId(newEntry.id);
        }
      }
      
      setLastSaved(new Date());
      setHasUnsavedChanges(false);
    } catch (error) {
      console.error('❌ Erro ao salvar:', error);
      alert('Erro ao salvar. Tente novamente.');
    } finally {
      setIsSaving(false);
    }
  };

  // ============================================================
  // AUTO-SAVE CORRIGIDO - Agora espera o primeiro save manual
  // ============================================================
  useEffect(() => {
    if (!isInitialized) return;
    if (!hasUnsavedChanges) return;
    if (!content.trim() && !title.trim()) return;
    
    // NÃO fazer auto-save se ainda não tem um ID
    // Isso evita criar entradas duplicadas automaticamente
    if (!currentEntryId) {
      console.log('⏸️ Auto-save pausado - aguardando primeiro save manual');
      return;
    }
    
    console.log('⏳ Auto-save agendado...');
    
    const timer = setTimeout(async () => {
      console.log('💾 Executando auto-save...');
      
      setIsSaving(true);
      
      try {
        // Só atualiza entradas existentes (nunca cria novas no auto-save)
        await updateEntry(currentEntryId, { title, content, dateKey });
        console.log('✅ Auto-save: atualizado', currentEntryId);
        
        setLastSaved(new Date());
        setHasUnsavedChanges(false);
      } catch (error) {
        console.error('❌ Erro no auto-save:', error);
      } finally {
        setIsSaving(false);
      }
    }, 5000); // 5 segundos - mais tempo para escrever tranquilamente

    return () => clearTimeout(timer);
  }, [title, content, hasUnsavedChanges, isInitialized, currentEntryId, dateKey, updateEntry]);

  return (
    <div className="min-h-screen bg-[#FFF5F8] flex flex-col">
      <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-4">
        <div className="flex items-center justify-between">
          <button
            onClick={() => setScreen({ name: 'secret-diary-home' })}
            className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center"
          >
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          
          <div className="flex items-center gap-2">
            {isSaving ? (
              <span className="text-white/80 text-sm font-['Poppins']">💾 Salvando...</span>
            ) : lastSaved ? (
              <span className="text-white/80 text-sm font-['Poppins']">✓ Salvo às {lastSaved.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</span>
            ) : null}
            
            <button
              onClick={handleSave}
              disabled={isSaving || (!content.trim() && !title.trim())}
              className="px-5 py-2 bg-white rounded-full text-pink-500 font-bold text-sm disabled:opacity-50 shadow-md hover:shadow-lg transition-all font-['Poppins']"
            >
              💾 Salvar
            </button>
          </div>
        </div>
      </div>

      <div className="p-4 -mt-2">
        <div className="bg-gradient-to-br from-purple-400 to-pink-500 rounded-2xl p-4 shadow-lg">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-xl bg-white/20 flex items-center justify-center">
              <span className="text-3xl">📔</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-white font-['Poppins']">
                Diário de {formatDate(dateKey)}
              </h1>
              <p className="text-white/80 text-sm">
                {currentEntryId ? '✓ Editando' : '✨ Novo registro'} • Privado
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 p-4 flex flex-col">
        <div className="mb-4">
          <input
            type="text"
            value={title}
            onChange={(e) => {
              setTitle(e.target.value);
              setHasUnsavedChanges(true);
            }}
            placeholder="Título do dia (opcional)"
            className="w-full text-xl font-bold text-gray-800 bg-transparent outline-none placeholder-gray-400 font-['Poppins']"
          />
        </div>

        <div className="bg-purple-50 rounded-xl p-3 mb-4">
          <p className="text-sm text-purple-700 font-['Poppins']">
            💭 O que aconteceu de especial hoje? Como você se sentiu?
          </p>
        </div>

        <textarea
          value={content}
          onChange={(e) => {
            setContent(e.target.value);
            setHasUnsavedChanges(true);
          }}
          placeholder="Querido diário..."
          className="flex-1 w-full min-h-[300px] text-gray-700 bg-white rounded-2xl p-4 outline-none resize-none placeholder-gray-400 font-['Poppins'] leading-relaxed shadow-sm border border-purple-100"
        />
        
        <p className="text-center text-gray-400 text-xs mt-3 font-['Poppins']">
          ✨ Clique em Salvar para criar. Depois, salva automaticamente a cada 5 segundos
        </p>
      </div>
    </div>
  );
};

// ==================== SETTINGS SCREEN ====================

export const SecretDiarySettingsScreen: React.FC<Props> = ({ setScreen }) => {
  const { settings, changePin, toggleBiometry, lock } = useSecretDiaryStore();
  
  const [showChangePin, setShowChangePin] = useState(false);
  const [oldPin, setOldPin] = useState('');
  const [newPin, setNewPin] = useState('');
  const [confirmNewPin, setConfirmNewPin] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleChangePin = () => {
    setError('');
    setSuccess('');

    if (newPin.length !== 4) {
      setError('A nova senha deve ter 4 dígitos');
      return;
    }

    if (newPin !== confirmNewPin) {
      setError('As senhas não coincidem');
      return;
    }

    if (changePin(oldPin, newPin)) {
      setSuccess('Senha alterada com sucesso!');
      setShowChangePin(false);
      setOldPin('');
      setNewPin('');
      setConfirmNewPin('');
    } else {
      setError('Senha atual incorreta');
    }
  };

  const handleLock = () => {
    lock();
    setScreen({ name: 'secret-diary' });
  };

  return (
    <div className="min-h-screen bg-[#FFF5F8]">
      <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-6">
        <div className="flex items-center gap-4">
          <button
            onClick={() => setScreen({ name: 'secret-diary-home' })}
            className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center"
          >
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <h1 className="text-xl font-bold text-white font-['Poppins']">Configurações</h1>
        </div>
      </div>

      <div className="p-4">
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-purple-100 mb-4">
          <h2 className="font-bold text-gray-800 mb-4 font-['Poppins'] flex items-center gap-2">
            <span>🔐</span> Segurança
          </h2>

          <button
            onClick={() => setShowChangePin(!showChangePin)}
            className="w-full flex items-center justify-between py-3 border-b border-gray-100"
          >
            <div className="flex items-center gap-3">
              <span className="text-xl">🔑</span>
              <span className="font-medium text-gray-700 font-['Poppins']">Alterar senha</span>
            </div>
            <span className="text-gray-400">{showChangePin ? '▲' : '▼'}</span>
          </button>

          {showChangePin && (
            <div className="py-4 space-y-3">
              <input
                type="password"
                value={oldPin}
                onChange={(e) => setOldPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                placeholder="Senha atual"
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-purple-400 outline-none font-['Poppins']"
                maxLength={4}
              />
              <input
                type="password"
                value={newPin}
                onChange={(e) => setNewPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                placeholder="Nova senha (4 dígitos)"
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-purple-400 outline-none font-['Poppins']"
                maxLength={4}
              />
              <input
                type="password"
                value={confirmNewPin}
                onChange={(e) => setConfirmNewPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                placeholder="Confirmar nova senha"
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-purple-400 outline-none font-['Poppins']"
                maxLength={4}
              />
              
              {error && <p className="text-red-500 text-sm">{error}</p>}
              {success && <p className="text-green-500 text-sm">{success}</p>}
              
              <button
                onClick={handleChangePin}
                className="w-full bg-purple-500 text-white py-3 rounded-xl font-semibold font-['Poppins']"
              >
                Salvar nova senha
              </button>
            </div>
          )}

          <div className="flex items-center justify-between py-3">
            <div className="flex items-center gap-3">
              <span className="text-xl">👆</span>
              <div>
                <span className="font-medium text-gray-700 font-['Poppins']">Biometria</span>
                <p className="text-xs text-gray-500">Face ID / Impressão digital</p>
              </div>
            </div>
            <button
              onClick={() => toggleBiometry()}
              className={`w-12 h-7 rounded-full transition-colors ${
                settings.biometryEnabled ? 'bg-purple-500' : 'bg-gray-300'
              }`}
            >
              <div className={`w-5 h-5 bg-white rounded-full shadow transition-transform ${
                settings.biometryEnabled ? 'translate-x-6' : 'translate-x-1'
              }`} />
            </button>
          </div>
        </div>

        <button
          onClick={handleLock}
          className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white py-4 rounded-2xl font-semibold font-['Poppins'] shadow-lg flex items-center justify-center gap-2"
        >
          <span>🔒</span>
          <span>Bloquear Agora</span>
        </button>

        <div className="mt-6 bg-purple-50 rounded-2xl p-4">
          <h3 className="font-bold text-purple-700 mb-2 font-['Poppins']">💡 Dica de segurança</h3>
          <p className="text-sm text-purple-600 font-['Poppins']">
            Seus dados são armazenados localmente no seu dispositivo e protegidos por senha. 
            Ninguém além de você tem acesso ao conteúdo do seu diário.
          </p>
        </div>
      </div>
    </div>
  );
};