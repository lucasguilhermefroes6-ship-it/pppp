import { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  Plus, 
  Target, 
  Flame, 
  Trophy,
  TrendingUp,
  Calendar,
  RotateCcw,
  Check,
  Minus,
  Settings,
  Trash2
} from 'lucide-react';
import { useGoalStore } from '@/store/useGoalStore';
import { Goal, GoalType } from '@/types';
import { Screen } from '@/types/screens';

interface GoalsScreenProps {
  onNavigate: (screen: Screen) => void;
}

// ========== GOAL CARD COMPONENT ==========
const GoalCard = ({ 
  goalId, 
  onEdit,
  onDelete 
}: { 
  goalId: string; 
  onEdit: (goal: Goal) => void;
  onDelete: (goalId: string) => void;
}) => {
  const { getGoalWithStats, incrementProgress, decrementProgress } = useGoalStore();
  const stats = getGoalWithStats(goalId);
  
  if (!stats) return null;
  
  const { goal, progress, streak, percentage } = stats;
  const currentCount = progress?.count || 0;
  const isCompleted = goal.type === 'OBJECTIVE' 
    ? (goal.totalProgress || 0) >= (goal.totalTarget || 1)
    : currentCount >= goal.targetCount;
  
  const periodLabels = {
    DAILY: 'hoje',
    WEEKLY: 'esta semana',
    MONTHLY: 'este mês'
  };
  
  const getIconBgColor = () => {
    switch (goal.color) {
      case 'blue': return 'from-blue-400 to-blue-500';
      case 'green': return 'from-emerald-400 to-emerald-500';
      case 'purple': return 'from-purple-400 to-purple-500';
      case 'orange': return 'from-orange-400 to-orange-500';
      case 'pink': return 'from-pink-400 to-pink-500';
      default: return 'from-pink-400 to-pink-500';
    }
  };
  
  const getProgressBarColor = () => {
    if (isCompleted) return 'bg-emerald-500';
    if (percentage >= 50) return 'bg-blue-500';
    return 'bg-pink-500';
  };
  
  const iconMap: Record<string, React.ReactNode> = {
    target: <Target className="w-6 h-6 text-white" />,
    flame: <Flame className="w-6 h-6 text-white" />,
    trophy: <Trophy className="w-6 h-6 text-white" />,
    trending: <TrendingUp className="w-6 h-6 text-white" />,
    calendar: <Calendar className="w-6 h-6 text-white" />,
    rotate: <RotateCcw className="w-6 h-6 text-white" />
  };
  
  return (
    <div className={`bg-white rounded-2xl p-4 shadow-sm border ${isCompleted ? 'border-emerald-200' : 'border-pink-100'} transition-all`}>
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${getIconBgColor()} flex items-center justify-center shadow-sm`}>
            {iconMap[goal.icon] || <Target className="w-6 h-6 text-white" />}
          </div>
          <div>
            <h3 className="font-semibold text-gray-800">{goal.title}</h3>
            <p className="text-xs text-gray-500">
              {goal.type === 'HABIT' ? '🔄 Hábito' : '🎯 Objetivo'} • {periodLabels[goal.renewalPeriod]}
            </p>
          </div>
        </div>
        
        {/* Streak Badge */}
        {streak.current > 0 && (
          <div className="flex items-center gap-1 bg-gradient-to-r from-orange-100 to-orange-200 text-orange-600 px-2 py-1 rounded-full">
            <Flame className="w-4 h-4" />
            <span className="text-xs font-bold">{streak.current}</span>
          </div>
        )}
      </div>
      
      {/* Description */}
      {goal.description && (
        <p className="text-sm text-gray-600 mb-3 line-clamp-2">{goal.description}</p>
      )}
      
      {/* Progress */}
      <div className="mb-3">
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs text-gray-500">
            {goal.type === 'OBJECTIVE' 
              ? `${goal.totalProgress || 0}/${goal.totalTarget} total`
              : `${currentCount}/${goal.targetCount} ${periodLabels[goal.renewalPeriod]}`
            }
          </span>
          <span className="text-xs font-semibold text-pink-600">{Math.round(percentage)}%</span>
        </div>
        <div className="w-full bg-gray-100 rounded-full h-2.5">
          <div 
            className={`h-2.5 rounded-full transition-all duration-500 ${getProgressBarColor()}`}
            style={{ width: `${percentage}%` }}
          />
        </div>
      </div>
      
      {/* Completed Badge */}
      {isCompleted && (
        <div className="flex items-center gap-2 bg-emerald-50 text-emerald-600 px-3 py-2 rounded-xl mb-3">
          <Check className="w-5 h-5" />
          <span className="text-sm font-medium">
            {goal.type === 'OBJECTIVE' ? '🎉 Objetivo concluído!' : '✨ Feito ' + periodLabels[goal.renewalPeriod] + '!'}
          </span>
        </div>
      )}
      
      {/* Actions */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button
            onClick={() => decrementProgress(goal.id)}
            disabled={currentCount === 0 && goal.type === 'HABIT'}
            className="w-10 h-10 rounded-xl bg-gray-100 hover:bg-gray-200 flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <Minus className="w-5 h-5 text-gray-600" />
          </button>
          
          <button
            onClick={() => incrementProgress(goal.id)}
            disabled={isCompleted && goal.type === 'OBJECTIVE'}
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
              isCompleted && goal.type !== 'OBJECTIVE'
                ? 'bg-emerald-500 text-white'
                : 'bg-pink-500 hover:bg-pink-600 text-white'
            } disabled:opacity-50 disabled:cursor-not-allowed`}
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>
        
        <div className="flex items-center gap-2">
          <button
            onClick={() => onEdit(goal)}
            className="w-10 h-10 rounded-xl bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition-colors"
          >
            <Settings className="w-5 h-5 text-gray-600" />
          </button>
          <button
            onClick={() => onDelete(goal.id)}
            className="w-10 h-10 rounded-xl bg-red-50 hover:bg-red-100 flex items-center justify-center transition-colors"
          >
            <Trash2 className="w-5 h-5 text-red-500" />
          </button>
        </div>
      </div>
      
      {/* Best Streak */}
      {streak.best > 0 && (
        <div className="mt-3 pt-3 border-t border-gray-100 flex items-center gap-2 text-xs text-gray-500">
          <Trophy className="w-4 h-4 text-yellow-500" />
          <span>Melhor sequência: <strong className="text-gray-700">{streak.best} dias</strong></span>
        </div>
      )}
    </div>
  );
};

// ========== STATS HEADER ==========
const StatsHeader = () => {
  const { goals, getActiveGoalsCount, getTodayCompletedCount } = useGoalStore();
  
  const activeCount = getActiveGoalsCount();
  const completedToday = getTodayCompletedCount();
  const totalStreak = goals.reduce((sum, g) => sum + g.currentStreak, 0);
  
  return (
    <div className="grid grid-cols-3 gap-3 mb-6">
      <div className="bg-gradient-to-br from-pink-50 to-pink-100 rounded-2xl p-4 text-center border border-pink-200">
        <div className="text-2xl font-bold text-pink-600">{activeCount}</div>
        <div className="text-xs text-pink-500">Metas Ativas</div>
      </div>
      <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 rounded-2xl p-4 text-center border border-emerald-200">
        <div className="text-2xl font-bold text-emerald-600">{completedToday}</div>
        <div className="text-xs text-emerald-500">Feitas Hoje</div>
      </div>
      <div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-2xl p-4 text-center border border-orange-200">
        <div className="flex items-center justify-center gap-1">
          <Flame className="w-5 h-5 text-orange-500" />
          <span className="text-2xl font-bold text-orange-600">{totalStreak}</span>
        </div>
        <div className="text-xs text-orange-500">Streak Total</div>
      </div>
    </div>
  );
};

// ========== MAIN SCREEN ==========
export default function GoalsScreen({ onNavigate }: GoalsScreenProps) {
  const { goals, isLoading, initialize, deleteGoal } = useGoalStore();
  const [showForm, setShowForm] = useState(false);
  const [editingGoal, setEditingGoal] = useState<Goal | null>(null);
  const [filter, setFilter] = useState<'all' | 'habit' | 'objective'>('all');
  
  useEffect(() => {
    initialize();
  }, [initialize]);
  
  const filteredGoals = goals.filter(g => {
    if (filter === 'habit') return g.type === 'HABIT';
    if (filter === 'objective') return g.type === 'OBJECTIVE';
    return true;
  }).filter(g => g.isActive);
  
  const handleEdit = (goal: Goal) => {
    setEditingGoal(goal);
    setShowForm(true);
  };
  
  const handleDelete = async (goalId: string) => {
    if (confirm('Tem certeza que deseja excluir esta meta?')) {
      await deleteGoal(goalId);
    }
  };
  
  const handleFormClose = () => {
    setShowForm(false);
    setEditingGoal(null);
  };
  
  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#FFF5F8] flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-pink-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-[#FFF5F8]">
      {/* Header */}
      <div className="bg-gradient-to-b from-pink-100 to-[#FFF5F8] px-4 pt-4 pb-6">
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() => onNavigate({ name: 'home' })}
            className="w-10 h-10 rounded-xl bg-white/80 flex items-center justify-center shadow-sm"
          >
            <ArrowLeft className="w-5 h-5 text-pink-600" />
          </button>
          <h1 className="text-xl font-bold text-pink-600 font-['Poppins']">Minhas Metas</h1>
          <div className="w-10" />
        </div>
        
        {/* Stats */}
        <StatsHeader />
        
        {/* Filter Tabs */}
        <div className="flex gap-2">
          {[
            { key: 'all', label: 'Todas' },
            { key: 'habit', label: '🔄 Hábitos' },
            { key: 'objective', label: '🎯 Objetivos' }
          ].map(({ key, label }) => (
            <button
              key={key}
              onClick={() => setFilter(key as typeof filter)}
              className={`flex-1 py-2.5 px-4 rounded-xl text-sm font-medium transition-colors ${
                filter === key
                  ? 'bg-pink-500 text-white shadow-sm'
                  : 'bg-white/80 text-gray-600 hover:bg-white'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>
      
      {/* Content */}
      <div className="px-4 pb-24">
        {filteredGoals.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-20 h-20 bg-pink-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Target className="w-10 h-10 text-pink-400" />
            </div>
            <h3 className="text-lg font-semibold text-gray-700 mb-2">Nenhuma meta ainda</h3>
            <p className="text-gray-500 mb-6">
              Crie sua primeira meta e comece a<br />acompanhar seu progresso!
            </p>
            <button
              onClick={() => setShowForm(true)}
              className="bg-pink-500 hover:bg-pink-600 text-white px-6 py-3 rounded-xl font-medium transition-colors inline-flex items-center gap-2"
            >
              <Plus className="w-5 h-5" />
              Criar Meta
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredGoals.map(goal => (
              <GoalCard 
                key={goal.id} 
                goalId={goal.id}
                onEdit={handleEdit}
                onDelete={handleDelete}
              />
            ))}
          </div>
        )}
      </div>
      
      {/* FAB */}
      {filteredGoals.length > 0 && (
        <button
          onClick={() => setShowForm(true)}
          className="fixed bottom-6 right-6 bg-pink-500 hover:bg-pink-600 text-white px-5 py-4 rounded-2xl shadow-lg font-medium flex items-center gap-2 transition-all hover:scale-105"
        >
          <Plus className="w-5 h-5" />
          Nova Meta
        </button>
      )}
      
      {/* Form Modal */}
      {showForm && (
        <GoalFormModal
          goal={editingGoal}
          onClose={handleFormClose}
        />
      )}
    </div>
  );
}

// ========== GOAL FORM MODAL ==========
interface GoalFormModalProps {
  goal: Goal | null;
  onClose: () => void;
}

const GoalFormModal = ({ goal, onClose }: GoalFormModalProps) => {
  const { createGoal, updateGoal } = useGoalStore();
  
  const [title, setTitle] = useState(goal?.title || '');
  const [description, setDescription] = useState(goal?.description || '');
  const [type, setType] = useState<GoalType>(goal?.type || 'HABIT');
  const [renewalPeriod, setRenewalPeriod] = useState(goal?.renewalPeriod || 'DAILY');
  const [targetCount, setTargetCount] = useState(goal?.targetCount || 1);
  const [totalTarget, setTotalTarget] = useState(goal?.totalTarget || 10);
  const [deadline, setDeadline] = useState(goal?.deadline || '');
  const [icon, setIcon] = useState(goal?.icon || 'target');
  const [color, setColor] = useState(goal?.color || 'pink');
  
  const handleSubmit = async () => {
    if (!title.trim()) return;
    
    const goalData = {
      title: title.trim(),
      description: description.trim() || undefined,
      type,
      icon,
      color,
      renewalPeriod,
      targetCount,
      totalTarget: type === 'OBJECTIVE' ? totalTarget : undefined,
      totalProgress: goal?.totalProgress || 0,
      deadline: deadline || undefined,
      isActive: true,
      lastCompletedDate: goal?.lastCompletedDate
    };
    
    if (goal) {
      await updateGoal({
        ...goal,
        ...goalData
      });
    } else {
      await createGoal(goalData);
    }
    
    onClose();
  };
  
  const icons = [
    { key: 'target', icon: <Target className="w-5 h-5" /> },
    { key: 'flame', icon: <Flame className="w-5 h-5" /> },
    { key: 'trophy', icon: <Trophy className="w-5 h-5" /> },
    { key: 'trending', icon: <TrendingUp className="w-5 h-5" /> },
    { key: 'calendar', icon: <Calendar className="w-5 h-5" /> },
    { key: 'rotate', icon: <RotateCcw className="w-5 h-5" /> }
  ];
  
  const colors = [
    { key: 'pink', class: 'bg-pink-500' },
    { key: 'blue', class: 'bg-blue-500' },
    { key: 'green', class: 'bg-emerald-500' },
    { key: 'purple', class: 'bg-purple-500' },
    { key: 'orange', class: 'bg-orange-500' }
  ];
  
  return (
    <div className="fixed inset-0 bg-black/50 flex items-end sm:items-center justify-center z-50">
      <div className="bg-white w-full max-w-lg rounded-t-3xl sm:rounded-3xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-white px-6 py-4 border-b border-gray-100 flex items-center justify-between">
          <h2 className="text-xl font-bold text-pink-600 font-['Poppins']">
            {goal ? 'Editar Meta' : 'Nova Meta'}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 text-2xl"
          >
            ×
          </button>
        </div>
        
        <div className="p-6 space-y-6">
          {/* Title */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Título da Meta *
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ex: Beber 8 copos de água"
              className="w-full px-4 py-3 rounded-xl border border-pink-200 focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none transition-all"
            />
          </div>
          
          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Descrição (opcional)
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Descreva sua meta..."
              rows={3}
              className="w-full px-4 py-3 rounded-xl border border-pink-200 focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none transition-all resize-none"
            />
          </div>
          
          {/* Type */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Tipo de Meta
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setType('HABIT')}
                className={`p-4 rounded-xl border-2 transition-all ${
                  type === 'HABIT'
                    ? 'border-pink-500 bg-pink-50'
                    : 'border-gray-200 hover:border-pink-200'
                }`}
              >
                <RotateCcw className={`w-6 h-6 mx-auto mb-2 ${type === 'HABIT' ? 'text-pink-500' : 'text-gray-400'}`} />
                <div className={`text-sm font-medium ${type === 'HABIT' ? 'text-pink-600' : 'text-gray-600'}`}>
                  Hábito
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  Repetitivo, renova por período
                </div>
              </button>
              
              <button
                type="button"
                onClick={() => setType('OBJECTIVE')}
                className={`p-4 rounded-xl border-2 transition-all ${
                  type === 'OBJECTIVE'
                    ? 'border-pink-500 bg-pink-50'
                    : 'border-gray-200 hover:border-pink-200'
                }`}
              >
                <Target className={`w-6 h-6 mx-auto mb-2 ${type === 'OBJECTIVE' ? 'text-pink-500' : 'text-gray-400'}`} />
                <div className={`text-sm font-medium ${type === 'OBJECTIVE' ? 'text-pink-600' : 'text-gray-600'}`}>
                  Objetivo
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  Único, progresso acumula
                </div>
              </button>
            </div>
          </div>
          
          {/* Renewal Period (for Habits) */}
          {type === 'HABIT' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Período de Renovação
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { key: 'DAILY', label: 'Diário' },
                  { key: 'WEEKLY', label: 'Semanal' },
                  { key: 'MONTHLY', label: 'Mensal' }
                ].map(({ key, label }) => (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setRenewalPeriod(key as typeof renewalPeriod)}
                    className={`py-2.5 px-3 rounded-xl text-sm font-medium transition-all ${
                      renewalPeriod === key
                        ? 'bg-pink-500 text-white'
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>
          )}
          
          {/* Target Count */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {type === 'OBJECTIVE' ? 'Meta Total' : 'Quantas vezes por período?'}
            </label>
            <div className="flex items-center gap-4">
              <button
                type="button"
                onClick={() => type === 'OBJECTIVE' 
                  ? setTotalTarget(Math.max(1, totalTarget - 1))
                  : setTargetCount(Math.max(1, targetCount - 1))
                }
                className="w-12 h-12 rounded-xl bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition-colors"
              >
                <Minus className="w-5 h-5 text-gray-600" />
              </button>
              <div className="flex-1 text-center">
                <div className="text-3xl font-bold text-pink-600">
                  {type === 'OBJECTIVE' ? totalTarget : targetCount}
                </div>
                <div className="text-xs text-gray-500">
                  {type === 'OBJECTIVE' ? 'vezes no total' : 
                    renewalPeriod === 'DAILY' ? 'vezes por dia' :
                    renewalPeriod === 'WEEKLY' ? 'vezes por semana' : 'vezes por mês'
                  }
                </div>
              </div>
              <button
                type="button"
                onClick={() => type === 'OBJECTIVE'
                  ? setTotalTarget(totalTarget + 1)
                  : setTargetCount(targetCount + 1)
                }
                className="w-12 h-12 rounded-xl bg-pink-500 hover:bg-pink-600 flex items-center justify-center transition-colors"
              >
                <Plus className="w-5 h-5 text-white" />
              </button>
            </div>
          </div>
          
          {/* Deadline */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Prazo Final (opcional)
            </label>
            <input
              type="date"
              value={deadline}
              onChange={(e) => setDeadline(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-pink-200 focus:border-pink-500 focus:ring-2 focus:ring-pink-200 outline-none transition-all"
            />
          </div>
          
          {/* Icon */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Ícone
            </label>
            <div className="flex gap-2">
              {icons.map(({ key, icon: iconElement }) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setIcon(key)}
                  className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all ${
                    icon === key
                      ? 'bg-pink-500 text-white'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {iconElement}
                </button>
              ))}
            </div>
          </div>
          
          {/* Color */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Cor
            </label>
            <div className="flex gap-3">
              {colors.map(({ key, class: colorClass }) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setColor(key)}
                  className={`w-10 h-10 rounded-full ${colorClass} transition-all ${
                    color === key ? 'ring-4 ring-offset-2 ring-pink-300' : ''
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
        
        {/* Submit Button */}
        <div className="sticky bottom-0 bg-white px-6 py-4 border-t border-gray-100">
          <button
            onClick={handleSubmit}
            disabled={!title.trim()}
            className="w-full bg-pink-500 hover:bg-pink-600 disabled:bg-gray-300 text-white py-4 rounded-xl font-semibold transition-colors"
          >
            {goal ? 'Salvar Alterações' : 'Criar Meta'}
          </button>
        </div>
      </div>
    </div>
  );
};
