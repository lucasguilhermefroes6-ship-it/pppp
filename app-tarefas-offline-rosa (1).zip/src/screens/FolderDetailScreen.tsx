import { useState, useEffect } from 'react';
import { 
  ArrowLeft, Plus, FileText, Link as LinkIcon, CheckSquare, Pin, PinOff,
  MoreVertical, Trash2, Folder, Sparkles, Sun, Moon, GraduationCap,
  Briefcase, Home, ChefHat, Dumbbell, Wallet, Heart, Plane, BookOpen,
  Star, Music, Camera, Gift, Coffee, Flower2, X
} from 'lucide-react';
import { Screen } from '../types/screens';
import { useFolderStore, FolderItemType, FolderItem } from '../store/useFolderStore';

interface FolderDetailScreenProps {
  onNavigate: (screen: Screen) => void;
  folderId: string;
}

// Mapeamento de ícones
const iconMap: Record<string, React.ElementType> = {
  Folder, Sparkles, Sun, Moon, GraduationCap, Briefcase, Home,
  ChefHat, Dumbbell, Wallet, Heart, Plane, BookOpen, Star,
  Music, Camera, Gift, Coffee, Flower2
};

function getIcon(name: string): React.ElementType {
  return iconMap[name] || Folder;
}

function getItemIcon(type: string): React.ElementType {
  switch (type) {
    case 'NOTE': return FileText;
    case 'LINK': return LinkIcon;
    case 'CHECKLIST': return CheckSquare;
    default: return FileText;
  }
}

function getRelativeTime(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffSecs = Math.floor(diffMs / 1000);
  const diffMins = Math.floor(diffSecs / 60);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffSecs < 60) return 'Agora';
  if (diffMins < 60) return `${diffMins} min`;
  if (diffHours < 24) return `${diffHours}h`;
  if (diffDays === 1) return 'Ontem';
  if (diffDays < 7) return `${diffDays} dias`;
  if (diffDays < 30) return `${Math.floor(diffDays / 7)} sem`;
  return `${Math.floor(diffDays / 30)} mês`;
}

function getItemPreview(item: FolderItem): string {
  switch (item.type) {
    case 'NOTE':
      return item.content?.substring(0, 60) || 'Sem conteúdo';
    case 'LINK':
      return item.content || 'Sem URL';
    case 'CHECKLIST':
      if (!item.checklistItems?.length) return 'Sem itens';
      const done = item.checklistItems.filter(i => i.done).length;
      return `${item.checklistItems.length} itens • ${done} concluídos`;
    default:
      return '';
  }
}

export default function FolderDetailScreen({ onNavigate, folderId }: FolderDetailScreenProps) {
  const { 
    getFolderById, 
    getItemsByFolder, 
    loadFolders,
    togglePinned,
    deleteItem
  } = useFolderStore();
  
  const folder = getFolderById(folderId);
  const [filter, setFilter] = useState<FolderItemType | null>(null);
  const [showNewModal, setShowNewModal] = useState(false);
  const [menuOpen, setMenuOpen] = useState<string | null>(null);
  
  const items = getItemsByFolder(folderId, filter || undefined);
  
  useEffect(() => {
    loadFolders();
  }, [loadFolders]);
  
  if (!folder) {
    return (
      <div className="min-h-screen bg-[#FFF5F8] flex items-center justify-center">
        <p className="text-gray-500">Pasta não encontrada</p>
      </div>
    );
  }
  
  const FolderIcon = getIcon(folder.iconName);
  
  const filters: Array<{ label: string; value: FolderItemType | null }> = [
    { label: 'Todos', value: null },
    { label: '📝 Notas', value: 'NOTE' },
    { label: '🔗 Links', value: 'LINK' },
    { label: '☑️ Checklists', value: 'CHECKLIST' },
  ];
  
  const handleDelete = async (id: string) => {
    if (confirm('Excluir este item?')) {
      await deleteItem(id);
    }
    setMenuOpen(null);
  };
  
  return (
    <div className="min-h-screen bg-[#FFF5F8]">
      {/* Header */}
      <div 
        className="pt-12 pb-6 px-4"
        style={{ 
          background: `linear-gradient(135deg, ${folder.colorHex}90, ${folder.colorHex})` 
        }}
      >
        <div className="flex items-center justify-between mb-4">
          <button 
            onClick={() => onNavigate({ name: 'folders' })}
            className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <h1 className="text-xl font-bold text-white font-['Poppins']">{folder.name}</h1>
          <div className="w-10" />
        </div>
        
        {/* Folder Info */}
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-white/20 rounded-xl flex items-center justify-center">
            <FolderIcon className="w-8 h-8 text-white" />
          </div>
          <div>
            <p className="text-white/80 text-sm">{items.length} itens</p>
            {folder.description && (
              <p className="text-white/70 text-sm mt-1">{folder.description}</p>
            )}
          </div>
        </div>
      </div>
      
      <div className="px-4 -mt-4 pb-24">
        {/* Filtros */}
        <div className="bg-white rounded-2xl p-3 shadow-sm border border-pink-100 mb-4">
          <div className="flex gap-2 overflow-x-auto">
            {filters.map((f) => (
              <button
                key={f.label}
                onClick={() => setFilter(f.value)}
                className={`px-4 py-2 rounded-full whitespace-nowrap font-semibold text-sm transition-all ${
                  filter === f.value
                    ? 'bg-pink-500 text-white'
                    : 'bg-pink-50 text-pink-600 hover:bg-pink-100'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
        
        {/* Lista de Itens */}
        {items.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 text-center border border-pink-100">
            <div className="w-16 h-16 bg-pink-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <FileText className="w-8 h-8 text-pink-300" />
            </div>
            <h3 className="text-lg font-semibold text-gray-700 mb-2">Nenhum item ainda</h3>
            <p className="text-gray-500 text-sm">
              Adicione notas, links ou checklists!
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {items.map((item) => {
              const ItemIcon = getItemIcon(item.type);
              
              return (
                <div
                  key={item.id}
                  className="bg-white rounded-2xl shadow-sm border border-pink-100 overflow-hidden relative"
                >
                  <div className="flex">
                    {/* Faixa colorida */}
                    <div 
                      className="w-2"
                      style={{ backgroundColor: folder.colorHex }}
                    />
                    
                    <button
                      onClick={() => onNavigate({ 
                        name: 'folder-item-edit', 
                        folderId, 
                        itemId: item.id 
                      })}
                      className="flex-1 p-4 text-left"
                    >
                      <div className="flex items-start gap-3">
                        <div 
                          className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                          style={{ backgroundColor: `${folder.colorHex}20` }}
                        >
                          <ItemIcon className="w-5 h-5" style={{ color: folder.colorHex }} />
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <h4 className="font-bold text-gray-800 truncate">{item.title}</h4>
                            {item.pinned && (
                              <Pin className="w-4 h-4 text-pink-400 flex-shrink-0" />
                            )}
                          </div>
                          <p className="text-sm text-gray-500 truncate">{getItemPreview(item)}</p>
                          <p className="text-xs text-gray-400 mt-1">{getRelativeTime(item.updatedAt)}</p>
                        </div>
                      </div>
                    </button>
                    
                    {/* Ações */}
                    <div className="flex items-center pr-2 gap-1">
                      <button
                        onClick={() => togglePinned(item.id)}
                        className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100"
                      >
                        {item.pinned ? (
                          <PinOff className="w-4 h-4 text-pink-400" />
                        ) : (
                          <Pin className="w-4 h-4 text-gray-400" />
                        )}
                      </button>
                      
                      <button
                        onClick={() => setMenuOpen(menuOpen === item.id ? null : item.id)}
                        className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100"
                      >
                        <MoreVertical className="w-4 h-4 text-gray-400" />
                      </button>
                    </div>
                  </div>
                  
                  {/* Menu */}
                  {menuOpen === item.id && (
                    <div className="absolute top-12 right-3 bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden z-10">
                      <button
                        onClick={() => handleDelete(item.id)}
                        className="w-full px-4 py-2 text-left text-sm text-red-500 hover:bg-red-50 flex items-center gap-2"
                      >
                        <Trash2 className="w-4 h-4" />
                        Excluir
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
      
      {/* FAB */}
      <button
        onClick={() => setShowNewModal(true)}
        className="fixed bottom-6 right-6 bg-pink-500 text-white px-6 py-4 rounded-2xl shadow-lg flex items-center gap-2 font-semibold"
      >
        <Plus className="w-5 h-5" />
        Novo
      </button>
      
      {/* Modal Novo Item */}
      {showNewModal && (
        <div className="fixed inset-0 bg-black/50 flex items-end justify-center z-50">
          <div className="bg-white rounded-t-3xl w-full max-w-lg p-6 animate-slide-up">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-800 font-['Poppins']">
                Novo Item ✨
              </h3>
              <button
                onClick={() => setShowNewModal(false)}
                className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100"
              >
                <X className="w-5 h-5 text-gray-600" />
              </button>
            </div>
            
            <div className="space-y-3">
              <button
                onClick={() => {
                  setShowNewModal(false);
                  onNavigate({ name: 'folder-item-edit', folderId, itemType: 'NOTE' });
                }}
                className="w-full bg-pink-50 rounded-2xl p-4 flex items-center gap-4 text-left hover:bg-pink-100 transition-colors"
              >
                <div className="w-12 h-12 bg-pink-100 rounded-xl flex items-center justify-center">
                  <FileText className="w-6 h-6 text-pink-500" />
                </div>
                <div>
                  <h4 className="font-bold text-gray-800">📝 Nota</h4>
                  <p className="text-sm text-gray-500">Texto livre para suas ideias</p>
                </div>
              </button>
              
              <button
                onClick={() => {
                  setShowNewModal(false);
                  onNavigate({ name: 'folder-item-edit', folderId, itemType: 'LINK' });
                }}
                className="w-full bg-blue-50 rounded-2xl p-4 flex items-center gap-4 text-left hover:bg-blue-100 transition-colors"
              >
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                  <LinkIcon className="w-6 h-6 text-blue-500" />
                </div>
                <div>
                  <h4 className="font-bold text-gray-800">🔗 Link</h4>
                  <p className="text-sm text-gray-500">Salve URLs importantes</p>
                </div>
              </button>
              
              <button
                onClick={() => {
                  setShowNewModal(false);
                  onNavigate({ name: 'folder-item-edit', folderId, itemType: 'CHECKLIST' });
                }}
                className="w-full bg-green-50 rounded-2xl p-4 flex items-center gap-4 text-left hover:bg-green-100 transition-colors"
              >
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                  <CheckSquare className="w-6 h-6 text-green-500" />
                </div>
                <div>
                  <h4 className="font-bold text-gray-800">☑️ Checklist</h4>
                  <p className="text-sm text-gray-500">Lista de itens com check</p>
                </div>
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Click outside to close menu */}
      {menuOpen && (
        <div 
          className="fixed inset-0 z-0" 
          onClick={() => setMenuOpen(null)}
        />
      )}
    </div>
  );
}
