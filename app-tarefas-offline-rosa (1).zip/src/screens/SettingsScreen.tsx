import { useState } from 'react';
import { 
  ArrowLeft, 
  Settings,
  Moon,
  Droplets,
  Timer,
  Bell,
  BellOff,
  Download,
  Trash2,
  Heart,
  ChevronRight,
  Check
} from 'lucide-react';
import { Screen } from '@/types/screens';

interface SettingsScreenProps {
  setScreen: (screen: Screen) => void;
  isDarkMode: boolean;
  setIsDarkMode: (value: boolean) => void;
}

export default function SettingsScreen({ setScreen, isDarkMode, setIsDarkMode }: SettingsScreenProps) {
  const [waterGoal, setWaterGoal] = useState(() => {
    const saved = localStorage.getItem('settings-water-goal');
    return saved ? parseInt(saved) : 2000;
  });
  
  const [sleepGoal, setSleepGoal] = useState(() => {
    const saved = localStorage.getItem('settings-sleep-goal');
    return saved ? parseInt(saved) : 8;
  });
  
  const [pomodoroTime, setPomodoroTime] = useState(() => {
    const saved = localStorage.getItem('settings-pomodoro-time');
    return saved ? parseInt(saved) : 25;
  });
  
  const [notificationsEnabled, setNotificationsEnabled] = useState(() => {
    const saved = localStorage.getItem('settings-notifications');
    return saved !== 'false';
  });
  
  const [showWaterGoalPicker, setShowWaterGoalPicker] = useState(false);
  const [showSleepGoalPicker, setShowSleepGoalPicker] = useState(false);
  const [showPomodoroPicker, setShowPomodoroPicker] = useState(false);
  const [showClearDataConfirm, setShowClearDataConfirm] = useState(false);

  const handleWaterGoalChange = (value: number) => {
    setWaterGoal(value);
    localStorage.setItem('settings-water-goal', value.toString());
    setShowWaterGoalPicker(false);
  };

  const handleSleepGoalChange = (value: number) => {
    setSleepGoal(value);
    localStorage.setItem('settings-sleep-goal', value.toString());
    setShowSleepGoalPicker(false);
  };

  const handlePomodoroChange = (value: number) => {
    setPomodoroTime(value);
    localStorage.setItem('settings-pomodoro-time', value.toString());
    setShowPomodoroPicker(false);
  };

  const handleNotificationsToggle = () => {
    const newValue = !notificationsEnabled;
    setNotificationsEnabled(newValue);
    localStorage.setItem('settings-notifications', newValue.toString());
  };

  const handleDarkModeToggle = () => {
    setIsDarkMode(!isDarkMode);
  };

  const handleExportData = () => {
    const allData: Record<string, string | null> = {};
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key) {
        allData[key] = localStorage.getItem(key);
      }
    }
    
    const dataStr = JSON.stringify(allData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `vida-rosa-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleClearData = () => {
    localStorage.clear();
    setShowClearDataConfirm(false);
    window.location.reload();
  };

  return (
    <div className={`min-h-screen ${isDarkMode ? 'bg-gray-900' : 'bg-[#FFF8FC]'}`}>
      {/* Header */}
      <div 
        className="px-5 pt-6 pb-8"
        style={{ 
          background: isDarkMode 
            ? 'linear-gradient(135deg, #831843 0%, #701a75 100%)' 
            : 'linear-gradient(135deg, #EC4899 0%, #DB2777 50%, #BE185D 100%)' 
        }}
      >
        <div className="flex items-center gap-4">
          <button
            onClick={() => setScreen({ name: 'home' })}
            className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center">
              <Settings className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold font-poppins text-white">Configurações</h1>
              <p className="text-white/70 text-sm">Personalize seu app</p>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-5 -mt-4">
        {/* Aparência */}
        <div className={`rounded-2xl p-4 mb-4 ${isDarkMode ? 'bg-gray-800' : 'bg-white'}`} 
          style={{ boxShadow: '0 2px 12px rgba(0,0,0,0.06)', border: `1px solid ${isDarkMode ? '#374151' : '#F3C9DF'}` }}>
          <h2 className={`text-lg font-semibold font-poppins mb-4 ${isDarkMode ? 'text-white' : 'text-[#2B1B2B]'}`}>
            Aparência
          </h2>
          
          {/* Modo Escuro */}
          <button
            onClick={handleDarkModeToggle}
            className={`w-full flex items-center justify-between p-3 rounded-xl mb-2 ${
              isDarkMode ? 'bg-gray-700' : 'bg-[#FFF0F8]'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                isDarkMode ? 'bg-purple-500/20' : 'bg-[#FFD6EA]'
              }`}>
                <Moon className={`w-5 h-5 ${isDarkMode ? 'text-purple-400' : 'text-[#FF5DAF]'}`} />
              </div>
              <span className={`font-medium ${isDarkMode ? 'text-white' : 'text-[#2B1B2B]'}`}>
                Modo Escuro
              </span>
            </div>
            <div className={`w-12 h-7 rounded-full p-1 transition-colors ${
              isDarkMode ? 'bg-[#FF5DAF]' : 'bg-gray-300'
            }`}>
              <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                isDarkMode ? 'translate-x-5' : 'translate-x-0'
              }`} />
            </div>
          </button>
        </div>

        {/* Metas Diárias */}
        <div className={`rounded-2xl p-4 mb-4 ${isDarkMode ? 'bg-gray-800' : 'bg-white'}`}
          style={{ boxShadow: '0 2px 12px rgba(0,0,0,0.06)', border: `1px solid ${isDarkMode ? '#374151' : '#F3C9DF'}` }}>
          <h2 className={`text-lg font-semibold font-poppins mb-4 ${isDarkMode ? 'text-white' : 'text-[#2B1B2B]'}`}>
            Metas Diárias
          </h2>
          
          {/* Meta de Água */}
          <button
            onClick={() => setShowWaterGoalPicker(true)}
            className={`w-full flex items-center justify-between p-3 rounded-xl mb-2 ${
              isDarkMode ? 'bg-gray-700' : 'bg-[#FFF0F8]'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                isDarkMode ? 'bg-cyan-500/20' : 'bg-[#E0F7FA]'
              }`}>
                <Droplets className={`w-5 h-5 ${isDarkMode ? 'text-cyan-400' : 'text-cyan-600'}`} />
              </div>
              <span className={`font-medium ${isDarkMode ? 'text-white' : 'text-[#2B1B2B]'}`}>
                Meta de Água
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className={`font-semibold ${isDarkMode ? 'text-gray-300' : 'text-[#7A5A73]'}`}>
                {(waterGoal / 1000).toFixed(1)}L
              </span>
              <ChevronRight className={`w-5 h-5 ${isDarkMode ? 'text-gray-500' : 'text-[#7A5A73]'}`} />
            </div>
          </button>

          {/* Meta de Sono */}
          <button
            onClick={() => setShowSleepGoalPicker(true)}
            className={`w-full flex items-center justify-between p-3 rounded-xl mb-2 ${
              isDarkMode ? 'bg-gray-700' : 'bg-[#FFF0F8]'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                isDarkMode ? 'bg-indigo-500/20' : 'bg-indigo-100'
              }`}>
                <Moon className={`w-5 h-5 ${isDarkMode ? 'text-indigo-400' : 'text-indigo-600'}`} />
              </div>
              <span className={`font-medium ${isDarkMode ? 'text-white' : 'text-[#2B1B2B]'}`}>
                Meta de Sono
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className={`font-semibold ${isDarkMode ? 'text-gray-300' : 'text-[#7A5A73]'}`}>
                {sleepGoal}h
              </span>
              <ChevronRight className={`w-5 h-5 ${isDarkMode ? 'text-gray-500' : 'text-[#7A5A73]'}`} />
            </div>
          </button>

          {/* Tempo Pomodoro */}
          <button
            onClick={() => setShowPomodoroPicker(true)}
            className={`w-full flex items-center justify-between p-3 rounded-xl ${
              isDarkMode ? 'bg-gray-700' : 'bg-[#FFF0F8]'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                isDarkMode ? 'bg-red-500/20' : 'bg-red-100'
              }`}>
                <Timer className={`w-5 h-5 ${isDarkMode ? 'text-red-400' : 'text-red-600'}`} />
              </div>
              <span className={`font-medium ${isDarkMode ? 'text-white' : 'text-[#2B1B2B]'}`}>
                Tempo Pomodoro
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className={`font-semibold ${isDarkMode ? 'text-gray-300' : 'text-[#7A5A73]'}`}>
                {pomodoroTime}min
              </span>
              <ChevronRight className={`w-5 h-5 ${isDarkMode ? 'text-gray-500' : 'text-[#7A5A73]'}`} />
            </div>
          </button>
        </div>

        {/* Notificações */}
        <div className={`rounded-2xl p-4 mb-4 ${isDarkMode ? 'bg-gray-800' : 'bg-white'}`}
          style={{ boxShadow: '0 2px 12px rgba(0,0,0,0.06)', border: `1px solid ${isDarkMode ? '#374151' : '#F3C9DF'}` }}>
          <h2 className={`text-lg font-semibold font-poppins mb-4 ${isDarkMode ? 'text-white' : 'text-[#2B1B2B]'}`}>
            Notificações
          </h2>
          
          <button
            onClick={handleNotificationsToggle}
            className={`w-full flex items-center justify-between p-3 rounded-xl ${
              isDarkMode ? 'bg-gray-700' : 'bg-[#FFF0F8]'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                isDarkMode ? 'bg-yellow-500/20' : 'bg-yellow-100'
              }`}>
                {notificationsEnabled ? (
                  <Bell className={`w-5 h-5 ${isDarkMode ? 'text-yellow-400' : 'text-yellow-600'}`} />
                ) : (
                  <BellOff className={`w-5 h-5 ${isDarkMode ? 'text-yellow-400' : 'text-yellow-600'}`} />
                )}
              </div>
              <span className={`font-medium ${isDarkMode ? 'text-white' : 'text-[#2B1B2B]'}`}>
                Notificações
              </span>
            </div>
            <div className={`w-12 h-7 rounded-full p-1 transition-colors ${
              notificationsEnabled ? 'bg-[#FF5DAF]' : 'bg-gray-300'
            }`}>
              <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                notificationsEnabled ? 'translate-x-5' : 'translate-x-0'
              }`} />
            </div>
          </button>
        </div>

        {/* Dados */}
        <div className={`rounded-2xl p-4 mb-4 ${isDarkMode ? 'bg-gray-800' : 'bg-white'}`}
          style={{ boxShadow: '0 2px 12px rgba(0,0,0,0.06)', border: `1px solid ${isDarkMode ? '#374151' : '#F3C9DF'}` }}>
          <h2 className={`text-lg font-semibold font-poppins mb-4 ${isDarkMode ? 'text-white' : 'text-[#2B1B2B]'}`}>
            Dados
          </h2>
          
          <button
            onClick={handleExportData}
            className={`w-full flex items-center justify-between p-3 rounded-xl mb-2 ${
              isDarkMode ? 'bg-gray-700' : 'bg-[#FFF0F8]'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                isDarkMode ? 'bg-green-500/20' : 'bg-green-100'
              }`}>
                <Download className={`w-5 h-5 ${isDarkMode ? 'text-green-400' : 'text-green-600'}`} />
              </div>
              <span className={`font-medium ${isDarkMode ? 'text-white' : 'text-[#2B1B2B]'}`}>
                Exportar Dados
              </span>
            </div>
            <ChevronRight className={`w-5 h-5 ${isDarkMode ? 'text-gray-500' : 'text-[#7A5A73]'}`} />
          </button>

          <button
            onClick={() => setShowClearDataConfirm(true)}
            className={`w-full flex items-center justify-between p-3 rounded-xl ${
              isDarkMode ? 'bg-gray-700' : 'bg-[#FFF0F8]'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                isDarkMode ? 'bg-red-500/20' : 'bg-red-100'
              }`}>
                <Trash2 className={`w-5 h-5 ${isDarkMode ? 'text-red-400' : 'text-red-500'}`} />
              </div>
              <span className={`font-medium ${isDarkMode ? 'text-white' : 'text-[#2B1B2B]'}`}>
                Limpar Todos os Dados
              </span>
            </div>
            <ChevronRight className={`w-5 h-5 ${isDarkMode ? 'text-gray-500' : 'text-[#7A5A73]'}`} />
          </button>
        </div>

        {/* Sobre */}
        <div className={`rounded-2xl p-4 mb-8 ${isDarkMode ? 'bg-gray-800' : 'bg-white'}`}
          style={{ boxShadow: '0 2px 12px rgba(0,0,0,0.06)', border: `1px solid ${isDarkMode ? '#374151' : '#F3C9DF'}` }}>
          <h2 className={`text-lg font-semibold font-poppins mb-4 ${isDarkMode ? 'text-white' : 'text-[#2B1B2B]'}`}>
            Sobre
          </h2>
          
          <div className="text-center py-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#FF5DAF] to-[#FF7DC4] flex items-center justify-center mx-auto mb-3">
              <Heart className="w-8 h-8 text-white" />
            </div>
            <h3 className={`font-bold font-poppins text-lg ${isDarkMode ? 'text-white' : 'text-[#2B1B2B]'}`}>
              Vida Rosa
            </h3>
            <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-[#7A5A73]'}`}>
              Versão 1.0.0
            </p>
            <p className={`text-sm mt-2 ${isDarkMode ? 'text-gray-400' : 'text-[#7A5A73]'}`}>
              Feito com 💕 para você
            </p>
          </div>
        </div>
      </div>

      {/* Water Goal Picker Modal */}
      {showWaterGoalPicker && (
        <div className="fixed inset-0 bg-black/50 flex items-end justify-center z-50">
          <div className={`w-full max-w-md rounded-t-3xl p-6 ${isDarkMode ? 'bg-gray-800' : 'bg-white'}`}>
            <h3 className={`text-lg font-bold font-poppins mb-4 ${isDarkMode ? 'text-white' : 'text-[#2B1B2B]'}`}>
              Meta de Água Diária
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {[1500, 2000, 2500, 3000].map(value => (
                <button
                  key={value}
                  onClick={() => handleWaterGoalChange(value)}
                  className={`p-4 rounded-xl flex items-center justify-center gap-2 ${
                    waterGoal === value 
                      ? 'bg-[#FF5DAF] text-white' 
                      : isDarkMode ? 'bg-gray-700 text-white' : 'bg-[#FFF0F8] text-[#2B1B2B]'
                  }`}
                >
                  {waterGoal === value && <Check className="w-5 h-5" />}
                  {(value / 1000).toFixed(1)}L
                </button>
              ))}
            </div>
            <button
              onClick={() => setShowWaterGoalPicker(false)}
              className={`w-full mt-4 py-3 rounded-xl ${
                isDarkMode ? 'bg-gray-700 text-white' : 'bg-gray-200 text-gray-600'
              }`}
            >
              Cancelar
            </button>
          </div>
        </div>
      )}

      {/* Sleep Goal Picker Modal */}
      {showSleepGoalPicker && (
        <div className="fixed inset-0 bg-black/50 flex items-end justify-center z-50">
          <div className={`w-full max-w-md rounded-t-3xl p-6 ${isDarkMode ? 'bg-gray-800' : 'bg-white'}`}>
            <h3 className={`text-lg font-bold font-poppins mb-4 ${isDarkMode ? 'text-white' : 'text-[#2B1B2B]'}`}>
              Meta de Sono Diária
            </h3>
            <div className="grid grid-cols-4 gap-3">
              {[6, 7, 8, 9].map(value => (
                <button
                  key={value}
                  onClick={() => handleSleepGoalChange(value)}
                  className={`p-4 rounded-xl flex items-center justify-center gap-2 ${
                    sleepGoal === value 
                      ? 'bg-[#FF5DAF] text-white' 
                      : isDarkMode ? 'bg-gray-700 text-white' : 'bg-[#FFF0F8] text-[#2B1B2B]'
                  }`}
                >
                  {sleepGoal === value && <Check className="w-5 h-5" />}
                  {value}h
                </button>
              ))}
            </div>
            <button
              onClick={() => setShowSleepGoalPicker(false)}
              className={`w-full mt-4 py-3 rounded-xl ${
                isDarkMode ? 'bg-gray-700 text-white' : 'bg-gray-200 text-gray-600'
              }`}
            >
              Cancelar
            </button>
          </div>
        </div>
      )}

      {/* Pomodoro Picker Modal */}
      {showPomodoroPicker && (
        <div className="fixed inset-0 bg-black/50 flex items-end justify-center z-50">
          <div className={`w-full max-w-md rounded-t-3xl p-6 ${isDarkMode ? 'bg-gray-800' : 'bg-white'}`}>
            <h3 className={`text-lg font-bold font-poppins mb-4 ${isDarkMode ? 'text-white' : 'text-[#2B1B2B]'}`}>
              Tempo de Foco (Pomodoro)
            </h3>
            <div className="grid grid-cols-4 gap-3">
              {[20, 25, 30, 45].map(value => (
                <button
                  key={value}
                  onClick={() => handlePomodoroChange(value)}
                  className={`p-4 rounded-xl flex items-center justify-center gap-2 ${
                    pomodoroTime === value 
                      ? 'bg-[#FF5DAF] text-white' 
                      : isDarkMode ? 'bg-gray-700 text-white' : 'bg-[#FFF0F8] text-[#2B1B2B]'
                  }`}
                >
                  {pomodoroTime === value && <Check className="w-5 h-5" />}
                  {value}min
                </button>
              ))}
            </div>
            <button
              onClick={() => setShowPomodoroPicker(false)}
              className={`w-full mt-4 py-3 rounded-xl ${
                isDarkMode ? 'bg-gray-700 text-white' : 'bg-gray-200 text-gray-600'
              }`}
            >
              Cancelar
            </button>
          </div>
        </div>
      )}

      {/* Clear Data Confirm Modal */}
      {showClearDataConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className={`w-full max-w-sm rounded-2xl p-6 ${isDarkMode ? 'bg-gray-800' : 'bg-white'}`}>
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-4">
                <Trash2 className="w-8 h-8 text-red-500" />
              </div>
              <h3 className={`text-lg font-bold font-poppins mb-2 ${isDarkMode ? 'text-white' : 'text-[#2B1B2B]'}`}>
                Limpar Todos os Dados?
              </h3>
              <p className={`text-sm mb-6 ${isDarkMode ? 'text-gray-400' : 'text-[#7A5A73]'}`}>
                Esta ação não pode ser desfeita. Todos os seus dados serão permanentemente excluídos.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowClearDataConfirm(false)}
                  className={`flex-1 py-3 rounded-xl font-semibold ${
                    isDarkMode ? 'bg-gray-700 text-white' : 'bg-gray-200 text-gray-600'
                  }`}
                >
                  Cancelar
                </button>
                <button
                  onClick={handleClearData}
                  className="flex-1 py-3 rounded-xl font-semibold bg-red-500 text-white"
                >
                  Limpar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
