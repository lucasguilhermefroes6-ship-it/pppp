import { useEffect, useState } from 'react';
import { 
  ArrowLeft, 
  ChevronLeft, 
  ChevronRight, 
  TrendingUp, 
  TrendingDown, 
  Wallet,
  Calendar,
  RefreshCw,
  Plus,
  Trash2,
  Utensils,
  Car,
  Home,
  Heart,
  GraduationCap,
  Gamepad2,
  ShoppingBag,
  FileText,
  MoreHorizontal,
  PieChart,
  BarChart3,
  Tag
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useFinanceStore, formatCurrency, Transaction } from '@/store/useFinanceStore';
import { Screen } from '@/types/screens';
import { cn } from '@/utils/cn';

interface FinancesScreenProps {
  onNavigate: (screen: Screen) => void;
}

// Default category icons and colors
const DEFAULT_CATEGORY_CONFIG: Record<string, { icon: any; color: string; bgColor: string }> = {
  'Alimentação': { icon: Utensils, color: '#F97316', bgColor: '#FFF7ED' },
  'Transporte': { icon: Car, color: '#3B82F6', bgColor: '#EFF6FF' },
  'Moradia': { icon: Home, color: '#8B5CF6', bgColor: '#F5F3FF' },
  'Saúde': { icon: Heart, color: '#EC4899', bgColor: '#FDF2F8' },
  'Educação': { icon: GraduationCap, color: '#10B981', bgColor: '#ECFDF5' },
  'Lazer': { icon: Gamepad2, color: '#F59E0B', bgColor: '#FFFBEB' },
  'Vestuário': { icon: ShoppingBag, color: '#EC4899', bgColor: '#FDF2F8' },
  'Contas': { icon: FileText, color: '#6366F1', bgColor: '#EEF2FF' },
  'Outros': { icon: MoreHorizontal, color: '#6B7280', bgColor: '#F9FAFB' },
};

// Helper function to lighten a color for background
const lightenColor = (hex: string): string => {
  // Convert hex to RGB
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  
  // Lighten by mixing with white (90% white, 10% color)
  const lightenedR = Math.round(r * 0.15 + 255 * 0.85);
  const lightenedG = Math.round(g * 0.15 + 255 * 0.85);
  const lightenedB = Math.round(b * 0.15 + 255 * 0.85);
  
  return `rgb(${lightenedR}, ${lightenedG}, ${lightenedB})`;
};

export default function FinancesScreen({ onNavigate }: FinancesScreenProps) {
  const {
    isLoading,
    selectedMonth,
    initialize,
    prevMonth,
    nextMonth,
    getMonthTransactions,
    sumIncomeForMonth,
    sumExpenseForMonth,
    getBalance,
    deleteTransaction,
    customCategories
  } = useFinanceStore();
  
  const [chartView, setChartView] = useState<'bar' | 'list'>('bar');
  
  useEffect(() => {
    initialize();
  }, [initialize]);
  
  // Function to get category config (supports custom categories)
  const getCategoryConfig = (categoryName: string): { icon: any; color: string; bgColor: string } => {
    // Check if it's a custom category
    const customCategory = customCategories.find(c => c.name === categoryName);
    if (customCategory) {
      return {
        icon: Tag,
        color: customCategory.color,
        bgColor: lightenColor(customCategory.color)
      };
    }
    // Return default config or fallback
    return DEFAULT_CATEGORY_CONFIG[categoryName] || DEFAULT_CATEGORY_CONFIG['Outros'];
  };
  
  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#FFF5F8] flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-pink-500 border-t-transparent rounded-full" />
      </div>
    );
  }
  
  const transactions = getMonthTransactions();
  const income = sumIncomeForMonth();
  const expense = sumExpenseForMonth();
  const balance = getBalance();
  
  // Calculate expenses by category
  const expensesByCategory = transactions
    .filter(t => t.type === 'EXPENSE')
    .reduce((acc, t) => {
      acc[t.category] = (acc[t.category] || 0) + t.amountCents;
      return acc;
    }, {} as Record<string, number>);
  
  const totalExpenses = Object.values(expensesByCategory).reduce((a, b) => a + b, 0);
  
  // Sort categories by amount
  const sortedCategories = Object.entries(expensesByCategory)
    .sort(([, a], [, b]) => b - a);
  
  // Group transactions by date
  const groupedTransactions = transactions.reduce((groups, transaction) => {
    const date = transaction.date;
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(transaction);
    return groups;
  }, {} as Record<string, Transaction[]>);
  
  // Sort dates descending
  const sortedDates = Object.keys(groupedTransactions).sort((a, b) => 
    new Date(b).getTime() - new Date(a).getTime()
  );
  
  const handleDelete = async (id: string) => {
    if (confirm('Tem certeza que deseja excluir esta transação?')) {
      await deleteTransaction(id);
    }
  };
  
  return (
    <div className="min-h-screen bg-[#FFF5F8] pb-24">
      {/* Header */}
      <header className="bg-gradient-to-br from-pink-400 to-pink-500 text-white px-4 pt-10 pb-6">
        <div className="max-w-lg mx-auto">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <button
                onClick={() => onNavigate({ name: 'home' })}
                className="p-2 -ml-2 rounded-lg hover:bg-white/10 transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div>
                <h1 className="text-xl font-bold font-poppins">Finanças</h1>
                <p className="text-pink-100 text-sm">Visão geral</p>
              </div>
            </div>
            <button className="p-2 rounded-lg hover:bg-white/10 transition-colors">
              <Calendar className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>
      
      <main className="px-4 py-6 max-w-lg mx-auto space-y-4">
        {/* Month Selector */}
        <div className="flex items-center justify-center gap-4">
          <button
            onClick={prevMonth}
            className="w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center hover:bg-pink-50 transition-colors border border-pink-100"
          >
            <ChevronLeft className="w-5 h-5 text-pink-500" />
          </button>
          <div className="text-center min-w-[160px]">
            <span className="text-lg font-semibold text-pink-600 font-poppins capitalize">
              {format(selectedMonth, 'MMMM yyyy', { locale: ptBR })}
            </span>
          </div>
          <button
            onClick={nextMonth}
            className="w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center hover:bg-pink-50 transition-colors border border-pink-100"
          >
            <ChevronRight className="w-5 h-5 text-pink-500" />
          </button>
        </div>
        
        {/* Summary Cards */}
        <div className="grid grid-cols-3 gap-3">
          {/* Income Card */}
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
            <div className="flex items-center gap-1 mb-2">
              <TrendingUp className="w-4 h-4 text-emerald-500" />
              <span className="text-xs text-gray-500">Entradas</span>
            </div>
            <p className="text-lg font-bold text-emerald-500 font-poppins">
              {formatCurrency(income)}
            </p>
          </div>
          
          {/* Expense Card */}
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
            <div className="flex items-center gap-1 mb-2">
              <TrendingDown className="w-4 h-4 text-red-500" />
              <span className="text-xs text-gray-500">Saídas</span>
            </div>
            <p className="text-lg font-bold text-red-500 font-poppins">
              {formatCurrency(expense)}
            </p>
          </div>
          
          {/* Balance Card */}
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
            <div className="flex items-center gap-1 mb-2">
              <Wallet className="w-4 h-4 text-blue-500" />
              <span className="text-xs text-gray-500">Saldo</span>
            </div>
            <p className={cn(
              'text-lg font-bold font-poppins',
              balance >= 0 ? 'text-blue-500' : 'text-red-500'
            )}>
              {formatCurrency(balance)}
            </p>
          </div>
        </div>
        
        {/* Category Chart - DESBLOQUEADO! */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <PieChart className="w-5 h-5 text-pink-500" />
              <span className="font-semibold text-gray-800 font-poppins">Gastos por Categoria</span>
            </div>
            <div className="flex bg-pink-50 rounded-lg p-1">
              <button
                onClick={() => setChartView('bar')}
                className={cn(
                  'p-1.5 rounded-md transition-colors',
                  chartView === 'bar' ? 'bg-white shadow-sm' : ''
                )}
              >
                <BarChart3 className="w-4 h-4 text-pink-500" />
              </button>
              <button
                onClick={() => setChartView('list')}
                className={cn(
                  'p-1.5 rounded-md transition-colors',
                  chartView === 'list' ? 'bg-white shadow-sm' : ''
                )}
              >
                <FileText className="w-4 h-4 text-pink-500" />
              </button>
            </div>
          </div>
          
          {sortedCategories.length === 0 ? (
            <div className="text-center py-6">
              <div className="w-14 h-14 bg-pink-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <PieChart className="w-7 h-7 text-pink-400" />
              </div>
              <p className="text-gray-500 text-sm">Nenhuma despesa neste mês</p>
            </div>
          ) : chartView === 'bar' ? (
            // Bar Chart View
            <div className="space-y-3">
              {sortedCategories.map(([category, amount]) => {
                const config = getCategoryConfig(category);
                const Icon = config.icon;
                const percentage = totalExpenses > 0 ? (amount / totalExpenses) * 100 : 0;
                
                return (
                  <div key={category}>
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-8 h-8 rounded-lg flex items-center justify-center"
                          style={{ backgroundColor: config.bgColor }}
                        >
                          <Icon className="w-4 h-4" style={{ color: config.color }} />
                        </div>
                        <span className="text-sm font-medium text-gray-700">{category}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-sm font-bold text-gray-800">
                          {formatCurrency(amount)}
                        </span>
                        <span className="text-xs text-gray-400 ml-2">
                          {percentage.toFixed(0)}%
                        </span>
                      </div>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full rounded-full transition-all duration-500"
                        style={{ 
                          width: `${percentage}%`,
                          backgroundColor: config.color
                        }}
                      />
                    </div>
                  </div>
                );
              })}
              
              {/* Total */}
              <div className="border-t border-gray-100 pt-3 mt-4">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-gray-700">Total de Gastos</span>
                  <span className="text-lg font-bold text-red-500 font-poppins">
                    {formatCurrency(totalExpenses)}
                  </span>
                </div>
              </div>
            </div>
          ) : (
            // List View with Donut Chart representation
            <div className="space-y-2">
              {/* Donut Chart Visual */}
              <div className="flex items-center justify-center mb-4">
                <div className="relative w-32 h-32">
                  <svg className="w-full h-full transform -rotate-90">
                    {sortedCategories.reduce((acc, [category, amount]) => {
                      const config = getCategoryConfig(category);
                      const percentage = (amount / totalExpenses) * 100;
                      const previousPercentage = acc.offset;
                      const circumference = 2 * Math.PI * 45;
                      const strokeDasharray = `${(percentage / 100) * circumference} ${circumference}`;
                      const strokeDashoffset = -((previousPercentage / 100) * circumference);
                      
                      acc.elements.push(
                        <circle
                          key={category}
                          cx="64"
                          cy="64"
                          r="45"
                          fill="none"
                          stroke={config.color}
                          strokeWidth="18"
                          strokeDasharray={strokeDasharray}
                          strokeDashoffset={strokeDashoffset}
                          className="transition-all duration-500"
                        />
                      );
                      acc.offset += percentage;
                      return acc;
                    }, { elements: [] as React.ReactNode[], offset: 0 }).elements}
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-xs text-gray-500">Total</span>
                    <span className="text-sm font-bold text-gray-800">
                      {formatCurrency(totalExpenses)}
                    </span>
                  </div>
                </div>
              </div>
              
              {/* Legend */}
              <div className="grid grid-cols-2 gap-2">
                {sortedCategories.map(([category, amount]) => {
                  const config = getCategoryConfig(category);
                  const percentage = totalExpenses > 0 ? (amount / totalExpenses) * 100 : 0;
                  
                  return (
                    <div 
                      key={category}
                      className="flex items-center gap-2 p-2 rounded-lg"
                      style={{ backgroundColor: config.bgColor }}
                    >
                      <div 
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: config.color }}
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-medium text-gray-700 truncate">{category}</p>
                        <p className="text-xs text-gray-500">{percentage.toFixed(0)}%</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
        
        {/* Fixed Transactions Card */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-pink-100 rounded-xl flex items-center justify-center">
              <RefreshCw className="w-5 h-5 text-pink-500" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-800">Transações Fixas</h3>
              <p className="text-sm text-gray-500">Adicione receitas e despesas recorrentes</p>
            </div>
          </div>
          <button
            onClick={() => onNavigate({ name: 'new-transaction', isFixed: true } as any)}
            className="w-full bg-pink-50 hover:bg-pink-100 text-pink-600 py-3 rounded-xl font-semibold transition-colors flex items-center justify-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Adicionar
          </button>
        </div>
        
        {/* Transactions List */}
        <div>
          <h3 className="font-semibold text-pink-600 font-poppins mb-3">Transações do Mês</h3>
          
          {sortedDates.length === 0 ? (
            <div className="bg-white rounded-2xl p-8 shadow-sm border border-pink-100 text-center">
              <div className="w-16 h-16 bg-pink-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <Wallet className="w-8 h-8 text-pink-400" />
              </div>
              <p className="text-gray-600 font-medium">Nenhuma transação neste mês</p>
              <p className="text-sm text-gray-400 mt-1">Adicione sua primeira transação!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {sortedDates.map((date) => {
                const dayTransactions = groupedTransactions[date];
                return (
                  <div key={date}>
                    <p className="text-sm text-gray-500 mb-2 font-medium">
                      {format(new Date(date), "dd/MM/yyyy - EEEE", { locale: ptBR })}
                    </p>
                    <div className="space-y-2">
                      {dayTransactions.map((transaction) => {
                        const config = getCategoryConfig(transaction.category);
                        const Icon = config.icon;
                        
                        return (
                          <div
                            key={transaction.id}
                            onClick={() => onNavigate({ name: 'new-transaction', editTransactionId: transaction.id } as any)}
                            className="bg-white rounded-xl p-4 shadow-sm border border-pink-100 flex items-center gap-3 cursor-pointer hover:bg-pink-50 transition-colors"
                          >
                            <div 
                              className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                              style={{ backgroundColor: config.bgColor }}
                            >
                              <Icon className="w-5 h-5" style={{ color: config.color }} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-medium text-gray-800 truncate">
                                {transaction.description || transaction.category}
                              </p>
                              <p className="text-sm text-gray-500">{transaction.category}</p>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className={cn(
                                'font-bold font-poppins whitespace-nowrap',
                                transaction.type === 'INCOME' ? 'text-emerald-500' : 'text-pink-500'
                              )}>
                                {transaction.type === 'INCOME' ? '+' : '-'}
                                {formatCurrency(transaction.amountCents)}
                              </span>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDelete(transaction.id);
                                }}
                                className="p-2 rounded-lg hover:bg-red-50 transition-colors"
                              >
                                <Trash2 className="w-4 h-4 text-red-400" />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </main>
      
      {/* FAB */}
      <button
        onClick={() => onNavigate({ name: 'new-transaction' } as any)}
        className="fixed bottom-6 right-6 bg-gradient-to-r from-pink-400 to-pink-500 text-white px-5 py-4 rounded-2xl shadow-lg font-semibold flex items-center gap-2 transition-all hover:scale-105"
        style={{ boxShadow: '0 8px 24px rgba(236, 72, 153, 0.4)' }}
      >
        <Plus className="w-5 h-5" />
        Nova Transação
      </button>
    </div>
  );
}
