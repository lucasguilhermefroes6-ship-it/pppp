import { useEffect, useState } from 'react';
import { Screen } from '../types/screens';
import { useMeasurementsStore, MEASUREMENT_FIELDS } from '../store/useMeasurementsStore';

interface Props {
  setScreen: (screen: Screen) => void;
  entryId?: string;
}

export default function MeasurementEditScreen({ setScreen, entryId }: Props) {
  const { addEntry, updateEntry, getEntryById, getEntryByDate } = useMeasurementsStore();
  
  const [dateKey, setDateKey] = useState(new Date().toISOString().split('T')[0]);
  const [weightKg, setWeightKg] = useState('');
  const [waistCm, setWaistCm] = useState('');
  const [bustCm, setBustCm] = useState('');
  const [armCm, setArmCm] = useState('');
  const [hipCm, setHipCm] = useState('');
  const [thighCm, setThighCm] = useState(''); // NOVO - Coxa
  const [note, setNote] = useState('');
  const [error, setError] = useState('');
  const [showDateConflict, setShowDateConflict] = useState(false);
  
  const isEditing = !!entryId;
  
  useEffect(() => {
    if (entryId) {
      const entry = getEntryById(entryId);
      if (entry) {
        setDateKey(entry.dateKey);
        setWeightKg(entry.weightKg?.toString() || '');
        setWaistCm(entry.waistCm?.toString() || '');
        setBustCm(entry.bustCm?.toString() || '');
        setArmCm(entry.armCm?.toString() || '');
        setHipCm(entry.hipCm?.toString() || '');
        setThighCm(entry.thighCm?.toString() || ''); // NOVO
        setNote(entry.note || '');
      }
    }
  }, [entryId, getEntryById]);
  
  const parseValue = (value: string): number | undefined => {
    if (!value.trim()) return undefined;
    const parsed = parseFloat(value.replace(',', '.'));
    return isNaN(parsed) || parsed < 0 ? undefined : parsed;
  };
  
  const handleSave = async () => {
    setError('');
    
    // Validate at least one measurement
    const weight = parseValue(weightKg);
    const waist = parseValue(waistCm);
    const bust = parseValue(bustCm);
    const arm = parseValue(armCm);
    const hip = parseValue(hipCm);
    const thigh = parseValue(thighCm); // NOVO
    
    if (!weight && !waist && !bust && !arm && !hip && !thigh) {
      setError('Preencha pelo menos uma medida');
      return;
    }
    
    // Check for existing entry on same date (only when creating new)
    if (!isEditing) {
      const existing = getEntryByDate(dateKey);
      if (existing) {
        setShowDateConflict(true);
        return;
      }
    }
    
    const data = {
      dateKey,
      weightKg: weight,
      waistCm: waist,
      bustCm: bust,
      armCm: arm,
      hipCm: hip,
      thighCm: thigh, // NOVO
      note: note.trim() || undefined,
    };
    
    if (isEditing && entryId) {
      await updateEntry(entryId, data);
    } else {
      await addEntry(data);
    }
    
    setScreen({ name: 'measurements' });
  };
  
  const handleReplaceExisting = async () => {
    const existing = getEntryByDate(dateKey);
    if (existing) {
      const data = {
        dateKey,
        weightKg: parseValue(weightKg),
        waistCm: parseValue(waistCm),
        bustCm: parseValue(bustCm),
        armCm: parseValue(armCm),
        hipCm: parseValue(hipCm),
        thighCm: parseValue(thighCm), // NOVO
        note: note.trim() || undefined,
      };
      await updateEntry(existing.id, data);
    }
    setShowDateConflict(false);
    setScreen({ name: 'measurements' });
  };
  
  const formatDate = (dateKey: string) => {
    const [year, month, day] = dateKey.split('-');
    return `${day}/${month}/${year}`;
  };
  
  // Mapeamento dos campos para os estados
  const getFieldValue = (key: string): string => {
    switch (key) {
      case 'weightKg': return weightKg;
      case 'waistCm': return waistCm;
      case 'bustCm': return bustCm;
      case 'armCm': return armCm;
      case 'hipCm': return hipCm;
      case 'thighCm': return thighCm;
      default: return '';
    }
  };
  
  const setFieldValue = (key: string, val: string) => {
    switch (key) {
      case 'weightKg': setWeightKg(val); break;
      case 'waistCm': setWaistCm(val); break;
      case 'bustCm': setBustCm(val); break;
      case 'armCm': setArmCm(val); break;
      case 'hipCm': setHipCm(val); break;
      case 'thighCm': setThighCm(val); break;
    }
  };

  return (
    <div className="min-h-screen bg-[#FFF5F8]">
      {/* Header */}
      <div className="bg-gradient-to-br from-pink-400 via-pink-500 to-rose-500 px-4 pt-12 pb-6">
        <div className="flex items-center justify-between">
          <button 
            onClick={() => setScreen({ name: 'measurements' })}
            className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center"
          >
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
          
          <h1 className="text-xl font-bold text-white font-poppins">
            {isEditing ? 'Editar Medição' : 'Nova Medição'}
          </h1>
          
          <button 
            onClick={handleSave}
            className="px-4 py-2 bg-white rounded-full flex items-center gap-2"
          >
            <svg className="w-5 h-5 text-pink-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
            <span className="text-pink-500 font-semibold">Salvar</span>
          </button>
        </div>
      </div>
      
      <div className="px-4 py-6 space-y-4">
        {/* Hero Card */}
        <div className="bg-gradient-to-br from-pink-400 to-rose-500 rounded-2xl p-5 text-white">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center">
              <span className="text-3xl">📏</span>
            </div>
            <div>
              <h2 className="text-xl font-bold font-poppins">
                {isEditing ? 'Editar Medição' : 'Registrar Medidas'}
              </h2>
              <p className="text-pink-100 text-sm">
                {isEditing ? `Atualizando ${formatDate(dateKey)}` : 'Acompanhe sua evolução corporal'}
              </p>
            </div>
          </div>
        </div>
        
        {/* Error */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-red-600 text-sm">
            ⚠️ {error}
          </div>
        )}
        
        {/* Data */}
        <div className="bg-white rounded-2xl shadow-sm border border-pink-100 p-4">
          <label className="block text-sm font-bold text-gray-700 mb-2 font-poppins">
            📅 Data da Medição
          </label>
          <input
            type="date"
            value={dateKey}
            onChange={(e) => setDateKey(e.target.value)}
            max={new Date().toISOString().split('T')[0]}
            min="2000-01-01"
            className="w-full px-4 py-3 border border-pink-200 rounded-xl focus:ring-2 focus:ring-pink-300 focus:border-pink-400 text-lg"
          />
          <p className="text-xs text-gray-400 mt-2">
            Você pode registrar medições de datas antigas
          </p>
        </div>
        
        {/* Medidas */}
        <div className="bg-white rounded-2xl shadow-sm border border-pink-100 p-4">
          <h3 className="text-sm font-bold text-gray-700 mb-4 font-poppins">📐 Medidas</h3>
          
          <div className="grid grid-cols-2 gap-3">
            {MEASUREMENT_FIELDS.map(field => (
              <div key={field.key} className="space-y-1">
                <label className="flex items-center gap-1 text-sm text-gray-600">
                  <span>{field.icon}</span>
                  <span>{field.label}</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    inputMode="decimal"
                    value={getFieldValue(field.key)}
                    onChange={(e) => setFieldValue(field.key, e.target.value)}
                    placeholder={`Ex: ${field.key === 'weightKg' ? '65,5' : '70'}`}
                    className="w-full px-3 py-3 pr-10 border border-pink-200 rounded-xl focus:ring-2 focus:ring-pink-300 focus:border-pink-400"
                  />
                  <span 
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-sm font-medium"
                    style={{ color: field.color }}
                  >
                    {field.unit}
                  </span>
                </div>
              </div>
            ))}
          </div>
          
          <p className="text-xs text-gray-400 mt-3 text-center">
            Preencha pelo menos uma medida • Use vírgula ou ponto para decimais
          </p>
        </div>
        
        {/* Info sobre regras de progresso */}
        <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-2xl p-4 border border-green-100">
          <h3 className="font-bold text-green-700 mb-2 font-poppins">📊 Como medimos seu progresso</h3>
          <div className="text-sm text-green-600 space-y-1">
            <p>• <strong>Peso, Cintura, Braço, Busto:</strong> ↓ diminuir = progresso positivo</p>
            <p>• <strong>Quadril, Coxa:</strong> ↑ aumentar = progresso positivo</p>
          </div>
        </div>
        
        {/* Observações */}
        <div className="bg-white rounded-2xl shadow-sm border border-pink-100 p-4">
          <label className="block text-sm font-bold text-gray-700 mb-2 font-poppins">
            📝 Observações (opcional)
          </label>
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Ex: Após treino, pela manhã, etc..."
            rows={2}
            className="w-full px-4 py-3 border border-pink-200 rounded-xl focus:ring-2 focus:ring-pink-300 focus:border-pink-400 resize-none"
          />
        </div>
        
        {/* Dicas */}
        <div className="bg-gradient-to-br from-pink-50 to-rose-50 rounded-2xl p-4 border border-pink-100">
          <h3 className="font-bold text-pink-700 mb-2 font-poppins">💡 Dicas para medir</h3>
          <ul className="text-sm text-pink-600 space-y-1">
            <li>• Meça sempre no mesmo horário (de preferência pela manhã)</li>
            <li>• Use uma fita métrica flexível para circunferências</li>
            <li>• Cintura: na parte mais fina do tronco</li>
            <li>• Quadril: na parte mais larga</li>
            <li>• Braço: no meio do bíceps relaxado</li>
            <li>• Coxa: na parte mais grossa da coxa</li>
          </ul>
        </div>
        
        {/* Botão grande */}
        <button
          onClick={handleSave}
          className="w-full py-4 bg-gradient-to-r from-pink-500 to-rose-500 text-white rounded-2xl font-bold font-poppins text-lg shadow-lg"
        >
          {isEditing ? 'Salvar Alterações' : 'Registrar Medição'}
        </button>
      </div>
      
      {/* Modal de conflito de data */}
      {showDateConflict && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full">
            <div className="text-center mb-4">
              <span className="text-4xl">⚠️</span>
              <h3 className="text-lg font-bold text-gray-800 mt-2">Medição existente</h3>
              <p className="text-gray-600 text-sm mt-1">
                Já existe uma medição registrada para {formatDate(dateKey)}. Deseja substituir?
              </p>
            </div>
            
            <div className="flex gap-3">
              <button
                onClick={() => setShowDateConflict(false)}
                className="flex-1 py-3 border border-gray-300 rounded-xl font-medium text-gray-700"
              >
                Cancelar
              </button>
              <button
                onClick={handleReplaceExisting}
                className="flex-1 py-3 bg-pink-500 text-white rounded-xl font-medium"
              >
                Substituir
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
