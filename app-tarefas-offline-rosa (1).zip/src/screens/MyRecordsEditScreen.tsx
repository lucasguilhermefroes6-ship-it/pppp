import { useState, useEffect } from 'react';
import { Screen } from '../types/screens';
import { useMyRecordsStore, formatDateKey, computeFastingMinutes, formatMinutesToHhMm } from '../store/useMyRecordsStore';

interface Props {
  setScreen: (screen: Screen) => void;
  dateKey?: string;
}

const COLORS = {
  primary: '#FF2D95',
  background: '#FFF3FA',
  card: '#FFFFFF',
  border: '#EFB2D3',
  textPrimary: '#241225',
  textSecondary: '#6B3D5F',
  success: '#2E7D32',
  error: '#C62828',
};

export default function MyRecordsEditScreen({ setScreen, dateKey }: Props) {
  const { initDB, getRecord, upsertRecord, deleteRecord } = useMyRecordsStore();
  
  const [selectedDate, setSelectedDate] = useState(dateKey || formatDateKey(new Date()));
  const [calories, setCalories] = useState('');
  const [fastingStart, setFastingStart] = useState('');
  const [fastingEnd, setFastingEnd] = useState('');
  const [note, setNote] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    const init = async () => {
      await initDB();
      setIsLoading(false);
    };
    init();
  }, [initDB]);
  
  useEffect(() => {
    if (!isLoading) {
      const record = getRecord(selectedDate);
      if (record) {
        setCalories(record.caloriesKcal?.toString() || '');
        setFastingStart(record.fastingStartTime || '');
        setFastingEnd(record.fastingEndTime || '');
        setNote(record.note || '');
      } else {
        setCalories('');
        setFastingStart('');
        setFastingEnd('');
        setNote('');
      }
    }
  }, [selectedDate, isLoading, getRecord]);
  
  const fastingDuration = computeFastingMinutes(fastingStart, fastingEnd);
  
  const handleSave = async () => {
    // Validação: pelo menos um campo preenchido
    if (!calories && !fastingStart && !fastingEnd) {
      alert('Preencha pelo menos calorias ou jejum.');
      return;
    }
    
    // Se preencher um horário, exigir o outro
    if ((fastingStart && !fastingEnd) || (!fastingStart && fastingEnd)) {
      alert('Preencha os dois horários do jejum ou deixe ambos vazios.');
      return;
    }
    
    setIsSaving(true);
    try {
      await upsertRecord({
        dateKey: selectedDate,
        caloriesKcal: calories ? parseInt(calories) : undefined,
        fastingStartTime: fastingStart || undefined,
        fastingEndTime: fastingEnd || undefined,
        note: note || undefined,
      });
      setScreen({ name: 'my-records' });
    } catch (error) {
      console.error('Error saving:', error);
      alert('Erro ao salvar. Tente novamente.');
    }
    setIsSaving(false);
  };
  
  const handleDelete = async () => {
    const record = getRecord(selectedDate);
    if (record) {
      await deleteRecord(record.id);
    }
    setScreen({ name: 'my-records' });
  };
  
  const formatDateDisplay = (dateStr: string) => {
    const date = new Date(dateStr + 'T12:00:00');
    return date.toLocaleDateString('pt-BR', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
  };
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: COLORS.background }}>
        <div className="w-12 h-12 border-4 border-pink-200 border-t-pink-500 rounded-full animate-spin" />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen pb-8" style={{ background: COLORS.background }}>
      {/* Header */}
      <div 
        className="pt-12 pb-6 px-5"
        style={{ background: `linear-gradient(135deg, ${COLORS.primary}20, ${COLORS.background})` }}
      >
        <div className="flex items-center justify-between">
          <button
            onClick={() => setScreen({ name: 'my-records' })}
            className="w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center"
          >
            <svg className="w-5 h-5" fill="none" stroke={COLORS.primary} viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
          
          <button
            onClick={handleSave}
            disabled={isSaving}
            className="px-5 py-2.5 rounded-xl flex items-center gap-2 shadow-md"
            style={{ 
              background: `linear-gradient(135deg, ${COLORS.primary}, #FF6B9D)`,
              opacity: isSaving ? 0.7 : 1
            }}
          >
            <svg className="w-4 h-4" fill="none" stroke="white" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
            <span className="text-white font-semibold">
              {isSaving ? 'Salvando...' : 'Salvar'}
            </span>
          </button>
        </div>
        
        <h1 className="text-2xl font-bold mt-4" style={{ color: COLORS.textPrimary }}>
          {dateKey ? 'Editar Registro' : 'Novo Registro'}
        </h1>
      </div>
      
      <div className="px-5 -mt-2 space-y-4">
        {/* Hero Card */}
        <div 
          className="rounded-2xl p-5"
          style={{ 
            background: `linear-gradient(135deg, ${COLORS.primary}, #FF6B9D)`,
            boxShadow: '0 4px 15px rgba(255, 45, 149, 0.3)'
          }}
        >
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-white/20 flex items-center justify-center">
              <span className="text-3xl">📊</span>
            </div>
            <div>
              <h2 className="text-white text-lg font-bold">Registro de Saúde</h2>
              <p className="text-white/80 text-sm">Acompanhe calorias e jejum</p>
            </div>
          </div>
        </div>
        
        {/* Date Picker */}
        <div 
          className="rounded-2xl p-4"
          style={{ 
            background: COLORS.card, 
            border: `1.5px solid ${COLORS.border}`,
            boxShadow: '0 2px 8px rgba(0,0,0,0.06)'
          }}
        >
          <label className="block font-semibold mb-2" style={{ color: COLORS.textPrimary }}>
            📅 Data do Registro
          </label>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            max={formatDateKey(new Date())}
            min="2000-01-01"
            className="w-full p-3 rounded-xl text-lg font-medium"
            style={{ 
              background: '#F8F4F6',
              color: COLORS.textPrimary,
              border: `1px solid ${COLORS.border}`
            }}
          />
          <p className="text-sm mt-2" style={{ color: COLORS.textSecondary }}>
            {formatDateDisplay(selectedDate)}
          </p>
        </div>
        
        {/* Calories */}
        <div 
          className="rounded-2xl p-4"
          style={{ 
            background: COLORS.card, 
            border: `1.5px solid ${COLORS.border}`,
            boxShadow: '0 2px 8px rgba(0,0,0,0.06)'
          }}
        >
          <label className="block font-semibold mb-3" style={{ color: COLORS.textPrimary }}>
            🔥 Calorias do Dia
          </label>
          
          <div className="relative">
            <input
              type="number"
              value={calories}
              onChange={(e) => setCalories(e.target.value)}
              placeholder="Ex: 1850"
              min="0"
              max="10000"
              className="w-full p-4 rounded-xl text-2xl font-bold text-center"
              style={{ 
                background: '#F8F4F6',
                color: COLORS.textPrimary,
                border: `1px solid ${COLORS.border}`
              }}
            />
            <span 
              className="absolute right-4 top-1/2 -translate-y-1/2 font-medium"
              style={{ color: COLORS.textSecondary }}
            >
              kcal
            </span>
          </div>
          
          {/* Quick buttons */}
          <div className="flex flex-wrap gap-2 mt-3">
            {[1200, 1500, 1800, 2000, 2200].map((val) => (
              <button
                key={val}
                onClick={() => setCalories(val.toString())}
                className="px-3 py-1.5 rounded-lg text-sm font-medium transition-colors"
                style={{ 
                  background: calories === val.toString() ? COLORS.primary : '#F8F4F6',
                  color: calories === val.toString() ? 'white' : COLORS.textSecondary,
                  border: `1px solid ${COLORS.border}`
                }}
              >
                {val}
              </button>
            ))}
          </div>
        </div>
        
        {/* Fasting */}
        <div 
          className="rounded-2xl p-4"
          style={{ 
            background: COLORS.card, 
            border: `1.5px solid ${COLORS.border}`,
            boxShadow: '0 2px 8px rgba(0,0,0,0.06)'
          }}
        >
          <label className="block font-semibold mb-3" style={{ color: COLORS.textPrimary }}>
            ⏱️ Jejum Intermitente
          </label>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm mb-1" style={{ color: COLORS.textSecondary }}>
                Parei de comer
              </label>
              <input
                type="time"
                value={fastingStart}
                onChange={(e) => setFastingStart(e.target.value)}
                className="w-full p-3 rounded-xl text-center font-medium"
                style={{ 
                  background: '#F8F4F6',
                  color: COLORS.textPrimary,
                  border: `1px solid ${COLORS.border}`
                }}
              />
              <p className="text-xs text-center mt-1" style={{ color: COLORS.textSecondary }}>
                (noite anterior)
              </p>
            </div>
            
            <div>
              <label className="block text-sm mb-1" style={{ color: COLORS.textSecondary }}>
                Comecei a comer
              </label>
              <input
                type="time"
                value={fastingEnd}
                onChange={(e) => setFastingEnd(e.target.value)}
                className="w-full p-3 rounded-xl text-center font-medium"
                style={{ 
                  background: '#F8F4F6',
                  color: COLORS.textPrimary,
                  border: `1px solid ${COLORS.border}`
                }}
              />
              <p className="text-xs text-center mt-1" style={{ color: COLORS.textSecondary }}>
                (dia seguinte)
              </p>
            </div>
          </div>
          
          {/* Duration display */}
          {fastingDuration !== null && (
            <div 
              className="mt-4 p-3 rounded-xl text-center"
              style={{ background: `${COLORS.success}15` }}
            >
              <p className="text-sm" style={{ color: COLORS.textSecondary }}>
                Duração do jejum:
              </p>
              <p className="text-2xl font-bold" style={{ color: COLORS.success }}>
                {formatMinutesToHhMm(fastingDuration)}
              </p>
            </div>
          )}
          
          {/* Common fasting presets */}
          <div className="mt-3">
            <p className="text-xs mb-2" style={{ color: COLORS.textSecondary }}>
              Atalhos comuns:
            </p>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => { setFastingStart('20:00'); setFastingEnd('12:00'); }}
                className="px-3 py-1.5 rounded-lg text-xs font-medium"
                style={{ 
                  background: '#F8F4F6',
                  color: COLORS.textSecondary,
                  border: `1px solid ${COLORS.border}`
                }}
              >
                16h (20:00→12:00)
              </button>
              <button
                onClick={() => { setFastingStart('21:00'); setFastingEnd('11:00'); }}
                className="px-3 py-1.5 rounded-lg text-xs font-medium"
                style={{ 
                  background: '#F8F4F6',
                  color: COLORS.textSecondary,
                  border: `1px solid ${COLORS.border}`
                }}
              >
                14h (21:00→11:00)
              </button>
              <button
                onClick={() => { setFastingStart('19:00'); setFastingEnd('11:00'); }}
                className="px-3 py-1.5 rounded-lg text-xs font-medium"
                style={{ 
                  background: '#F8F4F6',
                  color: COLORS.textSecondary,
                  border: `1px solid ${COLORS.border}`
                }}
              >
                16h (19:00→11:00)
              </button>
            </div>
          </div>
        </div>
        
        {/* Note */}
        <div 
          className="rounded-2xl p-4"
          style={{ 
            background: COLORS.card, 
            border: `1.5px solid ${COLORS.border}`,
            boxShadow: '0 2px 8px rgba(0,0,0,0.06)'
          }}
        >
          <label className="block font-semibold mb-2" style={{ color: COLORS.textPrimary }}>
            📝 Observações (opcional)
          </label>
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Como você se sentiu? Alguma observação especial?"
            rows={3}
            className="w-full p-3 rounded-xl resize-none"
            style={{ 
              background: '#F8F4F6',
              color: COLORS.textPrimary,
              border: `1px solid ${COLORS.border}`
            }}
          />
        </div>
        
        {/* Delete button */}
        {dateKey && getRecord(selectedDate) && (
          <div className="pt-4">
            {!showDeleteConfirm ? (
              <button
                onClick={() => setShowDeleteConfirm(true)}
                className="w-full p-3 rounded-xl text-center font-medium transition-colors"
                style={{ 
                  background: '#FFEBEE',
                  color: COLORS.error,
                  border: `1px solid #FFCDD2`
                }}
              >
                🗑️ Excluir Registro
              </button>
            ) : (
              <div 
                className="p-4 rounded-xl space-y-3"
                style={{ background: '#FFEBEE', border: `1px solid #FFCDD2` }}
              >
                <p className="text-center font-medium" style={{ color: COLORS.error }}>
                  Tem certeza que deseja excluir?
                </p>
                <div className="flex gap-3">
                  <button
                    onClick={() => setShowDeleteConfirm(false)}
                    className="flex-1 p-2 rounded-lg font-medium"
                    style={{ background: 'white', color: COLORS.textSecondary }}
                  >
                    Cancelar
                  </button>
                  <button
                    onClick={handleDelete}
                    className="flex-1 p-2 rounded-lg font-medium"
                    style={{ background: COLORS.error, color: 'white' }}
                  >
                    Excluir
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
