import { useEffect, useState, ReactNode } from 'react';
import { Screen } from '../types/screens';
import { MeasurementField, MeasurementPeriod, MeasurementEntry } from '../types';
import { useMeasurementsStore, MEASUREMENT_FIELDS, getDeltaStyle } from '../store/useMeasurementsStore';

// Ícones SVG outline para cada medida
const MeasurementIcon = ({ icon, color, size = 20 }: { icon: string; color: string; size?: number }): ReactNode => {
  const iconMap: Record<string, ReactNode> = {
    scale: (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 3v17M5 6h14M4 10l3-4M20 10l-3-4M6 21h12M9 17h6" />
        <circle cx="12" cy="8" r="2" />
      </svg>
    ),
    ruler: (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.084a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0l8.59-3.902z" />
        <path d="M3.5 12v4.5l8.5 4 8.5-4V12" />
      </svg>
    ),
    heart: (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
      </svg>
    ),
    arm: (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z" />
        <line x1="4" y1="22" x2="4" y2="15" />
      </svg>
    ),
    sparkle: (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z" />
      </svg>
    ),
    leg: (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 2v8" />
        <path d="M10 10c0 6-2 10-2 10" />
        <path d="M14 10c0 6 2 10 2 10" />
        <circle cx="12" cy="6" r="2" />
      </svg>
    ),
  };
  
  return iconMap[icon] || <span style={{ color, fontSize: size }}>{icon}</span>;
};

interface Props {
  setScreen: (screen: Screen) => void;
}

const PERIODS: { key: MeasurementPeriod; label: string }[] = [
  { key: '30days', label: '30 dias' },
  { key: '3months', label: '3 meses' },
  { key: '6months', label: '6 meses' },
  { key: '1year', label: '1 ano' },
  { key: 'all', label: 'Tudo' },
];

export default function MeasurementsScreen({ setScreen }: Props) {
  const { entries, loadEntries, deleteEntry, getLatestEntry, getPreviousEntry, getSeriesForField } = useMeasurementsStore();
  const [selectedField, setSelectedField] = useState<MeasurementField>('weightKg');
  const [selectedPeriod, setSelectedPeriod] = useState<MeasurementPeriod>('6months');
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  
  useEffect(() => {
    loadEntries();
  }, [loadEntries]);
  
  const latestEntry = getLatestEntry();
  const previousEntry = getPreviousEntry();
  const chartData = getSeriesForField(selectedField, selectedPeriod);
  
  const formatDate = (dateKey: string) => {
    const [year, month, day] = dateKey.split('-');
    return `${day}/${month}/${year}`;
  };
  
  const getEntrySummary = (entry: MeasurementEntry) => {
    const parts: string[] = [];
    if (entry.weightKg) parts.push(`Peso ${entry.weightKg.toFixed(1)} kg`);
    if (entry.waistCm) parts.push(`Cintura ${entry.waistCm.toFixed(1)} cm`);
    if (entry.bustCm) parts.push(`Busto ${entry.bustCm.toFixed(1)} cm`);
    if (entry.armCm) parts.push(`Braço ${entry.armCm.toFixed(1)} cm`);
    if (entry.hipCm) parts.push(`Quadril ${entry.hipCm.toFixed(1)} cm`);
    if (entry.thighCm) parts.push(`Coxa ${entry.thighCm.toFixed(1)} cm`);
    return parts.slice(0, 2).join(' • ') || 'Sem medidas';
  };
  
  // Calculate chart dimensions
  const chartWidth = 100;
  const chartHeight = 100;
  
  const getChartPath = () => {
    if (chartData.length < 2) return '';
    
    const minValue = Math.min(...chartData.map(d => d.value));
    const maxValue = Math.max(...chartData.map(d => d.value));
    const range = maxValue - minValue || 1;
    const padding = range * 0.1;
    
    const points = chartData.map((d, i) => {
      const x = (i / (chartData.length - 1)) * chartWidth;
      const y = chartHeight - ((d.value - minValue + padding) / (range + padding * 2)) * chartHeight;
      return { x, y };
    });
    
    let path = `M ${points[0].x} ${points[0].y}`;
    for (let i = 1; i < points.length; i++) {
      const cp1x = points[i - 1].x + (points[i].x - points[i - 1].x) / 3;
      const cp1y = points[i - 1].y;
      const cp2x = points[i].x - (points[i].x - points[i - 1].x) / 3;
      const cp2y = points[i].y;
      path += ` C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${points[i].x} ${points[i].y}`;
    }
    
    return path;
  };
  
  const getChartPoints = () => {
    if (chartData.length < 1) return [];
    
    const minValue = Math.min(...chartData.map(d => d.value));
    const maxValue = Math.max(...chartData.map(d => d.value));
    const range = maxValue - minValue || 1;
    const padding = range * 0.1;
    
    return chartData.map((d, i) => ({
      x: chartData.length === 1 ? chartWidth / 2 : (i / (chartData.length - 1)) * chartWidth,
      y: chartHeight - ((d.value - minValue + padding) / (range + padding * 2)) * chartHeight,
      value: d.value,
      date: d.date,
    }));
  };
  
  const handleDelete = async (id: string) => {
    await deleteEntry(id);
    setDeleteConfirm(null);
  };
  
  const selectedFieldInfo = MEASUREMENT_FIELDS.find(f => f.key === selectedField);
  
  // Calcular delta para o gráfico
  const getChartDelta = () => {
    if (chartData.length < 2) return null;
    const first = chartData[0].value;
    const last = chartData[chartData.length - 1].value;
    return getDeltaStyle(selectedField, last, first);
  };
  
  const chartDelta = getChartDelta();

  return (
    <div className="min-h-screen bg-[#FFF5F8]">
      {/* Header */}
      <div className="bg-gradient-to-br from-pink-400 via-pink-500 to-rose-500 px-4 pt-12 pb-8">
        <div className="flex items-center justify-between mb-4">
          <button 
            onClick={() => setScreen({ name: 'home' })}
            className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center"
          >
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <button 
            onClick={() => setScreen({ name: 'measurement-edit' })}
            className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center"
          >
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
          </button>
        </div>
        
        <div className="text-center">
          <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-3">
            <span className="text-3xl">📏</span>
          </div>
          <h1 className="text-2xl font-bold text-white font-poppins">Medidas</h1>
          <p className="text-pink-100 text-sm mt-1">Acompanhe sua evolução</p>
        </div>
      </div>
      
      <div className="px-4 -mt-4 pb-24">
        {/* Última Medição */}
        <div className="bg-white rounded-2xl shadow-sm border border-pink-100 p-4 mb-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-gray-800 font-poppins">Última Medição</h2>
            {latestEntry && (
              <span className="text-sm text-gray-500">{formatDate(latestEntry.dateKey)}</span>
            )}
          </div>
          
          {latestEntry ? (
            <div className="grid grid-cols-2 gap-3">
              {MEASUREMENT_FIELDS.map(field => {
                const currentValue = latestEntry[field.key];
                const previousValue = previousEntry?.[field.key];
                const delta = getDeltaStyle(field.key, currentValue, previousValue);
                
                return (
                  <div 
                    key={field.key}
                    className="bg-pink-50 rounded-xl p-3 border border-pink-100"
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <span className="flex items-center justify-center w-6 h-6">
                        <MeasurementIcon icon={field.icon} color={field.color} size={18} />
                      </span>
                      <span className="text-sm text-gray-600">{field.label}</span>
                    </div>
                    <p className="text-xl font-bold" style={{ color: field.color }}>
                      {currentValue ? `${currentValue.toFixed(1)} ${field.unit}` : '—'}
                    </p>
                    
                    {/* Delta com cores corretas */}
                    {delta && currentValue && (
                      <div 
                        className="flex items-center gap-1 mt-1 text-xs font-medium"
                        style={{ color: delta.color }}
                      >
                        <span>{delta.icon}</span>
                        <span>{delta.text}</span>
                        {delta.isGood && delta.icon !== '→' && (
                          <span className="ml-1">✓</span>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-6">
              <span className="text-4xl mb-2 block">📐</span>
              <p className="text-gray-500">Nenhuma medição cadastrada</p>
              <button
                onClick={() => setScreen({ name: 'measurement-edit' })}
                className="mt-3 px-4 py-2 bg-pink-500 text-white rounded-full text-sm font-medium"
              >
                Adicionar primeira medição
              </button>
            </div>
          )}
        </div>
        
        {/* Legenda de cores */}
        {latestEntry && previousEntry && (
          <div className="bg-gradient-to-r from-pink-50 to-rose-50 rounded-xl p-3 mb-4 border border-pink-100">
            <p className="text-xs text-gray-600 text-center">
              <span className="inline-flex items-center gap-1 mr-3">
                <span className="w-2 h-2 rounded-full bg-green-500"></span>
                <span>Bom progresso</span>
              </span>
              <span className="inline-flex items-center gap-1 mr-3">
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: '#BE185D' }}></span>
                <span>Atenção</span>
              </span>
              <span className="inline-flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-gray-400"></span>
                <span>Estável</span>
              </span>
            </p>
            <p className="text-xs text-gray-500 text-center mt-1">
              ↓ Peso/Cintura/Braço/Busto = bom | ↑ Quadril/Coxa = bom
            </p>
          </div>
        )}
        
        {/* Gráfico de Evolução */}
        <div className="bg-white rounded-2xl shadow-sm border border-pink-100 p-4 mb-4">
          <h2 className="text-lg font-bold text-gray-800 font-poppins mb-4">Evolução</h2>
          
          {/* Seletor de campo */}
          <div className="flex flex-wrap gap-2 mb-4">
            {MEASUREMENT_FIELDS.map(field => (
              <button
                key={field.key}
                onClick={() => setSelectedField(field.key)}
                className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all flex items-center gap-1.5 ${
                  selectedField === field.key
                    ? 'text-white shadow-md'
                    : 'bg-pink-50 text-gray-600 hover:bg-pink-100'
                }`}
                style={selectedField === field.key ? { backgroundColor: field.color } : {}}
              >
                <span className="flex items-center justify-center w-4 h-4">
                  <MeasurementIcon 
                    icon={field.icon} 
                    color={selectedField === field.key ? '#FFFFFF' : field.color} 
                    size={14} 
                  />
                </span>
                {field.label}
              </button>
            ))}
          </div>
          
          {/* Seletor de período */}
          <div className="flex gap-1 mb-4 bg-pink-50 rounded-xl p-1">
            {PERIODS.map(period => (
              <button
                key={period.key}
                onClick={() => setSelectedPeriod(period.key)}
                className={`flex-1 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  selectedPeriod === period.key
                    ? 'bg-pink-500 text-white'
                    : 'text-gray-600'
                }`}
              >
                {period.label}
              </button>
            ))}
          </div>
          
          {/* Gráfico */}
          {chartData.length > 0 ? (
            <div className="bg-gradient-to-br from-pink-50 to-rose-50 rounded-xl p-4">
              <div className="relative" style={{ height: '150px' }}>
                <svg 
                  viewBox={`-5 -10 ${chartWidth + 10} ${chartHeight + 20}`} 
                  className="w-full h-full"
                  preserveAspectRatio="none"
                >
                  {/* Grid lines */}
                  {[0, 25, 50, 75, 100].map(y => (
                    <line
                      key={y}
                      x1={0}
                      y1={y}
                      x2={chartWidth}
                      y2={y}
                      stroke="#F3E5F5"
                      strokeWidth="0.5"
                    />
                  ))}
                  
                  {/* Line */}
                  {chartData.length > 1 && (
                    <path
                      d={getChartPath()}
                      fill="none"
                      stroke={selectedFieldInfo?.color || '#E91E63'}
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  )}
                  
                  {/* Points */}
                  {getChartPoints().map((point, i) => (
                    <g key={i}>
                      <circle
                        cx={point.x}
                        cy={point.y}
                        r="3"
                        fill="white"
                        stroke={selectedFieldInfo?.color || '#E91E63'}
                        strokeWidth="2"
                      />
                    </g>
                  ))}
                </svg>
              </div>
              
              {/* Stats */}
              <div className="flex justify-between mt-4 pt-3 border-t border-pink-100">
                <div className="text-center">
                  <p className="text-xs text-gray-500">Menor</p>
                  <p className="font-bold" style={{ color: selectedFieldInfo?.color }}>
                    {Math.min(...chartData.map(d => d.value)).toFixed(1)} {selectedFieldInfo?.unit}
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-gray-500">Média</p>
                  <p className="font-bold" style={{ color: selectedFieldInfo?.color }}>
                    {(chartData.reduce((sum, d) => sum + d.value, 0) / chartData.length).toFixed(1)} {selectedFieldInfo?.unit}
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-gray-500">Maior</p>
                  <p className="font-bold" style={{ color: selectedFieldInfo?.color }}>
                    {Math.max(...chartData.map(d => d.value)).toFixed(1)} {selectedFieldInfo?.unit}
                  </p>
                </div>
              </div>
              
              {/* Variação com cores corretas */}
              {chartDelta && (
                <div className="mt-3 text-center">
                  <p 
                    className="text-sm font-medium flex items-center justify-center gap-1"
                    style={{ color: chartDelta.color }}
                  >
                    <span>{chartDelta.icon}</span>
                    <span>{chartDelta.text} no período</span>
                    {chartDelta.isGood && chartDelta.icon !== '→' && (
                      <span className="ml-1">✓</span>
                    )}
                  </p>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-8 bg-pink-50 rounded-xl">
              <span className="text-3xl mb-2 block">📈</span>
              <p className="text-gray-500 text-sm">Sem dados para este período</p>
            </div>
          )}
        </div>
        
        {/* Histórico */}
        <div className="bg-white rounded-2xl shadow-sm border border-pink-100 p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-gray-800 font-poppins">Histórico</h2>
            <span className="text-sm text-gray-500">{entries.length} registro(s)</span>
          </div>
          
          {entries.length > 0 ? (
            <div className="space-y-2">
              {entries.slice(0, 20).map(entry => (
                <div 
                  key={entry.id}
                  className="flex items-center justify-between p-3 bg-pink-50 rounded-xl border border-pink-100"
                >
                  <div 
                    className="flex-1 cursor-pointer"
                    onClick={() => setScreen({ name: 'measurement-edit', entryId: entry.id })}
                  >
                    <p className="font-semibold text-gray-800">{formatDate(entry.dateKey)}</p>
                    <p className="text-sm text-gray-500">{getEntrySummary(entry)}</p>
                    {entry.note && (
                      <p className="text-xs text-gray-400 mt-1 truncate">📝 {entry.note}</p>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setScreen({ name: 'measurement-edit', entryId: entry.id })}
                      className="w-8 h-8 bg-white rounded-full flex items-center justify-center border border-pink-200"
                    >
                      <svg className="w-4 h-4 text-pink-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                      </svg>
                    </button>
                    
                    {deleteConfirm === entry.id ? (
                      <div className="flex gap-1">
                        <button
                          onClick={() => handleDelete(entry.id)}
                          className="px-2 py-1 bg-red-500 text-white rounded-lg text-xs"
                        >
                          Sim
                        </button>
                        <button
                          onClick={() => setDeleteConfirm(null)}
                          className="px-2 py-1 bg-gray-200 text-gray-600 rounded-lg text-xs"
                        >
                          Não
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setDeleteConfirm(entry.id)}
                        className="w-8 h-8 bg-white rounded-full flex items-center justify-center border border-pink-200"
                      >
                        <svg className="w-4 h-4 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-6">
              <span className="text-3xl mb-2 block">📋</span>
              <p className="text-gray-500">Nenhum registro ainda</p>
            </div>
          )}
        </div>
      </div>
      
      {/* FAB */}
      <button
        onClick={() => setScreen({ name: 'measurement-edit' })}
        className="fixed bottom-6 right-6 bg-gradient-to-r from-pink-500 to-rose-500 text-white px-5 py-3 rounded-full shadow-lg flex items-center gap-2 font-poppins font-semibold"
      >
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
        </svg>
        Nova Medição
      </button>
    </div>
  );
}
