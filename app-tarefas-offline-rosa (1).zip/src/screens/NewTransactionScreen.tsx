import { useState, useEffect } from 'react';
import { ArrowLeft, Check, Plus } from 'lucide-react';
import { format } from 'date-fns';
import { useFinanceStore, TransactionType, parseCurrencyInput } from '@/store/useFinanceStore';
import { Screen } from '@/types/screens';
import { cn } from '@/utils/cn';

interface NewTransactionScreenProps {
  onNavigate: (screen: Screen) => void;
  isFixed?: boolean;
  editTransactionId?: string;
}

export default function NewTransactionScreen({ onNavigate, isFixed = false, editTransactionId }: NewTransactionScreenProps) {
  const { 
    createTransaction, 
    updateTransaction, 
    getTransactionById, 
    getAllCategories, 
    createCategory,
    customCategories 
  } = useFinanceStore();
  
  const [type, setType] = useState<TransactionType>('EXPENSE');
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<string>('Alimentação');
  const [date, setDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [isFixedTransaction, setIsFixedTransaction] = useState(isFixed);
  const [showCategorySheet, setShowCategorySheet] = useState(false);
  const [showNewCategoryModal, setShowNewCategoryModal] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [newCategoryColor, setNewCategoryColor] = useState('#EC4899');
  const [isEditing, setIsEditing] = useState(false);
  
  // Carregar transação para edição
  useEffect(() => {
    if (editTransactionId) {
      const transaction = getTransactionById(editTransactionId);
      if (transaction) {
        setType(transaction.type);
        setAmount((transaction.amountCents / 100).toFixed(2).replace('.', ','));
        setDescription(transaction.description || '');
        setCategory(transaction.category);
        setDate(transaction.date);
        setIsFixedTransaction(transaction.isFixed);
        setIsEditing(true);
      }
    }
  }, [editTransactionId, getTransactionById]);
  
  const handleSubmit = async () => {
    const amountCents = parseCurrencyInput(amount);
    
    if (amountCents <= 0) {
      alert('Por favor, insira um valor válido.');
      return;
    }
    
    if (isEditing && editTransactionId) {
      // Update existing transaction
      const existingTransaction = getTransactionById(editTransactionId);
      if (existingTransaction) {
        await updateTransaction({
          ...existingTransaction,
          type,
          amountCents,
          description: description.trim() || undefined,
          category,
          date,
          isFixed: isFixedTransaction
        });
      }
    } else {
      // Create new transaction
      await createTransaction({
        type,
        amountCents,
        description: description.trim() || undefined,
        category,
        date,
        isFixed: isFixedTransaction
      });
    }
    
    onNavigate({ name: 'expenses' });
  };
  
  const handleCreateCategory = async () => {
    if (!newCategoryName.trim()) {
      alert('Por favor, insira um nome para a categoria.');
      return;
    }
    
    // Verificar se já existe
    const allCategories = getAllCategories();
    if (allCategories.includes(newCategoryName.trim())) {
      alert('Esta categoria já existe.');
      return;
    }
    
    await createCategory({
      name: newCategoryName.trim(),
      color: newCategoryColor,
      type: 'BOTH'
    });
    
    setCategory(newCategoryName.trim());
    setNewCategoryName('');
    setNewCategoryColor('#EC4899');
    setShowNewCategoryModal(false);
    setShowCategorySheet(false);
  };
  
  const allCategories = getAllCategories();
  
  const categoryColors = [
    // Rosas e Vermelhos
    '#EC4899', '#F43F5E', '#E11D48', '#DB2777', '#BE185D', '#FB7185',
    // Laranjas e Amarelos
    '#F97316', '#EA580C', '#EAB308', '#FBBF24', '#F59E0B', '#FCD34D',
    // Verdes
    '#22C55E', '#16A34A', '#15803D', '#4ADE80', '#10B981', '#14B8A6',
    // Azuis
    '#3B82F6', '#2563EB', '#1D4ED8', '#0EA5E9', '#06B6D4', '#38BDF8',
    // Roxos e Violetas
    '#8B5CF6', '#7C3AED', '#6D28D9', '#A855F7', '#D946EF', '#C026D3',
    // Neutros
    '#6B7280', '#4B5563', '#78716C', '#A3A3A3'
  ];
  
  return (
    <div className="min-h-screen bg-[#FFF5F8]">
      {/* Header */}
      <header className="bg-gradient-to-br from-pink-400 to-pink-500 text-white px-4 pt-10 pb-6">
        <div className="max-w-lg mx-auto">
          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate({ name: 'expenses' })}
              className="p-2 -ml-2 rounded-lg hover:bg-white/10 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-xl font-bold font-poppins">
              {isEditing ? 'Editar Transação' : 'Nova Transação'}
            </h1>
          </div>
        </div>
      </header>
      
      <main className="px-4 py-6 max-w-lg mx-auto space-y-4">
        {/* Type Toggle */}
        <div className="bg-white rounded-2xl p-2 shadow-sm border border-pink-100 flex">
          <button
            onClick={() => setType('INCOME')}
            className={cn(
              'flex-1 py-3 rounded-xl font-semibold transition-all',
              type === 'INCOME'
                ? 'bg-emerald-500 text-white shadow-sm'
                : 'text-gray-600 hover:bg-gray-50'
            )}
          >
            Receita
          </button>
          <button
            onClick={() => setType('EXPENSE')}
            className={cn(
              'flex-1 py-3 rounded-xl font-semibold transition-all',
              type === 'EXPENSE'
                ? 'bg-pink-500 text-white shadow-sm'
                : 'text-gray-600 hover:bg-gray-50'
            )}
          >
            Despesa
          </button>
        </div>
        
        {/* Amount */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-pink-100 text-center">
          <label className="block text-sm text-gray-500 mb-2">Valor</label>
          <div className="flex items-center justify-center">
            <span className="text-3xl font-bold text-gray-400 mr-2">R$</span>
            <input
              type="text"
              inputMode="decimal"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0,00"
              className={cn(
                'text-4xl font-bold text-center outline-none w-40',
                type === 'INCOME' ? 'text-emerald-500' : 'text-pink-500'
              )}
            />
          </div>
        </div>
        
        {/* Description */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
          <label className="block text-sm text-gray-500 mb-2">Descrição</label>
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Ex: Almoço no restaurante"
            className="w-full text-gray-800 outline-none text-lg"
          />
        </div>
        
        {/* Category */}
        <button
          onClick={() => setShowCategorySheet(true)}
          className="w-full bg-white rounded-2xl p-4 shadow-sm border border-pink-100 flex items-center justify-between"
        >
          <div>
            <span className="block text-sm text-gray-500">Categoria</span>
            <span className="text-gray-800 font-medium">{category}</span>
          </div>
          <ArrowLeft className="w-5 h-5 text-gray-400 rotate-180" />
        </button>
        
        {/* Date */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
          <label className="block text-sm text-gray-500 mb-2">Data</label>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="w-full text-gray-800 outline-none text-lg"
          />
        </div>
        
        {/* Fixed Transaction Toggle */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100 flex items-center justify-between">
          <div>
            <span className="block text-gray-800 font-medium">Transação Fixa</span>
            <span className="text-sm text-gray-500">Repete todo mês</span>
          </div>
          <button
            onClick={() => setIsFixedTransaction(!isFixedTransaction)}
            className={cn(
              'w-12 h-7 rounded-full transition-colors relative',
              isFixedTransaction ? 'bg-pink-500' : 'bg-gray-200'
            )}
          >
            <div
              className={cn(
                'absolute top-1 w-5 h-5 bg-white rounded-full shadow transition-transform',
                isFixedTransaction ? 'translate-x-6' : 'translate-x-1'
              )}
            />
          </button>
        </div>
        
        {/* Submit Button */}
        <button
          onClick={handleSubmit}
          disabled={!amount || parseCurrencyInput(amount) <= 0}
          className="w-full bg-gradient-to-r from-pink-400 to-pink-500 text-white py-4 rounded-2xl font-bold text-lg shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all hover:scale-[1.02]"
          style={{ boxShadow: '0 8px 24px rgba(236, 72, 153, 0.4)' }}
        >
          {isEditing ? 'Atualizar' : 'Salvar'}
        </button>
      </main>
      
      {/* Category Bottom Sheet */}
      {showCategorySheet && (
        <div className="fixed inset-0 bg-black/50 flex items-end z-50">
          <div className="bg-white w-full rounded-t-3xl max-h-[70vh] overflow-hidden">
            <div className="sticky top-0 bg-white px-6 py-4 border-b border-gray-100 flex items-center justify-between">
              <h3 className="text-lg font-bold text-pink-600 font-poppins">Selecionar Categoria</h3>
              <button
                onClick={() => setShowCategorySheet(false)}
                className="text-gray-400 hover:text-gray-600 text-2xl"
              >
                ×
              </button>
            </div>
            <div className="p-4 overflow-y-auto max-h-[50vh]">
              {/* Botão Nova Categoria */}
              <button
                onClick={() => setShowNewCategoryModal(true)}
                className="w-full py-4 px-4 rounded-xl text-left flex items-center gap-3 bg-pink-50 text-pink-600 mb-3 border-2 border-dashed border-pink-200 hover:bg-pink-100 transition-colors"
              >
                <div className="w-8 h-8 rounded-full bg-pink-200 flex items-center justify-center">
                  <Plus className="w-5 h-5" />
                </div>
                <span className="font-semibold">+ Nova categoria</span>
              </button>
              
              {/* Lista de Categorias */}
              {allCategories.map((cat) => {
                const customCat = customCategories.find(c => c.name === cat);
                
                return (
                  <button
                    key={cat}
                    onClick={() => {
                      setCategory(cat);
                      setShowCategorySheet(false);
                    }}
                    className={cn(
                      'w-full py-4 px-4 rounded-xl text-left flex items-center justify-between transition-colors',
                      category === cat
                        ? 'bg-pink-50 text-pink-600'
                        : 'text-gray-700 hover:bg-gray-50'
                    )}
                  >
                    <div className="flex items-center gap-3">
                      {customCat && (
                        <div 
                          className="w-4 h-4 rounded-full"
                          style={{ backgroundColor: customCat.color }}
                        />
                      )}
                      <span className="font-medium">{cat}</span>
                    </div>
                    {category === cat && <Check className="w-5 h-5 text-pink-500" />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
      
      {/* Modal Nova Categoria */}
      {showNewCategoryModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white w-full max-w-sm rounded-2xl overflow-hidden">
            <div className="bg-gradient-to-r from-pink-400 to-pink-500 px-6 py-4">
              <h3 className="text-lg font-bold text-white font-poppins">Nova Categoria</h3>
            </div>
            <div className="p-6 space-y-4">
              {/* Nome */}
              <div>
                <label className="block text-sm text-gray-500 mb-2">Nome da categoria</label>
                <input
                  type="text"
                  value={newCategoryName}
                  onChange={(e) => setNewCategoryName(e.target.value)}
                  placeholder="Ex: Mercado, Pet, Streaming..."
                  className="w-full px-4 py-3 border border-pink-200 rounded-xl outline-none focus:border-pink-400 text-gray-800"
                />
              </div>
              
              {/* Cor */}
              <div>
                <label className="block text-sm text-gray-500 mb-2">Cor</label>
                <div className="max-h-40 overflow-y-auto pr-1">
                  <div className="grid grid-cols-6 gap-2">
                    {categoryColors.map((color) => (
                      <button
                        key={color}
                        onClick={() => setNewCategoryColor(color)}
                        className={cn(
                          'w-9 h-9 rounded-lg transition-all',
                          newCategoryColor === color ? 'ring-2 ring-offset-2 ring-pink-500 scale-110' : 'hover:scale-105'
                        )}
                        style={{ backgroundColor: color }}
                      >
                        {newCategoryColor === color && (
                          <Check className="w-4 h-4 text-white mx-auto" />
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              
              {/* Preview */}
              <div className="bg-gray-50 rounded-xl p-3 flex items-center gap-3">
                <div 
                  className="w-8 h-8 rounded-lg"
                  style={{ backgroundColor: newCategoryColor }}
                />
                <span className="font-medium text-gray-800">
                  {newCategoryName || 'Nome da categoria'}
                </span>
              </div>
              
              {/* Botões */}
              <div className="flex gap-3 pt-2">
                <button
                  onClick={() => {
                    setShowNewCategoryModal(false);
                    setNewCategoryName('');
                  }}
                  className="flex-1 py-3 rounded-xl font-semibold border border-gray-200 text-gray-600 hover:bg-gray-50 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleCreateCategory}
                  disabled={!newCategoryName.trim()}
                  className="flex-1 py-3 rounded-xl font-semibold bg-pink-500 text-white hover:bg-pink-600 transition-colors disabled:opacity-50"
                >
                  Criar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
