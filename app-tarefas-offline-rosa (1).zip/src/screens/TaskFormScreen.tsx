import { useState, useEffect, useCallback } from 'react';
import { ArrowLeft, Plus, X, Tag, Bell, Repeat, Trash2 } from 'lucide-react';
import { format } from 'date-fns';
import { useStore } from '@/store/useStore';
import { Screen } from '@/types/screens';
import { AppCard } from '@/components/ui/AppCard';
import { PrimaryButton } from '@/components/ui/PrimaryButton';
import { PastelChip } from '@/components/ui/PastelChip';
import { RecurrenceEditor } from '@/components/RecurrenceEditor';
import { Priority, RecurrenceRule, TaskWithRelations } from '@/types';
import { cn } from '@/utils/cn';

interface TaskFormScreenProps {
  taskId?: string;
  onNavigate: (screen: Screen) => void;
}

export function TaskFormScreen({ taskId, onNavigate }: TaskFormScreenProps) {
  const { createTask, updateTask, deleteTask, getTaskWithRelations, categories, tags, createTag } = useStore();
  
  const [isLoading, setIsLoading] = useState(!!taskId);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [dueDate, setDueDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [dueTime, setDueTime] = useState('');
  const [priority, setPriority] = useState<Priority>(Priority.MEDIUM);
  const [listId, setListId] = useState('personal');
  const [reminderEnabled, setReminderEnabled] = useState(false);
  const [recurrenceEnabled, setRecurrenceEnabled] = useState(false);
  const [recurrenceRule, setRecurrenceRule] = useState<RecurrenceRule | null>(null);
  const [subtaskTitles, setSubtaskTitles] = useState<string[]>([]);
  const [newSubtask, setNewSubtask] = useState('');
  const [selectedTagIds, setSelectedTagIds] = useState<string[]>([]);
  const [newTagName, setNewTagName] = useState('');
  const [showNewTag, setShowNewTag] = useState(false);

  useEffect(() => {
    if (taskId) {
      loadTask(taskId);
    }
  }, [taskId]);

  const loadTask = async (id: string) => {
    const task = await getTaskWithRelations(id);
    if (task) {
      setTitle(task.title);
      setDescription(task.description || '');
      setDueDate(task.dueDate || format(new Date(), 'yyyy-MM-dd'));
      setDueTime(task.dueTime || '');
      setPriority(task.priority);
      setListId(task.listId);
      setReminderEnabled(task.reminderEnabled);
      setRecurrenceEnabled(task.recurrenceEnabled);
      if (task.recurrenceRuleJson) {
        try {
          setRecurrenceRule(JSON.parse(task.recurrenceRuleJson));
        } catch { /* ignore */ }
      }
      setSubtaskTitles(task.subtasks.map(s => s.title));
      setSelectedTagIds(task.tags.map(t => t.id));
    }
    setIsLoading(false);
  };

  const handleRecurrenceChange = useCallback((rule: RecurrenceRule) => {
    setRecurrenceRule(rule);
  }, []);

  const addSubtask = () => {
    if (newSubtask.trim()) {
      setSubtaskTitles([...subtaskTitles, newSubtask.trim()]);
      setNewSubtask('');
    }
  };

  const removeSubtask = (index: number) => {
    setSubtaskTitles(subtaskTitles.filter((_, i) => i !== index));
  };

  const toggleTag = (tagId: string) => {
    setSelectedTagIds(prev =>
      prev.includes(tagId)
        ? prev.filter(id => id !== tagId)
        : [...prev, tagId]
    );
  };

  const handleCreateTag = async () => {
    if (newTagName.trim()) {
      const colors = ['#E91E63', '#9C27B0', '#3F51B5', '#009688', '#FF9800'];
      const randomColor = colors[Math.floor(Math.random() * colors.length)];
      const tag = await createTag(newTagName.trim(), randomColor);
      setSelectedTagIds([...selectedTagIds, tag.id]);
      setNewTagName('');
      setShowNewTag(false);
    }
  };

  const handleSubmit = async () => {
    if (!title.trim()) return;

    const taskData = {
      title: title.trim(),
      description: description.trim() || undefined,
      dueDate: dueDate || undefined,
      dueTime: dueTime || undefined,
      priority,
      listId,
      reminderEnabled,
      recurrenceEnabled,
      recurrenceRuleJson: recurrenceEnabled && recurrenceRule
        ? JSON.stringify(recurrenceRule)
        : undefined,
      recurrenceAnchorDate: recurrenceEnabled ? dueDate : undefined,
    };

    if (taskId) {
      const existing = await getTaskWithRelations(taskId);
      if (existing) {
        await updateTask(
          { ...existing, ...taskData } as TaskWithRelations,
          subtaskTitles,
          selectedTagIds
        );
      }
    } else {
      await createTask(taskData, subtaskTitles, selectedTagIds);
    }

    onNavigate({ name: 'tasks' });
  };

  const handleDelete = async () => {
    if (taskId && confirm('Tem certeza que deseja excluir esta tarefa?')) {
      await deleteTask(taskId);
      onNavigate({ name: 'tasks' });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#FFF5F8] flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-pink-200 border-t-pink-500 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FFF5F8]">
      {/* Header */}
      <header className="bg-gradient-to-br from-pink-500 to-pink-600 text-white px-4 pt-10 pb-6">
        <div className="max-w-lg mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                onClick={() => onNavigate({ name: 'tasks' })}
                className="p-2 -ml-2 rounded-lg hover:bg-white/10 transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <h1 className="text-xl font-bold">
                {taskId ? 'Editar Tarefa' : 'Nova Tarefa'}
              </h1>
            </div>
            {taskId && (
              <button
                onClick={handleDelete}
                className="p-2 rounded-lg hover:bg-white/10 transition-colors text-white/80 hover:text-white"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Form */}
      <main className="px-4 py-6 pb-24 max-w-lg mx-auto space-y-4">
        {/* Basic Info */}
        <AppCard>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Título *
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="O que você precisa fazer?"
                className="w-full px-4 py-3 border border-pink-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Descrição
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Adicione mais detalhes..."
                rows={3}
                className="w-full px-4 py-3 border border-pink-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent resize-none"
              />
            </div>
          </div>
        </AppCard>

        {/* Date & Time */}
        <AppCard>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Data
              </label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full px-4 py-3 border border-pink-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Hora
              </label>
              <input
                type="time"
                value={dueTime}
                onChange={(e) => setDueTime(e.target.value)}
                className="w-full px-4 py-3 border border-pink-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent"
              />
            </div>
          </div>
        </AppCard>

        {/* Priority & Category */}
        <AppCard>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Prioridade
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as Priority)}
                className="w-full px-4 py-3 border border-pink-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent bg-white"
              >
                <option value={Priority.LOW}>Baixa</option>
                <option value={Priority.MEDIUM}>Média</option>
                <option value={Priority.HIGH}>Alta</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Lista
              </label>
              <select
                value={listId}
                onChange={(e) => setListId(e.target.value)}
                className="w-full px-4 py-3 border border-pink-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent bg-white"
              >
                {categories.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </AppCard>

        {/* Subtasks */}
        <AppCard>
          <div className="flex items-center gap-2 mb-3">
            <h3 className="font-semibold text-gray-900">Subtarefas</h3>
            <span className="text-sm text-gray-400">({subtaskTitles.length})</span>
          </div>
          
          <div className="space-y-2 mb-3">
            {subtaskTitles.map((st, index) => (
              <div
                key={index}
                className="flex items-center gap-2 bg-pink-50 rounded-lg px-3 py-2"
              >
                <span className="flex-1 text-sm text-gray-700">{st}</span>
                <button
                  onClick={() => removeSubtask(index)}
                  className="text-gray-400 hover:text-pink-500 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
          
          <div className="flex gap-2">
            <input
              type="text"
              value={newSubtask}
              onChange={(e) => setNewSubtask(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && addSubtask()}
              placeholder="Adicionar subtarefa..."
              className="flex-1 px-3 py-2 border border-pink-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-pink-500"
            />
            <button
              onClick={addSubtask}
              className="p-2 bg-pink-100 text-pink-600 rounded-lg hover:bg-pink-200 transition-colors"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>
        </AppCard>

        {/* Tags */}
        <AppCard>
          <div className="flex items-center gap-2 mb-3">
            <Tag className="w-4 h-4 text-gray-500" />
            <h3 className="font-semibold text-gray-900">Tags</h3>
          </div>
          
          <div className="flex flex-wrap gap-2 mb-3">
            {tags.map((tag) => (
              <PastelChip
                key={tag.id}
                color="pink"
                active={selectedTagIds.includes(tag.id)}
                onClick={() => toggleTag(tag.id)}
              >
                {tag.name}
              </PastelChip>
            ))}
            
            {!showNewTag && (
              <button
                onClick={() => setShowNewTag(true)}
                className="inline-flex items-center gap-1 px-3 py-1 text-sm text-pink-500 hover:bg-pink-50 rounded-full transition-colors"
              >
                <Plus className="w-4 h-4" />
                Nova tag
              </button>
            )}
          </div>
          
          {showNewTag && (
            <div className="flex gap-2">
              <input
                type="text"
                value={newTagName}
                onChange={(e) => setNewTagName(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleCreateTag()}
                placeholder="Nome da tag..."
                className="flex-1 px-3 py-2 border border-pink-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-pink-500"
                autoFocus
              />
              <button
                onClick={handleCreateTag}
                className="px-3 py-2 bg-pink-500 text-white rounded-lg text-sm font-medium"
              >
                Criar
              </button>
              <button
                onClick={() => {
                  setShowNewTag(false);
                  setNewTagName('');
                }}
                className="px-3 py-2 text-gray-500 hover:bg-gray-100 rounded-lg text-sm"
              >
                Cancelar
              </button>
            </div>
          )}
        </AppCard>

        {/* Reminder */}
        <AppCard>
          <label className="flex items-center justify-between cursor-pointer">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-pink-100 rounded-xl flex items-center justify-center">
                <Bell className="w-5 h-5 text-pink-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">Lembrete</h3>
                <p className="text-sm text-gray-500">Notificar na hora</p>
              </div>
            </div>
            <div
              className={cn(
                'w-12 h-7 rounded-full transition-colors relative',
                reminderEnabled ? 'bg-pink-500' : 'bg-gray-200'
              )}
              onClick={() => setReminderEnabled(!reminderEnabled)}
            >
              <div
                className={cn(
                  'absolute top-1 w-5 h-5 bg-white rounded-full shadow transition-transform',
                  reminderEnabled ? 'translate-x-6' : 'translate-x-1'
                )}
              />
            </div>
          </label>
        </AppCard>

        {/* Recurrence */}
        <AppCard>
          <label className="flex items-center justify-between cursor-pointer mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-pink-100 rounded-xl flex items-center justify-center">
                <Repeat className="w-5 h-5 text-pink-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">Recorrência</h3>
                <p className="text-sm text-gray-500">Repetir tarefa</p>
              </div>
            </div>
            <div
              className={cn(
                'w-12 h-7 rounded-full transition-colors relative',
                recurrenceEnabled ? 'bg-pink-500' : 'bg-gray-200'
              )}
              onClick={() => setRecurrenceEnabled(!recurrenceEnabled)}
            >
              <div
                className={cn(
                  'absolute top-1 w-5 h-5 bg-white rounded-full shadow transition-transform',
                  recurrenceEnabled ? 'translate-x-6' : 'translate-x-1'
                )}
              />
            </div>
          </label>
          
          {recurrenceEnabled && (
            <div className="pt-4 border-t border-pink-100">
              <RecurrenceEditor
                value={recurrenceRule}
                onChange={handleRecurrenceChange}
              />
            </div>
          )}
        </AppCard>
      </main>

      {/* Submit Button */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-pink-100 px-4 py-4">
        <div className="max-w-lg mx-auto">
          <PrimaryButton
            fullWidth
            size="lg"
            onClick={handleSubmit}
            disabled={!title.trim()}
          >
            {taskId ? 'Salvar Alterações' : 'Criar Tarefa'}
          </PrimaryButton>
        </div>
      </div>
    </div>
  );
}
