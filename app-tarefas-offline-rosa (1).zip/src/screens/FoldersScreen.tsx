import React, { useEffect, useState } from 'react';
import { 
  ArrowLeft, Search, Plus, Folder, MoreVertical, Pin, Star,
  FileText, Link, CheckSquare, Sparkles, Sun, Moon, GraduationCap,
  Briefcase, Home, ChefHat, Dumbbell, Wallet, Heart, Plane, BookOpen,
  Edit, Trash2, X
} from 'lucide-react';
import { Screen } from '../types/screens';
import { useFolderStore, SUGGESTED_FOLDERS } from '../store/useFolderStore';

interface FoldersScreenProps {
  onNavigate: (screen: Screen) => void;
}

// Mapeamento de ícones
const iconMap: Record<string, React.ElementType> = {
  Folder, Sparkles, Sun, Moon, GraduationCap, Briefcase, Home,
  ChefHat, Dumbbell, Wallet, Heart, Plane, BookOpen, FileText, Link, CheckSquare, Star
};

function getIcon(name: string): React.ElementType {
  return iconMap[name] || Folder;
}

function getItemIcon(type: string): React.ElementType {
  switch (type) {
    case 'NOTE': return FileText;
    case 'LINK': return Link;
    case 'CHECKLIST': return CheckSquare;
    default: return FileText;
  }
}

export default function FoldersScreen({ onNavigate }: FoldersScreenProps) {
  const { 
    folders, 
    loadFolders, 
    deleteFolder,
    countItems,
    getPinnedItems,
    countPinnedItems,
    showSuggestionsModal,
    setShowSuggestionsModal,
    createSuggestedFolders
  } = useFolderStore();
  
  const [menuOpen, setMenuOpen] = useState<string | null>(null);
  const pinnedItems = getPinnedItems(5);
  const pinnedCount = countPinnedItems();
  
  useEffect(() => {
    loadFolders();
  }, [loadFolders]);
  
  const handleDeleteFolder = async (id: string) => {
    if (confirm('Excluir esta pasta e todos os itens?')) {
      await deleteFolder(id);
    }
    setMenuOpen(null);
  };
  
  return (
    <div className="min-h-screen bg-[#FFF5F8]">
      {/* Header */}
      <div className="bg-gradient-to-r from-pink-400 to-pink-500 pt-12 pb-6 px-4">
        <div className="flex items-center justify-between mb-4">
          <button 
            onClick={() => onNavigate({ name: 'home' })}
            className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <h1 className="text-xl font-bold text-white font-['Poppins']">Pastas</h1>
          <button 
            onClick={() => onNavigate({ name: 'folders-search' })}
            className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center"
          >
            <Search className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>
      
      <div className="px-4 -mt-4 pb-24">
        {/* Card Resumo */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100 mb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 bg-pink-50 rounded-xl flex items-center justify-center">
                <Folder className="w-7 h-7 text-pink-500" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-800 font-['Poppins']">Suas Pastas</h2>
                <p className="text-gray-500 text-sm">
                  {folders.length} coleções • {pinnedCount} favoritos
                </p>
              </div>
            </div>
            <div className="w-10 h-10 bg-pink-50 rounded-full flex items-center justify-center">
              <span className="text-pink-500 font-bold">{folders.length}</span>
            </div>
          </div>
        </div>
        
        {/* Seção Favoritos */}
        {pinnedItems.length > 0 && (
          <div className="mb-4">
            <div className="flex items-center gap-2 mb-3">
              <Star className="w-5 h-5 text-pink-500" />
              <h3 className="text-lg font-bold text-pink-600 font-['Poppins']">Favoritos</h3>
            </div>
            <div className="space-y-2">
              {pinnedItems.map((item) => {
                const ItemIcon = getItemIcon(item.type);
                return (
                  <button
                    key={item.id}
                    onClick={() => onNavigate({ 
                      name: 'folder-item-edit', 
                      folderId: item.folderId, 
                      itemId: item.id 
                    })}
                    className="w-full bg-white rounded-xl p-3 shadow-sm border border-pink-100 flex items-center gap-3 text-left"
                  >
                    <div 
                      className="w-10 h-10 rounded-lg flex items-center justify-center"
                      style={{ backgroundColor: `${item.folderColorHex}20` }}
                    >
                      <ItemIcon className="w-5 h-5" style={{ color: item.folderColorHex }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-gray-800 truncate">{item.title}</p>
                      <p className="text-xs text-gray-500 truncate">{item.folderName}</p>
                    </div>
                    <Pin className="w-4 h-4 text-pink-400" />
                  </button>
                );
              })}
            </div>
          </div>
        )}
        
        {/* Grid de Pastas */}
        <div className="flex items-center gap-2 mb-3">
          <Folder className="w-5 h-5 text-pink-500" />
          <h3 className="text-lg font-bold text-pink-600 font-['Poppins']">Coleções</h3>
        </div>
        
        {folders.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 text-center border border-pink-100">
            <div className="w-16 h-16 bg-pink-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Folder className="w-8 h-8 text-pink-300" />
            </div>
            <h3 className="text-lg font-semibold text-gray-700 mb-2">Nenhuma pasta ainda</h3>
            <p className="text-gray-500 text-sm mb-4">Crie pastas para organizar suas ideias!</p>
            <button
              onClick={() => setShowSuggestionsModal(true)}
              className="text-pink-500 font-semibold text-sm"
            >
              Criar pastas sugeridas
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {folders.map((folder) => {
              const Icon = getIcon(folder.iconName);
              const itemCount = countItems(folder.id);
              
              return (
                <div
                  key={folder.id}
                  className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100 relative"
                >
                  <button
                    onClick={() => onNavigate({ name: 'folder-detail', folderId: folder.id })}
                    className="w-full text-left"
                  >
                    <div 
                      className="w-14 h-14 rounded-xl flex items-center justify-center mb-3"
                      style={{ backgroundColor: `${folder.colorHex}20` }}
                    >
                      <Icon className="w-7 h-7" style={{ color: folder.colorHex }} />
                    </div>
                    <h4 className="font-bold text-gray-800 truncate">{folder.name}</h4>
                    <p className="text-sm text-gray-500">{itemCount} itens</p>
                  </button>
                  
                  {/* Menu */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setMenuOpen(menuOpen === folder.id ? null : folder.id);
                    }}
                    className="absolute top-3 right-3 w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100"
                  >
                    <MoreVertical className="w-4 h-4 text-gray-400" />
                  </button>
                  
                  {menuOpen === folder.id && (
                    <div className="absolute top-12 right-3 bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden z-10">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onNavigate({ name: 'folder-edit', folderId: folder.id });
                          setMenuOpen(null);
                        }}
                        className="w-full px-4 py-2 text-left text-sm hover:bg-gray-50 flex items-center gap-2"
                      >
                        <Edit className="w-4 h-4" />
                        Editar
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteFolder(folder.id);
                        }}
                        className="w-full px-4 py-2 text-left text-sm text-red-500 hover:bg-red-50 flex items-center gap-2"
                      >
                        <Trash2 className="w-4 h-4" />
                        Excluir
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
      
      {/* FAB */}
      <button
        onClick={() => onNavigate({ name: 'folder-edit' })}
        className="fixed bottom-6 right-6 bg-pink-500 text-white px-6 py-4 rounded-2xl shadow-lg flex items-center gap-2 font-semibold"
      >
        <Plus className="w-5 h-5" />
        Nova Pasta
      </button>
      
      {/* Modal Sugestões */}
      {showSuggestionsModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full max-h-[80vh] overflow-hidden">
            <div className="bg-pink-100 p-4 flex items-center justify-between">
              <h3 className="text-lg font-bold text-pink-800 font-['Poppins']">
                Pastas Sugeridas ✨
              </h3>
              <button
                onClick={() => setShowSuggestionsModal(false)}
                className="w-8 h-8 flex items-center justify-center"
              >
                <X className="w-5 h-5 text-pink-800" />
              </button>
            </div>
            
            <div className="p-4">
              <p className="text-gray-600 mb-4">
                Criamos algumas pastas populares para você começar. Deseja criá-las?
              </p>
              
              <div className="grid grid-cols-2 gap-2 mb-4 max-h-60 overflow-y-auto">
                {SUGGESTED_FOLDERS.map((folder, index) => {
                  const Icon = getIcon(folder.icon);
                  return (
                    <div
                      key={index}
                      className="bg-pink-50 rounded-xl p-3 flex items-center gap-2"
                    >
                      <div 
                        className="w-8 h-8 rounded-lg flex items-center justify-center"
                        style={{ backgroundColor: `${folder.color}20` }}
                      >
                        <Icon className="w-4 h-4" style={{ color: folder.color }} />
                      </div>
                      <span className="text-sm font-medium text-gray-700 truncate">
                        {folder.name}
                      </span>
                    </div>
                  );
                })}
              </div>
              
              <div className="flex gap-3">
                <button
                  onClick={() => setShowSuggestionsModal(false)}
                  className="flex-1 py-3 rounded-xl border border-gray-200 font-semibold text-gray-600"
                >
                  Agora não
                </button>
                <button
                  onClick={createSuggestedFolders}
                  className="flex-1 py-3 rounded-xl bg-pink-500 text-white font-semibold"
                >
                  Criar Todas
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Click outside to close menu */}
      {menuOpen && (
        <div 
          className="fixed inset-0 z-0" 
          onClick={() => setMenuOpen(null)}
        />
      )}
    </div>
  );
}
