import { useState, useEffect } from 'react';
import { useGoalStore } from '../store/useGoalStore';
import { useFemininityStore } from '../store/useFemininityStore';
import { useMoodStore } from '../store/useMoodStore';
import { useStore } from '../store/useStore';
import { useSecretDiaryStore } from '../store/useSecretDiaryStore';
import { OccurrenceStatus } from '../types';

interface WellbeingSummaryScreenProps {
  setScreen: (screen: any) => void;
}

// Helpers
const getWeekDays = (weekStart: Date): Date[] => {
  const days: Date[] = [];
  for (let i = 0; i < 7; i++) {
    const day = new Date(weekStart);
    day.setDate(weekStart.getDate() + i);
    days.push(day);
  }
  return days;
};

const getStartOfWeek = (date: Date): Date => {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  d.setDate(diff);
  d.setHours(0, 0, 0, 0);
  return d;
};

const formatDateKey = (date: Date): string => {
  return date.toISOString().split('T')[0];
};

const WEEKDAYS = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];

export default function WellbeingSummaryScreen({ setScreen }: WellbeingSummaryScreenProps) {
  const [weekStart, setWeekStart] = useState(() => getStartOfWeek(new Date()));
  const weekDays = getWeekDays(weekStart);
  const weekStartKey = formatDateKey(weekStart);
  const weekEndKey = formatDateKey(weekDays[6]);
  
  // Stores - dados
  const goals = useGoalStore(state => state.goals);
  const goalProgress = useGoalStore(state => state.progress);
  const femininityLogs = useFemininityStore(state => state.logs);
  const moodEntries = useMoodStore(state => state.entries);
  const occurrences = useStore(state => state.occurrences);
  const diaryEntries = useSecretDiaryStore(state => state.entries);
  
  // Inicializar stores apenas uma vez
  useEffect(() => {
    // Inicializar todos os stores (alguns são sync, outros async)
    useGoalStore.getState().initialize();
    useFemininityStore.getState().initialize();
    useMoodStore.getState().initialize();
    useStore.getState().initialize();
    useSecretDiaryStore.getState().loadEntries();
  }, []);

  const isCurrentWeek = weekStartKey === formatDateKey(getStartOfWeek(new Date()));

  // Calculate weekly data
  const weekData = weekDays.map(day => {
    const dateKey = formatDateKey(day);
    
    // Femininity
    const dayFemininity = femininityLogs.find(l => l.dateKey === dateKey);
    const femProgress = dayFemininity ? Object.values(dayFemininity.answers).filter(Boolean).length : 0;
    const femTotal = dayFemininity ? Object.keys(dayFemininity.answers).length : 20;
    
    // Mood
    const dayMood = moodEntries.find(e => e.dateKey === dateKey);
    
    // Diary
    const dayDiary = diaryEntries.find(e => e.dateKey === dateKey);
    
    return {
      date: day,
      dateKey,
      femininity: { done: femProgress, total: femTotal },
      mood: dayMood,
      hasDiary: !!dayDiary,
    };
  });

  // Tasks completed this week
  const tasksCompletedCount = (() => {
    let count = 0;
    
    // Iterate through the Map
    occurrences.forEach((occ, key) => {
      // Key format is "${taskId}-${date}"
      const parts = key.split('-');
      if (parts.length >= 4) {
        // Date is in format YYYY-MM-DD, so rejoin the last 3 parts
        const dateKey = `${parts[parts.length - 3]}-${parts[parts.length - 2]}-${parts[parts.length - 1]}`;
        if (dateKey >= weekStartKey && dateKey <= weekEndKey && occ.status === OccurrenceStatus.DONE) {
          count++;
        }
      }
    });
    
    return count;
  })();

  // Femininity average
  const femDays = weekData.filter(d => d.femininity.done > 0);
  const avgFemininity = femDays.length > 0 
    ? Math.round((femDays.reduce((sum, d) => sum + (d.femininity.done / d.femininity.total) * 100, 0)) / femDays.length)
    : 0;

  // Top mood
  const moodCounts: Record<string, number> = {};
  weekData.forEach(d => {
    if (d.mood) {
      moodCounts[d.mood.moodId] = (moodCounts[d.mood.moodId] || 0) + 1;
    }
  });
  const topMoodEntry = Object.entries(moodCounts).sort((a, b) => b[1] - a[1])[0];
  const topMoodData = topMoodEntry ? moodEntries.find(m => m.moodId === topMoodEntry[0]) : null;

  // Diary days
  const diaryDays = weekData.filter(d => d.hasDiary).length;

  // Goals calculations
  const activeGoals = goals.filter(g => g.isActive);
  
  const goalsWithProgress = activeGoals.map(goal => {
    // Get progress records that fall within this week
    const weekProgressRecords = goalProgress.filter(p => {
      // Check if progress period overlaps with selected week
      return p.goalId === goal.id && p.periodStart >= weekStartKey && p.periodStart <= weekEndKey;
    });
    
    const weekCount = weekProgressRecords.reduce((sum, p) => sum + p.count, 0);
    
    // Calculate week target based on renewal period
    let weekTarget = 0;
    if (goal.type === 'HABIT') {
      if (goal.renewalPeriod === 'DAILY') {
        weekTarget = goal.targetCount * 7;
      } else if (goal.renewalPeriod === 'WEEKLY') {
        weekTarget = goal.targetCount;
      } else if (goal.renewalPeriod === 'MONTHLY') {
        weekTarget = Math.ceil(goal.targetCount / 4);
      }
    }
    
    // For objectives, use totalProgress
    const totalProgress = goal.type === 'OBJECTIVE' ? (goal.totalProgress || 0) : 0;
    const totalTarget = goal.type === 'OBJECTIVE' ? (goal.totalTarget || 0) : 0;
    
    // Check if completed
    const isCompleted = goal.type === 'HABIT' 
      ? (weekTarget > 0 && weekCount >= weekTarget)
      : (totalTarget > 0 && totalProgress >= totalTarget);
    
    return {
      ...goal,
      weekCount,
      weekTarget,
      totalProgress,
      totalTarget,
      weekDelta: weekCount,
      isCompleted,
      percentWeek: weekTarget > 0 ? Math.min((weekCount / weekTarget) * 100, 100) : 0,
      percentTotal: totalTarget > 0 ? Math.min((totalProgress / totalTarget) * 100, 100) : 0,
    };
  });

  const completedGoals = goalsWithProgress.filter(g => g.isCompleted).length;
  const totalGoals = goalsWithProgress.length;
  const habitGoals = goalsWithProgress.filter(g => g.type === 'HABIT');
  const objectiveGoals = goalsWithProgress.filter(g => g.type === 'OBJECTIVE');

  const navigateWeek = (delta: number) => {
    const newStart = new Date(weekStart);
    newStart.setDate(newStart.getDate() + (delta * 7));
    setWeekStart(newStart);
  };

  const formatWeekRange = () => {
    const end = new Date(weekStart);
    end.setDate(end.getDate() + 6);
    const startStr = weekStart.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
    const endStr = end.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
    return `${startStr} a ${endStr}`;
  };

  // Max for femininity bars
  const maxFem = Math.max(...weekData.map(d => d.femininity.done), 1);

  return (
    <div className="min-h-screen pb-6" style={{ backgroundColor: '#FFF8FC' }}>
      {/* Header */}
      <div 
        className="px-4 pt-12 pb-6"
        style={{ background: 'linear-gradient(135deg, #E8DEF8 0%, #FFF0F7 100%)' }}
      >
        <div className="flex items-center gap-3 mb-4">
          <button
            onClick={() => setScreen({ name: 'home' })}
            className="w-10 h-10 rounded-full bg-white shadow flex items-center justify-center"
          >
            <svg className="w-5 h-5" fill="none" stroke="#7C3AED" strokeWidth={2} viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <div>
            <h1 className="text-2xl font-bold" style={{ color: '#2D1F2D', fontFamily: 'Poppins, sans-serif' }}>
              Resumo Bem-Estar
            </h1>
            <p style={{ color: '#7A5A73', fontSize: 14 }}>Desenvolvimento pessoal</p>
          </div>
        </div>
      </div>

      <div className="px-4 -mt-2 space-y-4">
        {/* Week Selector */}
        <div className="bg-white rounded-2xl p-4 shadow-sm" style={{ border: '1px solid #F3C9DF' }}>
          <div className="flex items-center justify-between">
            <button 
              onClick={() => navigateWeek(-1)}
              className="w-10 h-10 rounded-full flex items-center justify-center"
              style={{ backgroundColor: '#F3E8FF' }}
            >
              <svg className="w-5 h-5" fill="none" stroke="#7C3AED" strokeWidth={2} viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <div className="text-center">
              <p className="font-semibold" style={{ color: '#2D1F2D' }}>Semana de {formatWeekRange()}</p>
              {isCurrentWeek && (
                <span className="text-xs px-2 py-0.5 rounded-full" style={{ backgroundColor: '#F3E8FF', color: '#7C3AED' }}>
                  Esta semana
                </span>
              )}
            </div>
            <button 
              onClick={() => navigateWeek(1)}
              className="w-10 h-10 rounded-full flex items-center justify-center"
              style={{ backgroundColor: '#F3E8FF' }}
            >
              <svg className="w-5 h-5" fill="none" stroke="#7C3AED" strokeWidth={2} viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 gap-3">
          {/* Feminilidade */}
          <div className="bg-white rounded-2xl p-4 shadow-sm" style={{ border: '1px solid #F3C9DF' }}>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: '#FCE7F3' }}>
                <span>✨</span>
              </div>
              <span className="text-sm" style={{ color: '#7A5A73' }}>Feminilidade</span>
            </div>
            <p className="text-xl font-bold" style={{ color: '#EC4899' }}>{avgFemininity}% média</p>
          </div>

          {/* Humor */}
          <div className="bg-white rounded-2xl p-4 shadow-sm" style={{ border: '1px solid #F3C9DF' }}>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: '#FEF3C7' }}>
                <span>😊</span>
              </div>
              <span className="text-sm" style={{ color: '#7A5A73' }}>Humor</span>
            </div>
            <p className="text-xl font-bold" style={{ color: '#F59E0B' }}>
              {topMoodData ? `${topMoodData.emoji}` : '—'}
            </p>
          </div>

          {/* Tarefas */}
          <div className="bg-white rounded-2xl p-4 shadow-sm" style={{ border: '1px solid #F3C9DF' }}>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: '#D1FAE5' }}>
                <span>✅</span>
              </div>
              <span className="text-sm" style={{ color: '#7A5A73' }}>Tarefas</span>
            </div>
            <p className="text-xl font-bold" style={{ color: '#10B981' }}>{tasksCompletedCount} feitas</p>
          </div>

          {/* Diários */}
          <div className="bg-white rounded-2xl p-4 shadow-sm" style={{ border: '1px solid #F3C9DF' }}>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: '#E8DEF8' }}>
                <span>📔</span>
              </div>
              <span className="text-sm" style={{ color: '#7A5A73' }}>Diários</span>
            </div>
            <p className="text-xl font-bold" style={{ color: '#7C3AED' }}>{diaryDays} dias</p>
          </div>
        </div>

        {/* Goals Highlight Card */}
        <div 
          className="rounded-2xl p-4 shadow-sm"
          style={{ 
            background: 'linear-gradient(135deg, #F0609E 0%, #7C3AED 100%)',
          }}
        >
          <div className="flex items-center gap-2 mb-3">
            <span className="text-lg">🎯</span>
            <h3 className="font-semibold text-white">Metas da Semana</h3>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-white/20 rounded-xl p-3 text-center">
              <p className="text-2xl font-bold text-white">{completedGoals}/{totalGoals}</p>
              <p className="text-xs text-white/80">Concluídas</p>
            </div>
            <div className="bg-white/20 rounded-xl p-3 text-center">
              <p className="text-2xl font-bold text-white">{habitGoals.filter(g => g.isCompleted).length}</p>
              <p className="text-xs text-white/80">Hábitos ✓</p>
            </div>
            <div className="bg-white/20 rounded-xl p-3 text-center">
              <p className="text-2xl font-bold text-white">{objectiveGoals.filter(g => g.isCompleted).length}</p>
              <p className="text-xs text-white/80">Objetivos ✓</p>
            </div>
          </div>
        </div>

        {/* Goals List */}
        <div className="bg-white rounded-2xl p-4 shadow-sm" style={{ border: '1px solid #F3C9DF' }}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <span className="text-lg">🎯</span>
              <h3 className="font-semibold" style={{ color: '#2D1F2D' }}>Metas (Semana)</h3>
            </div>
            <span className="text-sm" style={{ color: '#7A5A73' }}>{totalGoals} ativas</span>
          </div>
          
          {goalsWithProgress.length === 0 ? (
            <p className="text-center py-4" style={{ color: '#7A5A73' }}>Nenhuma meta ativa</p>
          ) : (
            <div className="space-y-3">
              {goalsWithProgress.slice(0, 6).map(goal => (
                <div key={goal.id} className="p-3 rounded-xl" style={{ backgroundColor: '#FFF8FC' }}>
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span>{goal.icon}</span>
                      <div>
                        <p className="font-medium" style={{ color: '#2D1F2D' }}>{goal.title}</p>
                        <p className="text-xs" style={{ color: '#7A5A73' }}>
                          {goal.type === 'HABIT' ? 'Hábito' : 'Objetivo'}
                        </p>
                      </div>
                    </div>
                    {goal.isCompleted && (
                      <span className="text-xs px-2 py-0.5 rounded-full" style={{ backgroundColor: '#D1FAE5', color: '#10B981' }}>
                        ✓ Concluída
                      </span>
                    )}
                  </div>
                  
                  {goal.type === 'HABIT' ? (
                    <>
                      <div className="h-2 rounded-full overflow-hidden mb-1" style={{ backgroundColor: '#F3E8FF' }}>
                        <div 
                          className="h-full rounded-full transition-all"
                          style={{ 
                            width: `${goal.percentWeek}%`,
                            backgroundColor: goal.isCompleted ? '#10B981' : '#7C3AED'
                          }}
                        />
                      </div>
                      <p className="text-xs" style={{ color: '#7A5A73' }}>
                        {goal.weekCount}/{goal.weekTarget} esta semana
                      </p>
                    </>
                  ) : (
                    <>
                      <div className="h-2 rounded-full overflow-hidden mb-1" style={{ backgroundColor: '#FCE7F3' }}>
                        <div 
                          className="h-full rounded-full transition-all"
                          style={{ 
                            width: `${goal.percentTotal}%`,
                            backgroundColor: goal.isCompleted ? '#10B981' : '#EC4899'
                          }}
                        />
                      </div>
                      <p className="text-xs" style={{ color: '#7A5A73' }}>
                        Total: {goal.totalProgress}/{goal.totalTarget || '∞'} • +{goal.weekDelta} esta semana
                      </p>
                    </>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Feminilidade Chart */}
        <div className="bg-white rounded-2xl p-4 shadow-sm" style={{ border: '1px solid #F3C9DF' }}>
          <div className="flex items-center gap-2 mb-4">
            <span className="text-lg">✨</span>
            <h3 className="font-semibold" style={{ color: '#2D1F2D' }}>Feminilidade da Semana</h3>
          </div>
          <div className="flex justify-between items-end h-24 mb-2">
            {weekData.map((day, i) => (
              <div key={i} className="flex flex-col items-center flex-1">
                <div 
                  className="w-6 rounded-t-lg transition-all"
                  style={{ 
                    height: `${(day.femininity.done / maxFem) * 80}px`,
                    backgroundColor: day.femininity.done > 0 ? '#EC4899' : '#E8E8E8',
                    minHeight: 4
                  }}
                />
              </div>
            ))}
          </div>
          <div className="flex justify-between">
            {WEEKDAYS.map((d, i) => (
              <span key={i} className="text-xs text-center flex-1" style={{ color: '#7A5A73' }}>{d}</span>
            ))}
          </div>
          <div className="mt-3 pt-3 border-t flex justify-between text-sm" style={{ borderColor: '#F3C9DF' }}>
            <span style={{ color: '#7A5A73' }}>Dias ativos: {femDays.length}</span>
            <span style={{ color: '#7A5A73' }}>Média: {avgFemininity}%</span>
          </div>
        </div>

        {/* Humor */}
        <div className="bg-white rounded-2xl p-4 shadow-sm" style={{ border: '1px solid #F3C9DF' }}>
          <div className="flex items-center gap-2 mb-4">
            <span className="text-lg">😊</span>
            <h3 className="font-semibold" style={{ color: '#2D1F2D' }}>Humor da Semana</h3>
          </div>
          <div className="flex justify-between mb-2">
            {weekData.map((day, i) => (
              <div key={i} className="flex flex-col items-center flex-1">
                <span className="text-2xl">{day.mood?.emoji || '—'}</span>
              </div>
            ))}
          </div>
          <div className="flex justify-between">
            {WEEKDAYS.map((d, i) => (
              <span key={i} className="text-xs text-center flex-1" style={{ color: '#7A5A73' }}>{d}</span>
            ))}
          </div>
          {topMoodData && (
            <div className="mt-3 pt-3 border-t text-sm text-center" style={{ borderColor: '#F3C9DF', color: '#7A5A73' }}>
              Humor mais frequente: <span className="font-medium">{topMoodData.emoji} {topMoodData.label}</span>
            </div>
          )}
        </div>

        {/* Tarefas */}
        <div className="bg-white rounded-2xl p-4 shadow-sm" style={{ border: '1px solid #F3C9DF' }}>
          <div className="flex items-center gap-2 mb-4">
            <span className="text-lg">✅</span>
            <h3 className="font-semibold" style={{ color: '#2D1F2D' }}>Tarefas da Semana</h3>
          </div>
          <div className="text-center py-4">
            <p className="text-4xl font-bold" style={{ color: '#10B981' }}>{tasksCompletedCount}</p>
            <p className="text-sm" style={{ color: '#7A5A73' }}>tarefas concluídas</p>
          </div>
        </div>

        {/* Diário */}
        <div className="bg-white rounded-2xl p-4 shadow-sm" style={{ border: '1px solid #F3C9DF' }}>
          <div className="flex items-center gap-2 mb-4">
            <span className="text-lg">📔</span>
            <h3 className="font-semibold" style={{ color: '#2D1F2D' }}>Diário Secreto</h3>
          </div>
          <div className="flex justify-between mb-4">
            {weekData.map((day, i) => (
              <div key={i} className="flex flex-col items-center flex-1">
                <div 
                  className="w-8 h-8 rounded-full flex items-center justify-center"
                  style={{ 
                    backgroundColor: day.hasDiary ? '#E8DEF8' : '#F5F5F5',
                  }}
                >
                  <span className="text-sm">{day.hasDiary ? '📝' : '—'}</span>
                </div>
              </div>
            ))}
          </div>
          <div className="flex justify-between">
            {WEEKDAYS.map((d, i) => (
              <span key={i} className="text-xs text-center flex-1" style={{ color: '#7A5A73' }}>{d}</span>
            ))}
          </div>
          <div className="mt-3 pt-3 border-t text-sm text-center" style={{ borderColor: '#F3C9DF', color: '#7A5A73' }}>
            <span className="font-medium">{diaryDays} dias</span> com registro esta semana
          </div>
        </div>
      </div>
    </div>
  );
}
