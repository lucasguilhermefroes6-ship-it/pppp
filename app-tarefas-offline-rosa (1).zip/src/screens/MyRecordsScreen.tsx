import { useState, useEffect } from 'react';
import { Screen } from '../types/screens';
import { useMyRecordsStore, formatDateKey, startOfWeek, addDays, formatMinutesToHhMm } from '../store/useMyRecordsStore';

interface Props {
  setScreen: (screen: Screen) => void;
}

const COLORS = {
  primary: '#FF2D95',
  background: '#FFF3FA',
  card: '#FFFFFF',
  border: '#EFB2D3',
  textPrimary: '#241225',
  textSecondary: '#6B3D5F',
  success: '#2E7D32',
  error: '#C62828',
  neutral: '#9E9E9E',
};

export default function MyRecordsScreen({ setScreen }: Props) {
  const { goals, isLoading, initDB, getWeeklySummary, getRecord } = useMyRecordsStore();
  const [weekStart, setWeekStart] = useState(() => startOfWeek(new Date()));
  
  useEffect(() => {
    initDB();
  }, [initDB]);
  
  const summary = getWeeklySummary(weekStart);
  const today = formatDateKey(new Date());
  const todayRecord = getRecord(today);
  
  const weekEnd = addDays(weekStart, 6);
  const formatShortDate = (d: Date) => {
    return `${d.getDate().toString().padStart(2, '0')}/${(d.getMonth() + 1).toString().padStart(2, '0')}`;
  };
  
  const isCurrentWeek = formatDateKey(startOfWeek(new Date())) === formatDateKey(weekStart);
  
  const goToPrevWeek = () => setWeekStart(addDays(weekStart, -7));
  const goToNextWeek = () => setWeekStart(addDays(weekStart, 7));
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: COLORS.background }}>
        <div className="w-12 h-12 border-4 border-pink-200 border-t-pink-500 rounded-full animate-spin" />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen pb-24" style={{ background: COLORS.background }}>
      {/* Header */}
      <div 
        className="pt-12 pb-6 px-5"
        style={{ background: `linear-gradient(135deg, ${COLORS.primary}20, ${COLORS.background})` }}
      >
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() => setScreen({ name: 'home' })}
            className="w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center"
          >
            <svg className="w-5 h-5" fill="none" stroke={COLORS.primary} viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          
          <button
            onClick={() => setScreen({ name: 'my-records-goals' })}
            className="w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center"
          >
            <svg className="w-5 h-5" fill="none" stroke={COLORS.primary} viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </button>
        </div>
        
        <h1 className="text-2xl font-bold" style={{ color: COLORS.textPrimary }}>
          Meus Registros
        </h1>
        <p style={{ color: COLORS.textSecondary }}>Calorias & Jejum</p>
      </div>
      
      <div className="px-5 -mt-2 space-y-4">
        {/* Week Selector */}
        <div 
          className="rounded-2xl p-4 flex items-center justify-between"
          style={{ 
            background: COLORS.card, 
            border: `1.5px solid ${COLORS.border}`,
            boxShadow: '0 2px 8px rgba(0,0,0,0.06)'
          }}
        >
          <button 
            onClick={goToPrevWeek}
            className="w-10 h-10 rounded-full flex items-center justify-center"
            style={{ background: `${COLORS.primary}15` }}
          >
            <svg className="w-5 h-5" fill="none" stroke={COLORS.primary} viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          
          <div className="text-center">
            <p className="font-semibold" style={{ color: COLORS.textPrimary }}>
              Semana de {formatShortDate(weekStart)} a {formatShortDate(weekEnd)}
            </p>
            {isCurrentWeek && (
              <span 
                className="text-xs px-2 py-0.5 rounded-full"
                style={{ background: `${COLORS.primary}20`, color: COLORS.primary }}
              >
                Esta semana
              </span>
            )}
          </div>
          
          <button 
            onClick={goToNextWeek}
            className="w-10 h-10 rounded-full flex items-center justify-center"
            style={{ background: `${COLORS.primary}15` }}
          >
            <svg className="w-5 h-5" fill="none" stroke={COLORS.primary} viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>
        
        {/* Summary Cards */}
        <div className="grid grid-cols-2 gap-3">
          {/* Calories Card */}
          <div 
            className="rounded-2xl p-4"
            style={{ 
              background: COLORS.card, 
              border: `1.5px solid ${COLORS.border}`,
              boxShadow: '0 2px 8px rgba(0,0,0,0.06)'
            }}
          >
            <div className="flex items-center gap-2 mb-2">
              <div 
                className="w-8 h-8 rounded-lg flex items-center justify-center"
                style={{ background: '#FFF4E5' }}
              >
                <span className="text-lg">🔥</span>
              </div>
              <span className="font-semibold text-sm" style={{ color: COLORS.textPrimary }}>Calorias</span>
            </div>
            
            <p className="text-xl font-bold" style={{ color: COLORS.primary }}>
              {summary.avgCalories !== null ? `${summary.avgCalories}` : '—'}
              <span className="text-sm font-normal" style={{ color: COLORS.textSecondary }}> kcal/dia</span>
            </p>
            
            {goals?.calorieMinKcal !== undefined && goals?.calorieMaxKcal !== undefined && (
              <p className="text-xs mt-1" style={{ color: COLORS.textSecondary }}>
                Meta: {goals.calorieMinKcal}–{goals.calorieMaxKcal} kcal
              </p>
            )}
            
            <div className="flex items-center gap-1 mt-2">
              <span className="text-sm font-semibold" style={{ color: COLORS.success }}>
                {summary.daysCaloriesHitGoal}
              </span>
              <span className="text-xs" style={{ color: COLORS.textSecondary }}>
                /{summary.daysCaloriesWithData} dias na meta
              </span>
            </div>
          </div>
          
          {/* Fasting Card */}
          <div 
            className="rounded-2xl p-4"
            style={{ 
              background: COLORS.card, 
              border: `1.5px solid ${COLORS.border}`,
              boxShadow: '0 2px 8px rgba(0,0,0,0.06)'
            }}
          >
            <div className="flex items-center gap-2 mb-2">
              <div 
                className="w-8 h-8 rounded-lg flex items-center justify-center"
                style={{ background: '#E8F5E9' }}
              >
                <span className="text-lg">⏱️</span>
              </div>
              <span className="font-semibold text-sm" style={{ color: COLORS.textPrimary }}>Jejum</span>
            </div>
            
            <p className="text-xl font-bold" style={{ color: COLORS.primary }}>
              {formatMinutesToHhMm(summary.avgFastingMinutes)}
              <span className="text-sm font-normal" style={{ color: COLORS.textSecondary }}> média</span>
            </p>
            
            {goals?.fastingTargetMinutes !== undefined && (
              <p className="text-xs mt-1" style={{ color: COLORS.textSecondary }}>
                Meta: {formatMinutesToHhMm(goals.fastingTargetMinutes)}
              </p>
            )}
            
            <div className="flex items-center gap-1 mt-2">
              <span className="text-sm font-semibold" style={{ color: COLORS.success }}>
                {summary.daysFastingHitGoal}
              </span>
              <span className="text-xs" style={{ color: COLORS.textSecondary }}>
                /{summary.daysFastingWithData} dias na meta
              </span>
            </div>
          </div>
        </div>
        
        {/* Today Card */}
        <div 
          className="rounded-2xl p-5"
          style={{ 
            background: `linear-gradient(135deg, ${COLORS.primary}, #FF6B9D)`,
            boxShadow: '0 4px 15px rgba(255, 45, 149, 0.3)'
          }}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white/80 text-sm">Hoje</p>
              <p className="text-white text-lg font-semibold">
                {new Date().toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' })}
              </p>
            </div>
            <button
              onClick={() => setScreen({ name: 'my-records-edit', dateKey: today })}
              className="px-4 py-2 bg-white rounded-xl font-semibold text-sm shadow-md"
              style={{ color: COLORS.primary }}
            >
              Editar hoje
            </button>
          </div>
          
          <div className="grid grid-cols-2 gap-4 mt-4">
            <div className="bg-white/20 rounded-xl p-3">
              <p className="text-white/70 text-xs">Calorias</p>
              <p className="text-white text-xl font-bold">
                {todayRecord?.caloriesKcal !== undefined ? `${todayRecord.caloriesKcal} kcal` : '—'}
              </p>
            </div>
            <div className="bg-white/20 rounded-xl p-3">
              <p className="text-white/70 text-xs">Jejum</p>
              <p className="text-white text-xl font-bold">
                {formatMinutesToHhMm(todayRecord?.fastingDurationMinutes)}
              </p>
            </div>
          </div>
        </div>
        
        {/* Weekly List */}
        <div 
          className="rounded-2xl p-4"
          style={{ 
            background: COLORS.card, 
            border: `1.5px solid ${COLORS.border}`,
            boxShadow: '0 2px 8px rgba(0,0,0,0.06)'
          }}
        >
          <h3 className="font-bold mb-3" style={{ color: COLORS.textPrimary }}>
            Dias da Semana
          </h3>
          
          <div className="space-y-2">
            {summary.dailyRecords.map((day) => {
              const isToday = day.date === today;
              const dateObj = new Date(day.date + 'T12:00:00');
              
              return (
                <button
                  key={day.date}
                  onClick={() => setScreen({ name: 'my-records-edit', dateKey: day.date })}
                  className="w-full p-3 rounded-xl flex items-center justify-between transition-all hover:scale-[1.01]"
                  style={{ 
                    background: isToday ? `${COLORS.primary}10` : '#FAFAFA',
                    border: isToday ? `1.5px solid ${COLORS.primary}40` : '1px solid transparent'
                  }}
                >
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-10 h-10 rounded-lg flex flex-col items-center justify-center text-xs font-bold"
                      style={{ 
                        background: isToday ? COLORS.primary : '#E0E0E0',
                        color: isToday ? 'white' : COLORS.textSecondary
                      }}
                    >
                      <span>{day.dayName}</span>
                      <span className="text-[10px]">{dateObj.getDate()}</span>
                    </div>
                    
                    <div className="text-left">
                      <p className="font-medium text-sm" style={{ color: COLORS.textPrimary }}>
                        {day.record?.caloriesKcal !== undefined 
                          ? `${day.record.caloriesKcal} kcal`
                          : '—'
                        }
                      </p>
                      <p className="text-xs" style={{ color: COLORS.textSecondary }}>
                        Jejum: {formatMinutesToHhMm(day.record?.fastingDurationMinutes)}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {/* Calories indicator */}
                    <div 
                      className="w-6 h-6 rounded-full flex items-center justify-center text-xs"
                      style={{ 
                        background: day.caloriesHitGoal === true ? '#E8F5E9' : 
                                   day.caloriesHitGoal === false ? '#FFEBEE' : '#F5F5F5'
                      }}
                    >
                      {day.caloriesHitGoal === true && <span style={{ color: COLORS.success }}>✓</span>}
                      {day.caloriesHitGoal === false && <span style={{ color: COLORS.error }}>✗</span>}
                      {day.caloriesHitGoal === null && <span style={{ color: COLORS.neutral }}>—</span>}
                    </div>
                    
                    {/* Fasting indicator */}
                    <div 
                      className="w-6 h-6 rounded-full flex items-center justify-center text-xs"
                      style={{ 
                        background: day.fastingHitGoal === true ? '#E8F5E9' : 
                                   day.fastingHitGoal === false ? '#FFEBEE' : '#F5F5F5'
                      }}
                    >
                      {day.fastingHitGoal === true && <span style={{ color: COLORS.success }}>✓</span>}
                      {day.fastingHitGoal === false && <span style={{ color: COLORS.error }}>✗</span>}
                      {day.fastingHitGoal === null && <span style={{ color: COLORS.neutral }}>—</span>}
                    </div>
                    
                    <svg className="w-4 h-4" fill="none" stroke={COLORS.textSecondary} viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                </button>
              );
            })}
          </div>
          
          {/* Legend */}
          <div className="mt-4 pt-3 border-t flex items-center justify-center gap-6 text-xs" style={{ borderColor: COLORS.border }}>
            <div className="flex items-center gap-1">
              <span className="w-4 h-4 rounded-full flex items-center justify-center" style={{ background: '#E8F5E9', color: COLORS.success }}>✓</span>
              <span style={{ color: COLORS.textSecondary }}>Na meta</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-4 h-4 rounded-full flex items-center justify-center" style={{ background: '#FFEBEE', color: COLORS.error }}>✗</span>
              <span style={{ color: COLORS.textSecondary }}>Fora da meta</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-4 h-4 rounded-full flex items-center justify-center" style={{ background: '#F5F5F5', color: COLORS.neutral }}>—</span>
              <span style={{ color: COLORS.textSecondary }}>Sem dados</span>
            </div>
          </div>
        </div>
        
        {/* Tips */}
        <div 
          className="rounded-2xl p-4"
          style={{ 
            background: '#FFF9E6', 
            border: `1.5px solid #F5D46A`,
          }}
        >
          <div className="flex items-start gap-3">
            <span className="text-2xl">💡</span>
            <div>
              <p className="font-semibold text-sm" style={{ color: '#8B6914' }}>
                Dica sobre Jejum Intermitente
              </p>
              <p className="text-xs mt-1" style={{ color: '#A67C00' }}>
                Registre a hora que parou de comer à noite e a hora que começou a comer no dia seguinte.
                O app calcula automaticamente a duração do seu jejum!
              </p>
            </div>
          </div>
        </div>
      </div>
      
      {/* FAB */}
      <button
        onClick={() => setScreen({ name: 'my-records-edit' })}
        className="fixed bottom-6 right-6 px-6 py-4 rounded-2xl flex items-center gap-2 shadow-lg"
        style={{ 
          background: `linear-gradient(135deg, ${COLORS.primary}, #FF6B9D)`,
          boxShadow: '0 4px 20px rgba(255, 45, 149, 0.4)'
        }}
      >
        <svg className="w-5 h-5" fill="none" stroke="white" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
        </svg>
        <span className="text-white font-semibold">Novo Registro</span>
      </button>
    </div>
  );
}
