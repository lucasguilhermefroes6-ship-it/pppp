import { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Sparkles,
  X,
  Check,
  Volume2,
  Heart,
  Clock,
  CheckCircle,
  Brain,
  Footprints,
  Ear,
  Hand,
  Smile,
  Users,
  Home,
  Star,
  Feather,
  Lock,
  Leaf,
  Droplet,
  Sun,
  HeartHandshake,
  Flame,
  Calendar,
  Award,
} from 'lucide-react';
import { Screen } from '@/types/screens';
import { useFemininityStore, FEMININITY_QUESTIONS } from '@/store/useFemininityStore';

interface FemininityScreenProps {
  onNavigate: (screen: Screen) => void;
}

// Map icon names to components
const iconMap: Record<string, React.ComponentType<any>> = {
  'volume': Volume2,
  'heart': Heart,
  'clock': Clock,
  'check': CheckCircle,
  'brain': Brain,
  'footprints': Footprints,
  'ear': Ear,
  'sparkles': Sparkles,
  'hand': Hand,
  'smile': Smile,
  'users': Users,
  'home': Home,
  'mirror': Sparkles,
  'star': Star,
  'feather': Feather,
  'lock': Lock,
  'leaf': Leaf,
  'droplet': Droplet,
  'sun': Sun,
  'heart-handshake': HeartHandshake,
};

export default function FemininityScreen({ onNavigate }: FemininityScreenProps) {
  const [showModal, setShowModal] = useState(false);
  const {
    initialize,
    createOrGetTodayLog,
    toggleAnswer,
    getTodayProgress,
    getLast7Days,
    getStreak,
    getTodayLog,
  } = useFemininityStore();

  useEffect(() => {
    initialize();
  }, [initialize]);

  const { completed, total } = getTodayProgress();
  const last7Days = getLast7Days();
  const streak = getStreak();
  const todayLog = getTodayLog();
  const progressPercent = (completed / total) * 100;

  const getMotivationalMessage = () => {
    if (completed === 0) return '🌸 Vamos começar o dia com carinho!';
    if (completed < total * 0.25) return '🌷 Você está começando bem!';
    if (completed < total * 0.5) return '💮 Continue assim, querida!';
    if (completed < total * 0.75) return '🌺 Você está indo muito bem!';
    if (completed < total) return '🌹 Quase lá, você consegue!';
    return '🎀 Parabéns! Dia completo! ✨';
  };

  const formatDate = (dateKey: string) => {
    const date = new Date(dateKey + 'T12:00:00');
    return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
  };

  const handleOpenModal = () => {
    createOrGetTodayLog();
    setShowModal(true);
  };

  return (
    <div className="min-h-screen bg-[#FFF5F8]">
      {/* Header */}
      <div className="bg-gradient-to-r from-pink-300 via-pink-200 to-purple-200 pt-12 pb-6 px-4">
        <div className="max-w-lg mx-auto">
          <div className="flex items-center gap-3 mb-4">
            <button
              onClick={() => onNavigate({ name: 'home' })}
              className="w-10 h-10 bg-white/30 backdrop-blur-sm rounded-full flex items-center justify-center text-pink-700 hover:bg-white/50 transition-all"
            >
              <ArrowLeft size={20} />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-pink-800 font-[Poppins]">
                Feminilidade
              </h1>
              <p className="text-pink-600 text-sm">Seu diário de autocuidado 💅</p>
            </div>
          </div>

          {/* Progress Overview Card */}
          <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-5 shadow-lg border border-pink-100">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-pink-400 to-purple-400 flex items-center justify-center shadow-lg">
                  <Sparkles size={28} className="text-white" />
                </div>
                <div>
                  <p className="text-pink-700 font-semibold">Progresso de hoje</p>
                  <p className="text-gray-500 text-sm">{getMotivationalMessage()}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-3xl font-extrabold text-pink-500">{completed}/{total}</p>
              </div>
            </div>
            
            {/* Progress Bar */}
            <div className="h-3 bg-pink-100 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-pink-400 to-pink-500 rounded-full transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>

            {/* Streak */}
            {streak > 0 && (
              <div className="mt-3 flex items-center gap-2 text-orange-500">
                <Flame size={18} />
                <span className="font-semibold">{streak} dias seguidos!</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Content */}
      <main className="px-4 py-6 max-w-lg mx-auto space-y-6">
        {/* Open Button */}
        <button
          onClick={handleOpenModal}
          className="w-full py-4 bg-gradient-to-r from-pink-500 to-pink-600 text-white rounded-2xl font-bold text-lg shadow-lg hover:from-pink-600 hover:to-pink-700 transition-all flex items-center justify-center gap-3"
        >
          <Sparkles size={24} />
          Abrir Registro de Feminilidade
        </button>

        {/* Stats Cards */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-white rounded-2xl p-4 shadow-md border border-pink-100 text-center">
            <div className="w-10 h-10 bg-pink-100 rounded-xl flex items-center justify-center mx-auto mb-2">
              <Award size={20} className="text-pink-500" />
            </div>
            <p className="text-2xl font-bold text-pink-500">{completed}</p>
            <p className="text-gray-500 text-xs">Hoje</p>
          </div>
          <div className="bg-white rounded-2xl p-4 shadow-md border border-pink-100 text-center">
            <div className="w-10 h-10 bg-orange-100 rounded-xl flex items-center justify-center mx-auto mb-2">
              <Flame size={20} className="text-orange-500" />
            </div>
            <p className="text-2xl font-bold text-orange-500">{streak}</p>
            <p className="text-gray-500 text-xs">Sequência</p>
          </div>
          <div className="bg-white rounded-2xl p-4 shadow-md border border-pink-100 text-center">
            <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-2">
              <Calendar size={20} className="text-purple-500" />
            </div>
            <p className="text-2xl font-bold text-purple-500">{last7Days.filter(d => d.completed > 0).length}</p>
            <p className="text-gray-500 text-xs">Esta semana</p>
          </div>
        </div>

        {/* Last 7 Days */}
        <div className="bg-white rounded-3xl p-5 shadow-md border border-pink-100">
          <h3 className="font-bold text-pink-700 mb-4 flex items-center gap-2">
            <Calendar size={18} />
            Últimos 7 dias
          </h3>
          <div className="space-y-3">
            {last7Days.map((day, index) => {
              const percent = (day.completed / day.total) * 100;
              const isToday = index === 0;
              return (
                <div key={day.date} className="flex items-center gap-3">
                  <span className={`text-sm w-12 ${isToday ? 'font-bold text-pink-600' : 'text-gray-500'}`}>
                    {isToday ? 'Hoje' : formatDate(day.date)}
                  </span>
                  <div className="flex-1 h-2.5 bg-pink-50 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all ${
                        percent === 100 
                          ? 'bg-gradient-to-r from-green-400 to-green-500' 
                          : percent >= 50 
                          ? 'bg-gradient-to-r from-pink-400 to-pink-500'
                          : 'bg-gradient-to-r from-pink-200 to-pink-300'
                      }`}
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                  <span className={`text-sm w-10 text-right ${
                    percent === 100 ? 'text-green-500 font-bold' : 'text-gray-500'
                  }`}>
                    {day.completed}/{day.total}
                  </span>
                </div>
              );
            })}
          </div>
          {last7Days.every(d => d.completed === 0) && (
            <p className="text-gray-400 text-center py-4">Sem registros ainda</p>
          )}
        </div>

        {/* Tips Card */}
        <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-3xl p-5 border border-purple-100">
          <h3 className="font-bold text-purple-700 mb-3 flex items-center gap-2">
            <Sparkles size={18} />
            Dicas para desenvolver feminilidade
          </h3>
          <ul className="space-y-2 text-sm text-purple-600">
            <li className="flex items-start gap-2">
              <span className="text-purple-400">•</span>
              Fale sempre de forma calma e suave
            </li>
            <li className="flex items-start gap-2">
              <span className="text-purple-400">•</span>
              Cuide da sua aparência com carinho
            </li>
            <li className="flex items-start gap-2">
              <span className="text-purple-400">•</span>
              Pratique a paciência diariamente
            </li>
            <li className="flex items-start gap-2">
              <span className="text-purple-400">•</span>
              Seja gentil consigo mesma e com os outros
            </li>
          </ul>
        </div>
      </main>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-end justify-center">
          <div 
            className="bg-[#FFF5F8] w-full max-w-lg rounded-t-3xl max-h-[90vh] flex flex-col animate-slide-up"
            style={{ animation: 'slideUp 0.3s ease-out' }}
          >
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-pink-200 to-purple-200 px-5 py-4 rounded-t-3xl flex items-center justify-between flex-shrink-0">
              <h2 className="text-xl font-bold text-pink-800 font-[Poppins]">
                Registro de Feminilidade 💅✨
              </h2>
              <button
                onClick={() => setShowModal(false)}
                className="w-9 h-9 bg-white/50 rounded-full flex items-center justify-center text-pink-700 hover:bg-white/80 transition-all"
              >
                <X size={20} />
              </button>
            </div>

            {/* Progress Card */}
            <div className="px-5 py-4 flex-shrink-0">
              <div className="bg-white rounded-2xl p-4 shadow-md border border-pink-100">
                <div className="flex items-center justify-between mb-3">
                  <span className="font-semibold text-pink-700">Seu progresso hoje</span>
                  <span className="text-3xl font-extrabold text-pink-500">{completed}/{total}</span>
                </div>
                <div className="h-3 bg-pink-100 rounded-full overflow-hidden mb-2">
                  <div 
                    className="h-full bg-gradient-to-r from-pink-400 to-pink-500 rounded-full transition-all duration-300"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
                <p className="text-sm text-pink-600">{getMotivationalMessage()}</p>
              </div>
            </div>

            {/* Questions List */}
            <div className="flex-1 overflow-y-auto px-5 pb-6 space-y-3">
              {FEMININITY_QUESTIONS.map((question) => {
                const IconComponent = iconMap[question.icon] || Sparkles;
                const isChecked = todayLog?.answers[question.id] || false;
                
                return (
                  <button
                    key={question.id}
                    onClick={() => toggleAnswer(question.id)}
                    className={`w-full bg-white rounded-2xl p-4 border-2 transition-all flex items-center gap-3 text-left ${
                      isChecked 
                        ? 'border-pink-400 shadow-md' 
                        : 'border-pink-100 hover:border-pink-200'
                    }`}
                  >
                    {/* Checkbox */}
                    <div className={`w-7 h-7 rounded-full flex-shrink-0 flex items-center justify-center border-2 transition-all ${
                      isChecked 
                        ? 'bg-pink-500 border-pink-500' 
                        : 'border-gray-300 bg-white'
                    }`}>
                      {isChecked && <Check size={16} className="text-white" />}
                    </div>
                    
                    {/* Icon */}
                    <div 
                      className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: `${question.color}20` }}
                    >
                      <IconComponent size={16} style={{ color: question.color }} />
                    </div>
                    
                    {/* Text */}
                    <span className={`text-base font-medium flex-1 ${
                      isChecked ? 'text-pink-700' : 'text-gray-700'
                    }`}>
                      {question.text}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Animation styles */}
      <style>{`
        @keyframes slideUp {
          from {
            transform: translateY(100%);
          }
          to {
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}
