import { ArrowLeft, Construction, LucideIcon } from 'lucide-react';
import { Screen } from '@/types/screens';

interface PlaceholderScreenProps {
  title: string;
  icon: LucideIcon;
  onNavigate: (screen: Screen) => void;
  description?: string;
}

export function PlaceholderScreen({ title, icon: Icon, onNavigate, description }: PlaceholderScreenProps) {
  return (
    <div className="min-h-screen bg-[#FFF5F8]">
      {/* Header */}
      <header className="bg-gradient-to-br from-pink-400 to-pink-500 text-white px-4 pt-10 pb-6 shadow-[0_4px_16px_rgba(236,72,153,0.3)]">
        <div className="max-w-lg mx-auto">
          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate({ name: 'home' })}
              className="p-2 -ml-2 rounded-lg hover:bg-white/10 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-xl font-bold font-poppins">{title}</h1>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="px-4 py-12 max-w-lg mx-auto">
        <div className="text-center">
          {/* Icon */}
          <div className="w-24 h-24 bg-gradient-to-br from-pink-100 to-pink-200 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-[0_8px_24px_rgba(236,72,153,0.2)]">
            <Icon className="w-12 h-12 text-pink-500" />
          </div>

          {/* Construction Icon */}
          <div className="flex items-center justify-center gap-2 text-pink-400 mb-4">
            <Construction className="w-5 h-5" />
            <span className="text-sm font-semibold font-poppins">Em construção</span>
          </div>

          {/* Title */}
          <h2 className="text-xl font-bold font-poppins text-pink-600 mb-2">{title}</h2>
          
          {/* Description */}
          <p className="text-pink-400 max-w-xs mx-auto">
            {description || 'Esta funcionalidade está sendo desenvolvida com muito carinho para você! 💕'}
          </p>

          {/* Back Button */}
          <button
            onClick={() => onNavigate({ name: 'home' })}
            className="mt-8 px-6 py-3 bg-gradient-to-r from-pink-400 to-pink-500 text-white rounded-xl font-bold font-poppins hover:from-pink-500 hover:to-pink-600 transition-all shadow-[0_6px_16px_rgba(236,72,153,0.35)]"
          >
            Voltar para Home
          </button>
        </div>
      </main>
    </div>
  );
}
