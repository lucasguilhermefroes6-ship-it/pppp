import { useEffect, useState } from 'react';
import { 
  ArrowLeft, Heart, Calendar, Sparkles, 
  TrendingUp, Smile, X, Check, ChevronRight,
  Sun, Moon, Cloud
} from 'lucide-react';
import { Screen } from '@/types/screens';
import { useMoodStore, MOOD_OPTIONS, MoodOption } from '@/store/useMoodStore';

interface MoodScreenProps {
  onNavigate: (screen: Screen) => void;
}

export default function MoodScreen({ onNavigate }: MoodScreenProps) {
  const {
    entries,
    isLoading,
    isModalOpen,
    editingDate,
    initialize,
    saveMood,
    getTodayMood,
    getMoodByDate,
    getEntriesForLastDays,
    getMoodStats,
    openModal,
    closeModal,
  } = useMoodStore();

  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [notes, setNotes] = useState('');
  const [showNotes, setShowNotes] = useState(false);

  useEffect(() => {
    initialize();
  }, [initialize]);

  useEffect(() => {
    if (isModalOpen && editingDate) {
      const existing = getMoodByDate(editingDate);
      if (existing) {
        setSelectedMood(existing.moodId);
        setNotes(existing.notes || '');
      } else {
        setSelectedMood(null);
        setNotes('');
      }
    }
  }, [isModalOpen, editingDate, getMoodByDate]);

  const todayMood = getTodayMood();
  const last14Days = getEntriesForLastDays(14);
  const stats = getMoodStats();

  const handleSelectMood = (moodId: string) => {
    setSelectedMood(moodId);
    // Salvar automaticamente ao selecionar
    saveMood(moodId, editingDate || undefined, notes);
  };

  const handleSaveWithNotes = () => {
    if (selectedMood) {
      saveMood(selectedMood, editingDate || undefined, notes);
    }
  };

  const formatFullDate = (dateKey: string) => {
    const date = new Date(dateKey + 'T12:00:00');
    return date.toLocaleDateString('pt-BR', { 
      weekday: 'long',
      day: 'numeric', 
      month: 'long' 
    });
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return { text: 'Bom dia', icon: Sun, color: '#FFB800' };
    if (hour < 18) return { text: 'Boa tarde', icon: Sun, color: '#FF9100' };
    return { text: 'Boa noite', icon: Moon, color: '#7C4DFF' };
  };

  const greeting = getGreeting();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#FFF5F8] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-pink-200 border-t-pink-500 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FFF5F8]">
      {/* Header */}
      <div className="bg-gradient-to-br from-pink-400 via-pink-500 to-rose-500 pt-12 pb-8 px-5 rounded-b-[32px] shadow-lg">
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => onNavigate({ name: 'home' })}
            className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <div className="flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full">
            <Heart className="w-4 h-4 text-white" />
            <span className="text-white font-semibold text-sm">Humor</span>
          </div>
        </div>

        {/* Greeting */}
        <div className="text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <greeting.icon className="w-5 h-5 text-yellow-200" />
            <span className="text-white/90 font-medium">{greeting.text}!</span>
          </div>
          <h1 className="text-2xl font-bold text-white font-['Poppins'] mb-1">
            Como você está se sentindo?
          </h1>
          <p className="text-white/80 text-sm">
            {new Date().toLocaleDateString('pt-BR', { 
              weekday: 'long', 
              day: 'numeric', 
              month: 'long' 
            })}
          </p>
        </div>

        {/* Today's Mood Display */}
        {todayMood && (
          <div className="mt-6 bg-white/20 backdrop-blur-sm rounded-2xl p-4 flex items-center gap-4">
            <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-lg">
              <span className="text-4xl">{todayMood.emoji}</span>
            </div>
            <div className="flex-1">
              <p className="text-white/80 text-sm">Você está se sentindo</p>
              <p className="text-white font-bold text-xl font-['Poppins']">{todayMood.label}</p>
            </div>
            <button
              onClick={() => openModal()}
              className="w-10 h-10 bg-white/30 rounded-xl flex items-center justify-center"
            >
              <ChevronRight className="w-5 h-5 text-white" />
            </button>
          </div>
        )}
      </div>

      <div className="px-5 py-6 space-y-6">
        {/* Button to Register */}
        {!todayMood && (
          <button
            onClick={() => openModal()}
            className="w-full bg-gradient-to-r from-pink-500 to-rose-500 text-white py-4 rounded-2xl font-semibold text-lg shadow-lg shadow-pink-500/30 flex items-center justify-center gap-3 hover:shadow-xl transition-all"
          >
            <Sparkles className="w-5 h-5" />
            Registrar meu humor
          </button>
        )}

        {/* Stats Cards */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
            <div className="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center mb-2">
              <span className="text-xl">😊</span>
            </div>
            <p className="text-2xl font-bold text-green-600 font-['Poppins']">{stats.positive}</p>
            <p className="text-xs text-gray-500">Positivos</p>
          </div>
          
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
            <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center mb-2">
              <span className="text-xl">😌</span>
            </div>
            <p className="text-2xl font-bold text-blue-600 font-['Poppins']">{stats.neutral}</p>
            <p className="text-xs text-gray-500">Neutros</p>
          </div>
          
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
            <div className="w-10 h-10 bg-orange-100 rounded-xl flex items-center justify-center mb-2">
              <span className="text-xl">😔</span>
            </div>
            <p className="text-2xl font-bold text-orange-600 font-['Poppins']">{stats.negative}</p>
            <p className="text-xs text-gray-500">Difíceis</p>
          </div>
        </div>

        {/* Most Frequent */}
        {stats.mostFrequent && (
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-pink-100">
            <div className="flex items-center gap-3 mb-3">
              <TrendingUp className="w-5 h-5 text-pink-500" />
              <h3 className="font-bold text-gray-800 font-['Poppins']">Humor mais frequente</h3>
            </div>
            <div className="flex items-center gap-4">
              <div 
                className="w-16 h-16 rounded-2xl flex items-center justify-center"
                style={{ backgroundColor: stats.mostFrequent.bgColor }}
              >
                <span className="text-4xl">{stats.mostFrequent.emoji}</span>
              </div>
              <div>
                <p className="font-bold text-lg text-gray-800">{stats.mostFrequent.label}</p>
                <p className="text-sm text-gray-500">Este mês você se sentiu assim mais vezes</p>
              </div>
            </div>
          </div>
        )}

        {/* Week Overview */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-pink-100">
          <div className="flex items-center gap-3 mb-4">
            <Calendar className="w-5 h-5 text-pink-500" />
            <h3 className="font-bold text-gray-800 font-['Poppins']">Últimos 7 dias</h3>
          </div>
          
          <div className="flex justify-between">
            {Array.from({ length: 7 }).map((_, i) => {
              const date = new Date();
              date.setDate(date.getDate() - (6 - i));
              const dateKey = date.toISOString().split('T')[0];
              const entry = entries.find(e => e.dateKey === dateKey);
              const isToday = i === 6;
              
              return (
                <div key={i} className="flex flex-col items-center gap-2">
                  <span className="text-xs text-gray-400">
                    {date.toLocaleDateString('pt-BR', { weekday: 'short' }).slice(0, 3)}
                  </span>
                  <button
                    onClick={() => openModal(dateKey)}
                    className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all ${
                      isToday ? 'ring-2 ring-pink-500 ring-offset-2' : ''
                    }`}
                    style={{ 
                      backgroundColor: entry 
                        ? MOOD_OPTIONS.find(m => m.id === entry.moodId)?.bgColor || '#FCE4EC'
                        : '#F5F5F5'
                    }}
                  >
                    {entry ? (
                      <span className="text-2xl">{entry.emoji}</span>
                    ) : (
                      <Cloud className="w-5 h-5 text-gray-300" />
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* History */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-pink-100">
          <div className="flex items-center gap-3 mb-4">
            <Smile className="w-5 h-5 text-pink-500" />
            <h3 className="font-bold text-gray-800 font-['Poppins']">Histórico completo</h3>
          </div>
          
          {last14Days.length === 0 ? (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-pink-50 rounded-full flex items-center justify-center mx-auto mb-3">
                <Heart className="w-8 h-8 text-pink-300" />
              </div>
              <p className="text-gray-400">Nenhum registro ainda</p>
              <p className="text-sm text-gray-300">Comece registrando como você se sente!</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {last14Days.map(entry => {
                const mood = MOOD_OPTIONS.find(m => m.id === entry.moodId);
                return (
                  <button
                    key={entry.id}
                    onClick={() => openModal(entry.dateKey)}
                    className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-pink-50 transition-colors"
                  >
                    <div 
                      className="w-10 h-10 rounded-xl flex items-center justify-center"
                      style={{ backgroundColor: mood?.bgColor || '#FCE4EC' }}
                    >
                      <span className="text-xl">{entry.emoji}</span>
                    </div>
                    <div className="flex-1 text-left">
                      <p className="font-semibold text-gray-800">{entry.label}</p>
                      <p className="text-xs text-gray-400">{formatFullDate(entry.dateKey)}</p>
                    </div>
                    {entry.notes && (
                      <div className="w-2 h-2 bg-pink-400 rounded-full" />
                    )}
                    <ChevronRight className="w-4 h-4 text-gray-300" />
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Tips */}
        <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-5 border border-purple-100">
          <div className="flex items-center gap-3 mb-3">
            <Sparkles className="w-5 h-5 text-purple-500" />
            <h3 className="font-bold text-gray-800 font-['Poppins']">Dica do dia 💕</h3>
          </div>
          <p className="text-gray-600 text-sm leading-relaxed">
            Registrar suas emoções diariamente ajuda a entender seus padrões e a cuidar 
            melhor da sua saúde mental. Não existe humor "errado" — todos os sentimentos são válidos! ✨
          </p>
        </div>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end justify-center">
          <div 
            className="bg-white w-full max-w-lg rounded-t-[32px] max-h-[90vh] overflow-hidden animate-slide-up"
            onClick={e => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-pink-100 to-rose-100 px-6 py-5">
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">💕</span>
                    <h2 className="text-xl font-bold text-[#7A2240] font-['Poppins']">
                      Como você está se sentindo?
                    </h2>
                  </div>
                  <p className="text-[#7A2240]/70 text-sm mt-1">
                    {editingDate && formatFullDate(editingDate)}
                  </p>
                </div>
                <button
                  onClick={closeModal}
                  className="w-10 h-10 bg-white/50 rounded-xl flex items-center justify-center"
                >
                  <X className="w-5 h-5 text-[#7A2240]" />
                </button>
              </div>
            </div>

            {/* Modal Content */}
            <div className="p-6 overflow-y-auto max-h-[calc(90vh-100px)]">
              {/* Selected Mood Preview */}
              {selectedMood && (
                <div className="mb-6 p-4 bg-gradient-to-r from-pink-50 to-rose-50 rounded-2xl border border-pink-200">
                  <div className="flex items-center gap-4">
                    <div 
                      className="w-16 h-16 rounded-2xl flex items-center justify-center"
                      style={{ backgroundColor: MOOD_OPTIONS.find(m => m.id === selectedMood)?.bgColor }}
                    >
                      <span className="text-4xl">
                        {MOOD_OPTIONS.find(m => m.id === selectedMood)?.emoji}
                      </span>
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-pink-600">Você selecionou</p>
                      <p className="font-bold text-xl text-gray-800 font-['Poppins']">
                        {MOOD_OPTIONS.find(m => m.id === selectedMood)?.label}
                      </p>
                    </div>
                    <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                      <Check className="w-5 h-5 text-white" />
                    </div>
                  </div>
                </div>
              )}

              {/* Mood Grid */}
              <div className="space-y-4">
                {/* Positive */}
                <div>
                  <p className="text-sm font-semibold text-gray-500 mb-3 flex items-center gap-2">
                    <span className="text-lg">✨</span> Positivos
                  </p>
                  <div className="grid grid-cols-3 gap-3">
                    {MOOD_OPTIONS.filter(m => m.category === 'positive').map(mood => (
                      <MoodTile
                        key={mood.id}
                        mood={mood}
                        isSelected={selectedMood === mood.id}
                        onSelect={() => handleSelectMood(mood.id)}
                      />
                    ))}
                  </div>
                </div>

                {/* Neutral */}
                <div>
                  <p className="text-sm font-semibold text-gray-500 mb-3 flex items-center gap-2">
                    <span className="text-lg">☁️</span> Neutros
                  </p>
                  <div className="grid grid-cols-3 gap-3">
                    {MOOD_OPTIONS.filter(m => m.category === 'neutral').map(mood => (
                      <MoodTile
                        key={mood.id}
                        mood={mood}
                        isSelected={selectedMood === mood.id}
                        onSelect={() => handleSelectMood(mood.id)}
                      />
                    ))}
                  </div>
                </div>

                {/* Negative */}
                <div>
                  <p className="text-sm font-semibold text-gray-500 mb-3 flex items-center gap-2">
                    <span className="text-lg">🌧️</span> Difíceis
                  </p>
                  <div className="grid grid-cols-3 gap-3">
                    {MOOD_OPTIONS.filter(m => m.category === 'negative').map(mood => (
                      <MoodTile
                        key={mood.id}
                        mood={mood}
                        isSelected={selectedMood === mood.id}
                        onSelect={() => handleSelectMood(mood.id)}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Notes Section */}
              <div className="mt-6">
                <button
                  onClick={() => setShowNotes(!showNotes)}
                  className="text-sm text-pink-600 font-medium flex items-center gap-2"
                >
                  <span>✍️</span>
                  {showNotes ? 'Ocultar notas' : 'Adicionar notas (opcional)'}
                </button>
                
                {showNotes && (
                  <div className="mt-3">
                    <textarea
                      value={notes}
                      onChange={e => setNotes(e.target.value)}
                      placeholder="Como foi seu dia? O que te fez sentir assim?"
                      className="w-full p-4 bg-pink-50 border border-pink-200 rounded-xl text-gray-700 placeholder-gray-400 resize-none focus:outline-none focus:border-pink-400"
                      rows={3}
                    />
                    {selectedMood && (
                      <button
                        onClick={handleSaveWithNotes}
                        className="mt-2 w-full py-3 bg-pink-500 text-white rounded-xl font-semibold"
                      >
                        Salvar com notas
                      </button>
                    )}
                  </div>
                )}
              </div>

              {/* Motivational Message */}
              <div className="mt-6 text-center">
                <p className="text-sm text-gray-400">
                  💕 Lembre-se: todos os sentimentos são válidos
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes slide-up {
          from {
            transform: translateY(100%);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }
        .animate-slide-up {
          animation: slide-up 0.3s ease-out;
        }
      `}</style>
    </div>
  );
}

// Mood Tile Component
interface MoodTileProps {
  mood: MoodOption;
  isSelected: boolean;
  onSelect: () => void;
}

function MoodTile({ mood, isSelected, onSelect }: MoodTileProps) {
  return (
    <button
      onClick={onSelect}
      className={`relative p-4 rounded-2xl border-2 transition-all duration-200 flex flex-col items-center gap-2 ${
        isSelected 
          ? 'border-pink-500 shadow-lg scale-105' 
          : 'border-pink-100 hover:border-pink-300 hover:shadow-md'
      }`}
      style={{ 
        backgroundColor: isSelected ? mood.bgColor : '#FCE4EC',
      }}
    >
      {isSelected && (
        <div className="absolute top-2 right-2 w-5 h-5 bg-pink-500 rounded-full flex items-center justify-center">
          <Check className="w-3 h-3 text-white" />
        </div>
      )}
      <span className="text-3xl">{mood.emoji}</span>
      <span className={`text-sm font-semibold ${isSelected ? 'text-gray-800' : 'text-gray-600'}`}>
        {mood.label}
      </span>
    </button>
  );
}
