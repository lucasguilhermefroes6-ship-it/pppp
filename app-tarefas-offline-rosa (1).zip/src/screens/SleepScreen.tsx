import { useEffect, useState } from 'react';
import { 
  ArrowLeft, Moon, Sun, Clock, TrendingUp, 
  Plus, Trash2, Star, Calendar, Settings, Bed, Coffee
} from 'lucide-react';
import { Screen } from '@/types/screens';
import { useSleepStore, SleepEntry } from '@/store/useSleepStore';

interface SleepScreenProps {
  onNavigate: (screen: Screen) => void;
}

const qualityOptions: { value: SleepEntry['quality']; label: string; emoji: string; color: string }[] = [
  { value: 'bad', label: 'Ruim', emoji: '😴', color: 'bg-red-100 text-red-600 border-red-200' },
  { value: 'ok', label: 'Ok', emoji: '😐', color: 'bg-yellow-100 text-yellow-600 border-yellow-200' },
  { value: 'good', label: 'Bom', emoji: '😊', color: 'bg-green-100 text-green-600 border-green-200' },
  { value: 'great', label: 'Ótimo', emoji: '😴✨', color: 'bg-purple-100 text-purple-600 border-purple-200' },
];

const getYesterday = () => {
  const date = new Date();
  date.setDate(date.getDate() - 1);
  return date.toISOString().split('T')[0];
};

export default function SleepScreen({ onNavigate }: SleepScreenProps) {
  const { 
    entries, idealHours, initialize,
    addSleep, removeSleep, setIdealHours, formatDuration,
    getLastNightSleep, getWeekData, getAverageHours
  } = useSleepStore();
  
  const [showAddModal, setShowAddModal] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [newIdealHours, setNewIdealHours] = useState(idealHours);
  
  // Form state
  const [formDate, setFormDate] = useState(getYesterday());
  const [formSleepTime, setFormSleepTime] = useState('23:00');
  const [formWakeTime, setFormWakeTime] = useState('07:00');
  const [formQuality, setFormQuality] = useState<SleepEntry['quality']>('good');
  const [formNotes, setFormNotes] = useState('');
  
  useEffect(() => {
    initialize();
  }, [initialize]);
  
  useEffect(() => {
    setNewIdealHours(idealHours);
  }, [idealHours]);
  
  const lastNight = getLastNightSleep();
  const weekData = getWeekData();
  const avgHours = getAverageHours();
  
  // Calculate sleep debt
  const idealMinutes = idealHours * 60;
  const avgMinutes = avgHours.hours * 60 + avgHours.minutes;
  const sleepDebt = idealMinutes - avgMinutes;
  
  const handleAddSleep = async () => {
    await addSleep({
      date: formDate,
      sleepTime: formSleepTime,
      wakeTime: formWakeTime,
      quality: formQuality,
      notes: formNotes || undefined,
    });
    setShowAddModal(false);
    // Reset form
    setFormDate(getYesterday());
    setFormSleepTime('23:00');
    setFormWakeTime('07:00');
    setFormQuality('good');
    setFormNotes('');
  };
  
  const handleSaveSettings = async () => {
    await setIdealHours(newIdealHours);
    setShowSettings(false);
  };
  
  const formatDateShort = (dateStr: string) => {
    const date = new Date(dateStr + 'T12:00:00');
    const days = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
    return days[date.getDay()];
  };
  
  const formatDateFull = (dateStr: string) => {
    const date = new Date(dateStr + 'T12:00:00');
    return date.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });
  };
  
  // Calculate preview duration
  const previewDuration = (() => {
    const [sleepH, sleepM] = formSleepTime.split(':').map(Number);
    const [wakeH, wakeM] = formWakeTime.split(':').map(Number);
    
    let sleepMinutes = sleepH * 60 + sleepM;
    let wakeMinutes = wakeH * 60 + wakeM;
    
    if (wakeMinutes <= sleepMinutes) {
      wakeMinutes += 24 * 60;
    }
    
    return wakeMinutes - sleepMinutes;
  })();
  
  // localStorage is synchronous, so no loading needed
  
  return (
    <div className="min-h-screen bg-[#FFF5F8]">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-500 via-purple-500 to-indigo-400 px-4 pt-8 pb-6">
        <div className="flex items-center justify-between mb-4">
          <button 
            onClick={() => onNavigate({ name: 'home' })}
            className="w-10 h-10 bg-white/20 backdrop-blur rounded-xl flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <h1 className="text-xl font-bold text-white font-['Poppins']">Sono</h1>
          <button 
            onClick={() => setShowSettings(true)}
            className="w-10 h-10 bg-white/20 backdrop-blur rounded-xl flex items-center justify-center"
          >
            <Settings className="w-5 h-5 text-white" />
          </button>
        </div>
        
        {/* Last night summary */}
        <div className="bg-white/10 backdrop-blur rounded-2xl p-4 mt-4">
          {lastNight ? (
            <div className="text-center">
              <p className="text-white/70 text-sm mb-1">Última noite</p>
              <div className="flex items-center justify-center gap-2 mb-3">
                <Moon className="w-6 h-6 text-white" />
                <span className="text-4xl font-bold text-white font-['Poppins']">
                  {formatDuration(lastNight.durationMinutes)}
                </span>
              </div>
              <div className="flex items-center justify-center gap-4 text-white/80 text-sm">
                <div className="flex items-center gap-1">
                  <Bed className="w-4 h-4" />
                  <span>{lastNight.sleepTime}</span>
                </div>
                <div className="w-px h-4 bg-white/30" />
                <div className="flex items-center gap-1">
                  <Coffee className="w-4 h-4" />
                  <span>{lastNight.wakeTime}</span>
                </div>
              </div>
              {lastNight.quality && (
                <div className="mt-2">
                  <span className="bg-white/20 px-3 py-1 rounded-full text-sm">
                    {qualityOptions.find(q => q.value === lastNight.quality)?.emoji} {' '}
                    {qualityOptions.find(q => q.value === lastNight.quality)?.label}
                  </span>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-4">
              <Moon className="w-10 h-10 text-white/50 mx-auto mb-2" />
              <p className="text-white/70">Nenhum registro de sono</p>
              <p className="text-white/50 text-sm">Adicione sua primeira noite!</p>
            </div>
          )}
        </div>
      </div>
      
      <div className="px-4 -mt-4 pb-24 space-y-4">
        {/* Stats Row */}
        <div className="grid grid-cols-3 gap-3">
          {/* Average */}
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100 text-center">
            <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-2">
              <TrendingUp className="w-5 h-5 text-purple-500" />
            </div>
            <p className="text-lg font-bold text-gray-800 font-['Poppins']">
              {avgHours.hours}h{avgHours.minutes.toString().padStart(2, '0')}
            </p>
            <p className="text-xs text-gray-500">média/noite</p>
          </div>
          
          {/* Goal */}
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100 text-center">
            <div className="w-10 h-10 bg-indigo-100 rounded-xl flex items-center justify-center mx-auto mb-2">
              <Star className="w-5 h-5 text-indigo-500" />
            </div>
            <p className="text-lg font-bold text-gray-800 font-['Poppins']">{idealHours}h</p>
            <p className="text-xs text-gray-500">meta ideal</p>
          </div>
          
          {/* Debt/Surplus */}
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100 text-center">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center mx-auto mb-2 ${
              sleepDebt > 0 ? 'bg-red-100' : 'bg-green-100'
            }`}>
              <Clock className={`w-5 h-5 ${sleepDebt > 0 ? 'text-red-500' : 'text-green-500'}`} />
            </div>
            <p className={`text-lg font-bold font-['Poppins'] ${
              sleepDebt > 0 ? 'text-red-500' : 'text-green-500'
            }`}>
              {sleepDebt > 0 ? '-' : '+'}{formatDuration(Math.abs(sleepDebt))}
            </p>
            <p className="text-xs text-gray-500">{sleepDebt > 0 ? 'débito' : 'extra'}</p>
          </div>
        </div>
        
        {/* Week Chart */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-gray-700 font-['Poppins']">Última Semana</h3>
            <Calendar className="w-4 h-4 text-purple-500" />
          </div>
          
          <div className="space-y-3">
            {[...Array(7)].map((_, i) => {
              const date = new Date();
              date.setDate(date.getDate() - (6 - i));
              const dateStr = date.toISOString().split('T')[0];
              const entry = weekData.find(e => e.date === dateStr);
              const progress = entry ? (entry.durationMinutes / (idealHours * 60)) * 100 : 0;
              const isToday = i === 6;
              
              return (
                <div key={i} className="flex items-center gap-3">
                  <div className={`w-10 text-xs ${isToday ? 'text-purple-600 font-bold' : 'text-gray-500'}`}>
                    {formatDateShort(dateStr)}
                  </div>
                  <div className="flex-1 h-6 bg-gray-100 rounded-full overflow-hidden relative">
                    {entry && (
                      <div 
                        className={`h-full rounded-full transition-all duration-500 ${
                          progress >= 100 
                            ? 'bg-gradient-to-r from-green-400 to-green-300' 
                            : progress >= 75 
                              ? 'bg-gradient-to-r from-purple-400 to-indigo-300'
                              : 'bg-gradient-to-r from-orange-400 to-yellow-300'
                        }`}
                        style={{ width: `${Math.min(progress, 100)}%` }}
                      />
                    )}
                    {/* Goal line */}
                    <div 
                      className="absolute top-0 bottom-0 w-0.5 bg-gray-300"
                      style={{ left: '100%' }}
                    />
                  </div>
                  <div className="w-14 text-right text-sm font-medium text-gray-700">
                    {entry ? formatDuration(entry.durationMinutes) : '—'}
                  </div>
                </div>
              );
            })}
          </div>
          
          <div className="flex items-center justify-center gap-4 mt-4 text-xs text-gray-500">
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 rounded-full bg-gradient-to-r from-green-400 to-green-300" />
              <span>Meta atingida</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 rounded-full bg-gradient-to-r from-purple-400 to-indigo-300" />
              <span>Quase lá</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 rounded-full bg-gradient-to-r from-orange-400 to-yellow-300" />
              <span>Pouco sono</span>
            </div>
          </div>
        </div>
        
        {/* History */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
          <h3 className="text-sm font-semibold text-gray-700 mb-3 font-['Poppins']">Histórico</h3>
          
          {entries.length === 0 ? (
            <div className="text-center py-8">
              <Moon className="w-12 h-12 text-gray-200 mx-auto mb-3" />
              <p className="text-gray-400">Nenhum registro ainda</p>
              <p className="text-sm text-gray-300">Comece a monitorar seu sono!</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {entries.slice(0, 10).map(entry => (
                <div 
                  key={entry.id}
                  className="flex items-center justify-between bg-gray-50 rounded-xl p-3"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center">
                      <Moon className="w-5 h-5 text-purple-500" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-800">
                        {formatDuration(entry.durationMinutes)}
                      </p>
                      <p className="text-xs text-gray-500">
                        {formatDateFull(entry.date)} • {entry.sleepTime} → {entry.wakeTime}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {entry.quality && (
                      <span className="text-lg">
                        {qualityOptions.find(q => q.value === entry.quality)?.emoji}
                      </span>
                    )}
                    <button
                      onClick={() => removeSleep(entry.id)}
                      className="w-8 h-8 bg-red-50 hover:bg-red-100 rounded-lg flex items-center justify-center transition-colors"
                    >
                      <Trash2 className="w-4 h-4 text-red-400" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        
        {/* Tips Card */}
        <div className="bg-gradient-to-r from-indigo-500 to-purple-500 rounded-2xl p-4 text-white">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0">
              <Star className="w-5 h-5" />
            </div>
            <div>
              <p className="font-semibold mb-1">Dica para dormir melhor</p>
              <p className="text-sm text-white/80">
                Evite telas azuis 1h antes de dormir e mantenha o quarto fresco e escuro 🌙
              </p>
            </div>
          </div>
        </div>
      </div>
      
      {/* FAB */}
      <button
        onClick={() => setShowAddModal(true)}
        className="fixed bottom-6 right-6 bg-gradient-to-r from-indigo-500 to-purple-500 text-white 
          px-6 py-4 rounded-2xl shadow-lg flex items-center gap-2 font-semibold"
      >
        <Plus className="w-5 h-5" />
        Registrar Sono
      </button>
      
      {/* Add Sleep Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 flex items-end justify-center z-50">
          <div className="bg-white rounded-t-3xl w-full max-w-lg p-6 animate-slide-up max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-gray-800 font-['Poppins']">Registrar Sono</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-gray-400 hover:text-gray-600 text-2xl"
              >
                ×
              </button>
            </div>
            
            <div className="space-y-5">
              {/* Date */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Noite de
                </label>
                <input
                  type="date"
                  value={formDate}
                  onChange={e => setFormDate(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>
              
              {/* Time inputs */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                    <Moon className="w-4 h-4 text-purple-500" />
                    Hora de dormir
                  </label>
                  <input
                    type="time"
                    value={formSleepTime}
                    onChange={e => setFormSleepTime(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                    <Sun className="w-4 h-4 text-orange-400" />
                    Hora de acordar
                  </label>
                  <input
                    type="time"
                    value={formWakeTime}
                    onChange={e => setFormWakeTime(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>
              </div>
              
              {/* Duration preview */}
              <div className="bg-purple-50 rounded-xl p-4 text-center">
                <p className="text-sm text-purple-600 mb-1">Duração do sono</p>
                <p className="text-3xl font-bold text-purple-700 font-['Poppins']">
                  {formatDuration(previewDuration)}
                </p>
              </div>
              
              {/* Quality */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Qualidade do sono
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {qualityOptions.map(option => (
                    <button
                      key={option.value}
                      onClick={() => setFormQuality(option.value)}
                      className={`p-3 rounded-xl border-2 transition-all flex flex-col items-center ${
                        formQuality === option.value 
                          ? option.color + ' border-current' 
                          : 'bg-gray-50 border-gray-100 hover:bg-gray-100'
                      }`}
                    >
                      <span className="text-xl mb-1">{option.emoji}</span>
                      <span className="text-xs font-medium">{option.label}</span>
                    </button>
                  ))}
                </div>
              </div>
              
              {/* Notes */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Observações (opcional)
                </label>
                <textarea
                  value={formNotes}
                  onChange={e => setFormNotes(e.target.value)}
                  placeholder="Como foi sua noite?"
                  rows={2}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
                />
              </div>
              
              <button
                onClick={handleAddSleep}
                className="w-full bg-gradient-to-r from-indigo-500 to-purple-500 text-white py-4 rounded-xl font-semibold"
              >
                Salvar Registro
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 bg-black/50 flex items-end justify-center z-50">
          <div className="bg-white rounded-t-3xl w-full max-w-lg p-6 animate-slide-up">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-gray-800 font-['Poppins']">Configurações</h3>
              <button
                onClick={() => setShowSettings(false)}
                className="text-gray-400 hover:text-gray-600 text-2xl"
              >
                ×
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Meta de sono (horas por noite)
                </label>
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => setNewIdealHours(Math.max(4, newIdealHours - 0.5))}
                    className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center"
                  >
                    <span className="text-xl">-</span>
                  </button>
                  <div className="flex-1 text-center">
                    <span className="text-3xl font-bold text-gray-800">{newIdealHours}</span>
                    <span className="text-xl text-gray-500 ml-1">horas</span>
                  </div>
                  <button
                    onClick={() => setNewIdealHours(Math.min(12, newIdealHours + 0.5))}
                    className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center"
                  >
                    <span className="text-xl">+</span>
                  </button>
                </div>
              </div>
              
              {/* Preset goals */}
              <div className="grid grid-cols-4 gap-2">
                {[6, 7, 8, 9].map(hours => (
                  <button
                    key={hours}
                    onClick={() => setNewIdealHours(hours)}
                    className={`py-2 rounded-xl text-sm font-medium transition-all ${
                      newIdealHours === hours 
                        ? 'bg-purple-500 text-white' 
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {hours}h
                  </button>
                ))}
              </div>
              
              <button
                onClick={handleSaveSettings}
                className="w-full bg-gradient-to-r from-indigo-500 to-purple-500 text-white py-4 rounded-xl font-semibold"
              >
                Salvar
              </button>
            </div>
          </div>
        </div>
      )}
      
      <style>{`
        @keyframes slide-up {
          from { transform: translateY(100%); }
          to { transform: translateY(0); }
        }
        .animate-slide-up {
          animation: slide-up 0.3s ease-out;
        }
      `}</style>
    </div>
  );
}
