import { useEffect, useRef } from 'react';
import { 
  ArrowLeft, 
  Play, 
  Pause, 
  RotateCcw, 
  SkipForward,
  Timer,
  Coffee,
  Moon,
  Flame,
  Clock,
  Target
} from 'lucide-react';
import { usePomodoroStore, PomodoroMode } from '@/store/usePomodoroStore';
import { Screen } from '@/types/screens';
import { cn } from '@/utils/cn';

interface PomodoroScreenProps {
  onNavigate: (screen: Screen) => void;
}

const MOTIVATIONAL_TIPS = [
  '💪 Foco total! Você consegue!',
  '🌟 Cada sessão te aproxima do seu objetivo!',
  '🎯 Mantenha a concentração, você está indo bem!',
  '💖 Cuide da sua mente, faça pausas quando precisar.',
  '🚀 Produtividade é sobre consistência, não perfeição.',
  '✨ Você é incrível! Continue assim!',
  '🌸 Lembre-se: pequenos passos fazem grandes jornadas.'
];

export default function PomodoroScreen({ onNavigate }: PomodoroScreenProps) {
  const {
    mode,
    timeRemaining,
    isRunning,
    sessionsToday,
    totalFocusTime,
    currentStreak,
    setMode,
    start,
    pause,
    reset,
    tick,
    skip
  } = usePomodoroStore();
  
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  
  useEffect(() => {
    if (isRunning) {
      intervalRef.current = setInterval(() => {
        tick();
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    }
    
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isRunning, tick]);
  
  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  const getProgress = (): number => {
    const total = mode === 'focus' ? 25 * 60 : mode === 'shortBreak' ? 5 * 60 : 15 * 60;
    return ((total - timeRemaining) / total) * 100;
  };
  
  const getModeConfig = (m: PomodoroMode) => {
    switch (m) {
      case 'focus':
        return { 
          label: 'Foco', 
          icon: Timer, 
          color: 'from-pink-400 to-pink-500',
          bgColor: 'bg-pink-500'
        };
      case 'shortBreak':
        return { 
          label: 'Pausa Curta', 
          icon: Coffee, 
          color: 'from-emerald-400 to-emerald-500',
          bgColor: 'bg-emerald-500'
        };
      case 'longBreak':
        return { 
          label: 'Pausa Longa', 
          icon: Moon, 
          color: 'from-blue-400 to-blue-500',
          bgColor: 'bg-blue-500'
        };
    }
  };
  
  const currentConfig = getModeConfig(mode);
  const tipIndex = (new Date().getHours() + sessionsToday) % MOTIVATIONAL_TIPS.length;
  
  return (
    <div className={cn(
      'min-h-screen transition-colors duration-500',
      mode === 'focus' ? 'bg-[#FFF5F8]' : 
      mode === 'shortBreak' ? 'bg-emerald-50' : 'bg-blue-50'
    )}>
      {/* Header */}
      <header className={cn(
        'px-4 pt-10 pb-6 bg-gradient-to-br text-white',
        currentConfig.color
      )}>
        <div className="max-w-lg mx-auto">
          <div className="flex items-center gap-3 mb-4">
            <button
              onClick={() => onNavigate({ name: 'home' })}
              className="p-2 -ml-2 rounded-lg hover:bg-white/10 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-xl font-bold font-poppins">Pomodoro</h1>
          </div>
          
          {/* Mode Tabs */}
          <div className="flex bg-white/20 rounded-xl p-1 gap-1">
            {(['focus', 'shortBreak', 'longBreak'] as PomodoroMode[]).map((m) => {
              const config = getModeConfig(m);
              const Icon = config.icon;
              const isActive = mode === m;
              
              return (
                <button
                  key={m}
                  onClick={() => setMode(m)}
                  className={cn(
                    'flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-semibold transition-all',
                    isActive 
                      ? 'bg-white text-gray-800 shadow-sm' 
                      : 'text-white/80 hover:text-white hover:bg-white/10'
                  )}
                >
                  <Icon className="w-4 h-4" />
                  <span className="hidden sm:inline">{config.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </header>
      
      {/* Timer */}
      <main className="px-4 py-8 max-w-lg mx-auto">
        {/* Circular Timer */}
        <div className="flex justify-center mb-8">
          <div className="relative">
            {/* Background Circle */}
            <svg className="w-64 h-64 transform -rotate-90">
              <circle
                cx="128"
                cy="128"
                r="120"
                stroke="currentColor"
                strokeWidth="8"
                fill="none"
                className="text-white"
              />
              <circle
                cx="128"
                cy="128"
                r="120"
                stroke="url(#gradient)"
                strokeWidth="8"
                fill="none"
                strokeLinecap="round"
                strokeDasharray={2 * Math.PI * 120}
                strokeDashoffset={2 * Math.PI * 120 * (1 - getProgress() / 100)}
                className="transition-all duration-1000"
              />
              <defs>
                <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor={mode === 'focus' ? '#F472B6' : mode === 'shortBreak' ? '#34D399' : '#60A5FA'} />
                  <stop offset="100%" stopColor={mode === 'focus' ? '#EC4899' : mode === 'shortBreak' ? '#10B981' : '#3B82F6'} />
                </linearGradient>
              </defs>
            </svg>
            
            {/* Time Display */}
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className={cn(
                'text-6xl font-bold font-poppins',
                mode === 'focus' ? 'text-pink-600' : 
                mode === 'shortBreak' ? 'text-emerald-600' : 'text-blue-600'
              )}>
                {formatTime(timeRemaining)}
              </span>
              <span className="text-gray-500 text-sm mt-2 font-medium">
                {currentConfig.label}
              </span>
            </div>
          </div>
        </div>
        
        {/* Controls */}
        <div className="flex items-center justify-center gap-4 mb-8">
          <button
            onClick={reset}
            className="w-14 h-14 rounded-full bg-white shadow-lg flex items-center justify-center hover:scale-105 transition-transform border border-gray-100"
          >
            <RotateCcw className="w-6 h-6 text-gray-600" />
          </button>
          
          <button
            onClick={isRunning ? pause : start}
            className={cn(
              'w-20 h-20 rounded-full shadow-xl flex items-center justify-center hover:scale-105 transition-all',
              'bg-gradient-to-br text-white',
              currentConfig.color
            )}
            style={{
              boxShadow: mode === 'focus' 
                ? '0 8px 24px rgba(236, 72, 153, 0.4)' 
                : mode === 'shortBreak'
                  ? '0 8px 24px rgba(16, 185, 129, 0.4)'
                  : '0 8px 24px rgba(59, 130, 246, 0.4)'
            }}
          >
            {isRunning ? (
              <Pause className="w-8 h-8" />
            ) : (
              <Play className="w-8 h-8 ml-1" />
            )}
          </button>
          
          <button
            onClick={skip}
            className="w-14 h-14 rounded-full bg-white shadow-lg flex items-center justify-center hover:scale-105 transition-transform border border-gray-100"
          >
            <SkipForward className="w-6 h-6 text-gray-600" />
          </button>
        </div>
        
        {/* Stats Cards */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="bg-white rounded-2xl p-4 text-center shadow-sm border border-pink-100">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Target className="w-4 h-4 text-pink-500" />
            </div>
            <div className="text-2xl font-bold text-pink-600">{sessionsToday}</div>
            <div className="text-xs text-gray-500">Sessões</div>
          </div>
          
          <div className="bg-white rounded-2xl p-4 text-center shadow-sm border border-pink-100">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Clock className="w-4 h-4 text-pink-500" />
            </div>
            <div className="text-2xl font-bold text-pink-600">{totalFocusTime}</div>
            <div className="text-xs text-gray-500">Minutos</div>
          </div>
          
          <div className="bg-white rounded-2xl p-4 text-center shadow-sm border border-pink-100">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Flame className="w-4 h-4 text-orange-500" />
            </div>
            <div className="text-2xl font-bold text-orange-500">{currentStreak}</div>
            <div className="text-xs text-gray-500">Sequência</div>
          </div>
        </div>
        
        {/* Motivational Tip */}
        <div className={cn(
          'rounded-2xl p-4 border',
          mode === 'focus' ? 'bg-pink-50 border-pink-200' :
          mode === 'shortBreak' ? 'bg-emerald-50 border-emerald-200' :
          'bg-blue-50 border-blue-200'
        )}>
          <p className={cn(
            'text-center font-medium',
            mode === 'focus' ? 'text-pink-600' :
            mode === 'shortBreak' ? 'text-emerald-600' :
            'text-blue-600'
          )}>
            {MOTIVATIONAL_TIPS[tipIndex]}
          </p>
        </div>
        
        {/* Info Section */}
        <div className="mt-6 bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
          <h3 className="font-semibold text-gray-800 mb-3 font-poppins">Como funciona?</h3>
          <ul className="space-y-2 text-sm text-gray-600">
            <li className="flex items-start gap-2">
              <span className="text-pink-500">🍅</span>
              <span><strong>Foco:</strong> 25 minutos de concentração total</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-500">☕</span>
              <span><strong>Pausa Curta:</strong> 5 minutos para descansar</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-500">🌙</span>
              <span><strong>Pausa Longa:</strong> 15 minutos após 4 sessões</span>
            </li>
          </ul>
        </div>
      </main>
    </div>
  );
}
