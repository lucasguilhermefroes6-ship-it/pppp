import { useState, useEffect } from 'react';
import { Screen } from '../types/screens';
import { useMyRecordsStore, formatMinutesToHhMm } from '../store/useMyRecordsStore';

interface Props {
  setScreen: (screen: Screen) => void;
}

const COLORS = {
  primary: '#FF2D95',
  background: '#FFF3FA',
  card: '#FFFFFF',
  border: '#EFB2D3',
  textPrimary: '#241225',
  textSecondary: '#6B3D5F',
  success: '#2E7D32',
  error: '#C62828',
};

export default function MyRecordsGoalsScreen({ setScreen }: Props) {
  const { goals, initDB, saveGoals, isLoading } = useMyRecordsStore();
  
  const [calorieMin, setCalorieMin] = useState('');
  const [calorieMax, setCalorieMax] = useState('');
  const [fastingHours, setFastingHours] = useState('');
  const [fastingMinutes, setFastingMinutes] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  
  useEffect(() => {
    initDB();
  }, [initDB]);
  
  useEffect(() => {
    if (goals) {
      setCalorieMin(goals.calorieMinKcal?.toString() || '');
      setCalorieMax(goals.calorieMaxKcal?.toString() || '');
      if (goals.fastingTargetMinutes) {
        setFastingHours(Math.floor(goals.fastingTargetMinutes / 60).toString());
        setFastingMinutes((goals.fastingTargetMinutes % 60).toString());
      }
    }
  }, [goals]);
  
  const [error, setError] = useState<string | null>(null);
  
  const handleSave = async () => {
    setError(null);
    
    // Validação: ambos min e max devem ser preenchidos juntos
    const hasMin = calorieMin && calorieMin.trim() !== '';
    const hasMax = calorieMax && calorieMax.trim() !== '';
    
    if ((hasMin && !hasMax) || (!hasMin && hasMax)) {
      setError('Preencha tanto o mínimo quanto o máximo de calorias, ou deixe ambos vazios.');
      return;
    }
    
    if (hasMin && hasMax) {
      const min = parseInt(calorieMin);
      const max = parseInt(calorieMax);
      
      if (isNaN(min) || isNaN(max)) {
        setError('Os valores de calorias devem ser números válidos.');
        return;
      }
      
      if (min <= 0 || max <= 0) {
        setError('Os valores de calorias devem ser maiores que zero.');
        return;
      }
      
      if (min > max) {
        setError('A meta mínima não pode ser maior que a máxima.');
        return;
      }
      
      if (min === max) {
        setError('O valor mínimo deve ser diferente do máximo para criar um intervalo.');
        return;
      }
    }
    
    setIsSaving(true);
    try {
      let fastingTargetMinutes: number | undefined;
      if (fastingHours || fastingMinutes) {
        const h = parseInt(fastingHours) || 0;
        const m = parseInt(fastingMinutes) || 0;
        fastingTargetMinutes = h * 60 + m;
        if (fastingTargetMinutes <= 0) {
          fastingTargetMinutes = undefined;
        }
      }
      
      await saveGoals({
        calorieMinKcal: hasMin ? parseInt(calorieMin) : undefined,
        calorieMaxKcal: hasMax ? parseInt(calorieMax) : undefined,
        fastingTargetMinutes,
      });
      
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (error) {
      console.error('Error saving goals:', error);
      setError('Erro ao salvar. Tente novamente.');
    }
    setIsSaving(false);
  };
  
  const currentFastingMinutes = (parseInt(fastingHours) || 0) * 60 + (parseInt(fastingMinutes) || 0);
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: COLORS.background }}>
        <div className="w-12 h-12 border-4 border-pink-200 border-t-pink-500 rounded-full animate-spin" />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen pb-8" style={{ background: COLORS.background }}>
      {/* Header */}
      <div 
        className="pt-12 pb-6 px-5"
        style={{ background: `linear-gradient(135deg, ${COLORS.primary}20, ${COLORS.background})` }}
      >
        <div className="flex items-center justify-between">
          <button
            onClick={() => setScreen({ name: 'my-records' })}
            className="w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center"
          >
            <svg className="w-5 h-5" fill="none" stroke={COLORS.primary} viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          
          <div className="flex items-center gap-2">
            {saved && (
              <span className="text-sm font-medium animate-pulse" style={{ color: COLORS.success }}>
                ✓ Salvo!
              </span>
            )}
            <button
              onClick={handleSave}
              disabled={isSaving}
              className="px-5 py-2.5 rounded-xl flex items-center gap-2 shadow-md"
              style={{ 
                background: `linear-gradient(135deg, ${COLORS.primary}, #FF6B9D)`,
                opacity: isSaving ? 0.7 : 1
              }}
            >
              <svg className="w-4 h-4" fill="none" stroke="white" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span className="text-white font-semibold">
                {isSaving ? 'Salvando...' : 'Salvar'}
              </span>
            </button>
          </div>
        </div>
        
        <h1 className="text-2xl font-bold mt-4" style={{ color: COLORS.textPrimary }}>
          Minhas Metas
        </h1>
        <p style={{ color: COLORS.textSecondary }}>Configure suas metas diárias</p>
      </div>
      
      <div className="px-5 -mt-2 space-y-4">
        {/* Hero Card */}
        <div 
          className="rounded-2xl p-5"
          style={{ 
            background: `linear-gradient(135deg, ${COLORS.primary}, #FF6B9D)`,
            boxShadow: '0 4px 15px rgba(255, 45, 149, 0.3)'
          }}
        >
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-xl bg-white/20 flex items-center justify-center">
              <span className="text-3xl">🎯</span>
            </div>
            <div>
              <h2 className="text-white text-lg font-bold">Defina suas metas</h2>
              <p className="text-white/80 text-sm">Acompanhe seu progresso diário</p>
            </div>
          </div>
        </div>
        
        {/* Calories Goal */}
        <div 
          className="rounded-2xl p-4"
          style={{ 
            background: COLORS.card, 
            border: `1.5px solid ${COLORS.border}`,
            boxShadow: '0 2px 8px rgba(0,0,0,0.06)'
          }}
        >
          <div className="flex items-center gap-3 mb-4">
            <div 
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: '#FFF4E5' }}
            >
              <span className="text-xl">🔥</span>
            </div>
            <div>
              <h3 className="font-bold" style={{ color: COLORS.textPrimary }}>Meta de Calorias</h3>
              <p className="text-sm" style={{ color: COLORS.textSecondary }}>Intervalo mínimo–máximo por dia</p>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm mb-1" style={{ color: COLORS.textSecondary }}>
                Mínimo (kcal)
              </label>
              <input
                type="number"
                value={calorieMin}
                onChange={(e) => { setCalorieMin(e.target.value); setError(null); }}
                placeholder="1500"
                min="500"
                max="5000"
                className="w-full p-3 rounded-xl text-center font-medium"
                style={{ 
                  background: '#F8F4F6',
                  color: COLORS.textPrimary,
                  border: `1px solid ${error ? COLORS.error : COLORS.border}`
                }}
              />
            </div>
            
            <div>
              <label className="block text-sm mb-1" style={{ color: COLORS.textSecondary }}>
                Máximo (kcal)
              </label>
              <input
                type="number"
                value={calorieMax}
                onChange={(e) => { setCalorieMax(e.target.value); setError(null); }}
                placeholder="2000"
                min="500"
                max="5000"
                className="w-full p-3 rounded-xl text-center font-medium"
                style={{ 
                  background: '#F8F4F6',
                  color: COLORS.textPrimary,
                  border: `1px solid ${error ? COLORS.error : COLORS.border}`
                }}
              />
            </div>
          </div>
          
          {/* Error Message */}
          {error && (
            <div 
              className="mt-3 p-3 rounded-xl flex items-center gap-2"
              style={{ background: '#FFEBEE', border: `1px solid ${COLORS.error}` }}
            >
              <svg className="w-5 h-5 flex-shrink-0" fill={COLORS.error} viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
              <p className="text-sm" style={{ color: COLORS.error }}>{error}</p>
            </div>
          )}
          
          <div 
            className="mt-4 p-3 rounded-xl"
            style={{ background: '#FFF9E6', border: '1px solid #F5D46A' }}
          >
            <p className="text-xs" style={{ color: '#8B6914' }}>
              💡 <strong>Dica:</strong> Você bate a meta quando suas calorias ficam dentro deste intervalo.
              Exemplo: se a meta é 1500–2000 kcal, consumir 1750 kcal conta como atingido!
            </p>
          </div>
        </div>
        
        {/* Fasting Goal */}
        <div 
          className="rounded-2xl p-4"
          style={{ 
            background: COLORS.card, 
            border: `1.5px solid ${COLORS.border}`,
            boxShadow: '0 2px 8px rgba(0,0,0,0.06)'
          }}
        >
          <div className="flex items-center gap-3 mb-4">
            <div 
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: '#E8F5E9' }}
            >
              <span className="text-xl">⏱️</span>
            </div>
            <div>
              <h3 className="font-bold" style={{ color: COLORS.textPrimary }}>Meta de Jejum</h3>
              <p className="text-sm" style={{ color: COLORS.textSecondary }}>Mínimo de horas por dia</p>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm mb-1" style={{ color: COLORS.textSecondary }}>
                Horas
              </label>
              <input
                type="number"
                value={fastingHours}
                onChange={(e) => setFastingHours(e.target.value)}
                placeholder="16"
                min="0"
                max="23"
                className="w-full p-3 rounded-xl text-center font-medium"
                style={{ 
                  background: '#F8F4F6',
                  color: COLORS.textPrimary,
                  border: `1px solid ${COLORS.border}`
                }}
              />
            </div>
            
            <div>
              <label className="block text-sm mb-1" style={{ color: COLORS.textSecondary }}>
                Minutos
              </label>
              <input
                type="number"
                value={fastingMinutes}
                onChange={(e) => setFastingMinutes(e.target.value)}
                placeholder="0"
                min="0"
                max="59"
                className="w-full p-3 rounded-xl text-center font-medium"
                style={{ 
                  background: '#F8F4F6',
                  color: COLORS.textPrimary,
                  border: `1px solid ${COLORS.border}`
                }}
              />
            </div>
          </div>
          
          {/* Preview */}
          {currentFastingMinutes > 0 && (
            <div 
              className="mt-4 p-3 rounded-xl text-center"
              style={{ background: `${COLORS.success}15` }}
            >
              <p className="text-sm" style={{ color: COLORS.textSecondary }}>
                Meta de jejum:
              </p>
              <p className="text-xl font-bold" style={{ color: COLORS.success }}>
                {formatMinutesToHhMm(currentFastingMinutes)}
              </p>
            </div>
          )}
          
          {/* Preset buttons */}
          <div className="flex flex-wrap gap-2 mt-3">
            {[
              { label: '12h', h: 12, m: 0 },
              { label: '14h', h: 14, m: 0 },
              { label: '16h', h: 16, m: 0 },
              { label: '18h', h: 18, m: 0 },
              { label: '20h', h: 20, m: 0 },
            ].map((preset) => (
              <button
                key={preset.label}
                onClick={() => { setFastingHours(preset.h.toString()); setFastingMinutes(preset.m.toString()); }}
                className="px-4 py-2 rounded-xl text-sm font-medium transition-colors"
                style={{ 
                  background: currentFastingMinutes === preset.h * 60 + preset.m ? COLORS.primary : '#F8F4F6',
                  color: currentFastingMinutes === preset.h * 60 + preset.m ? 'white' : COLORS.textSecondary,
                  border: `1px solid ${COLORS.border}`
                }}
              >
                {preset.label}
              </button>
            ))}
          </div>
          
          <div 
            className="mt-4 p-3 rounded-xl"
            style={{ background: '#FFF9E6', border: '1px solid #F5D46A' }}
          >
            <p className="text-xs" style={{ color: '#8B6914' }}>
              💡 <strong>Dica:</strong> Você bate a meta quando seu jejum atingir pelo menos este tempo mínimo.
              Jejum de 16 horas (16:8) é o mais popular para iniciantes!
            </p>
          </div>
        </div>
        
        {/* Info Card */}
        <div 
          className="rounded-2xl p-4"
          style={{ 
            background: '#E3F2FD', 
            border: `1.5px solid #90CAF9`,
          }}
        >
          <div className="flex items-start gap-3">
            <span className="text-2xl">ℹ️</span>
            <div>
              <p className="font-semibold text-sm" style={{ color: '#1565C0' }}>
                Como funciona
              </p>
              <ul className="text-xs mt-1 space-y-1" style={{ color: '#1976D2' }}>
                <li>• <strong>Calorias:</strong> Meta de INTERVALO - você acerta quando fica dentro do mínimo e máximo.</li>
                <li>• <strong>Jejum:</strong> Meta de MÍNIMO - você acerta quando jejua pelo menos esse tempo.</li>
                <li>• O app conta quantos dias por semana você atingiu cada meta!</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
