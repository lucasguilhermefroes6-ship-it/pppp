import React, { useEffect, useState } from 'react';
import { Screen } from '../types/screens';
import { useNotepadStore } from '../store/useNotepadStore';
import { NotepadNote } from '../types';

interface Props {
  setScreen: (screen: Screen) => void;
}

// Note colors
const NOTE_COLORS = [
  { hex: '#FCE4EC', name: 'Rosa' },
  { hex: '#E3F2FD', name: 'Azul' },
  { hex: '#E8F5E9', name: 'Verde' },
  { hex: '#FFF3E0', name: 'Laranja' },
  { hex: '#F3E5F5', name: 'Roxo' },
  { hex: '#FFFDE7', name: 'Amarelo' },
  { hex: '#FFFFFF', name: 'Branco' },
];

// Time relative helper
const getRelativeTime = (dateStr: string): string => {
  const date = new Date(dateStr);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffSecs = Math.floor(diffMs / 1000);
  const diffMins = Math.floor(diffSecs / 60);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffSecs < 60) return 'Agora';
  if (diffMins < 60) return `${diffMins} min`;
  if (diffHours < 24) return `${diffHours}h`;
  if (diffDays === 1) return 'Ontem';
  if (diffDays < 7) return `${diffDays} dias`;
  if (diffDays < 30) return `${Math.floor(diffDays / 7)} sem`;
  return `${Math.floor(diffDays / 30)} mês`;
};

export const NotepadScreen: React.FC<Props> = ({ setScreen }) => {
  const {
    notes,
    isLoading,
    searchQuery,
    loadNotes,
    deleteNote,
    togglePinned,
    setSearchQuery,
    getFilteredNotes,
  } = useNotepadStore();

  const [showSearch, setShowSearch] = useState(false);
  const [menuOpen, setMenuOpen] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  useEffect(() => {
    loadNotes();
  }, [loadNotes]);

  const filteredNotes = getFilteredNotes();

  const handleDelete = async (id: string) => {
    await deleteNote(id);
    setConfirmDelete(null);
    setMenuOpen(null);
  };

  const handleTogglePin = async (id: string) => {
    await togglePinned(id);
    setMenuOpen(null);
  };

  const getPreview = (content: string): string => {
    const lines = content.split('\n').filter(l => l.trim());
    return lines.slice(0, 2).join(' ').substring(0, 100) || 'Nota vazia';
  };

  const getTitle = (note: NotepadNote): string => {
    if (note.title.trim()) return note.title;
    const firstLine = note.content.split('\n')[0]?.trim();
    return firstLine?.substring(0, 50) || 'Sem título';
  };

  return (
    <div className="min-h-screen bg-[#FFF5F8]">
      {/* Header */}
      <div className="bg-gradient-to-br from-pink-200 via-pink-100 to-rose-100 p-6 pb-8">
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() => setScreen({ name: 'home' })}
            className="w-10 h-10 rounded-full bg-white/50 flex items-center justify-center"
          >
            <span className="text-pink-600 text-xl">←</span>
          </button>
          <button
            onClick={() => setShowSearch(!showSearch)}
            className="w-10 h-10 rounded-full bg-white/50 flex items-center justify-center"
          >
            <span className="text-pink-600 text-xl">🔍</span>
          </button>
        </div>

        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-pink-400 to-rose-500 flex items-center justify-center shadow-lg">
            <span className="text-3xl">✏️</span>
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-800 font-['Poppins']">Bloco de Notas</h1>
            <p className="text-pink-600 font-medium">{notes.length} nota{notes.length !== 1 ? 's' : ''}</p>
          </div>
        </div>

        {/* Search bar */}
        {showSearch && (
          <div className="mt-4">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar em notas..."
              className="w-full px-4 py-3 rounded-xl bg-white border-2 border-pink-200 focus:border-pink-400 outline-none font-['Poppins']"
              autoFocus
            />
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-4 -mt-4">
        {/* Summary Card */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100 mb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-pink-100 flex items-center justify-center">
                <span className="text-2xl">📝</span>
              </div>
              <div>
                <h2 className="font-bold text-gray-800 font-['Poppins']">Suas Notas</h2>
                <p className="text-sm text-gray-500">{notes.length} nota{notes.length !== 1 ? 's' : ''} • Salvo automaticamente</p>
              </div>
            </div>
            <div className="w-10 h-10 rounded-full bg-pink-100 flex items-center justify-center">
              <span className="text-pink-600 font-bold">{notes.length}</span>
            </div>
          </div>
        </div>

        {/* Notes List */}
        {isLoading ? (
          <div className="text-center py-12 text-gray-500">Carregando...</div>
        ) : filteredNotes.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-20 h-20 bg-pink-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-4xl">📝</span>
            </div>
            <h3 className="text-lg font-bold text-gray-700 mb-2 font-['Poppins']">
              {searchQuery ? 'Nenhum resultado' : 'Nenhuma nota ainda'}
            </h3>
            <p className="text-gray-500 text-sm">
              {searchQuery ? 'Tente outro termo' : 'Crie sua primeira nota!'}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredNotes.map((note) => (
              <div
                key={note.id}
                className="relative"
              >
                <div
                  onClick={() => setScreen({ name: 'notepad-edit', noteId: note.id })}
                  className="bg-white rounded-2xl shadow-sm border border-pink-100 overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
                  style={{ backgroundColor: note.colorHex || '#FFFFFF' }}
                >
                  <div className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          {note.pinned && <span className="text-pink-500">📌</span>}
                          <h3 className="font-bold text-gray-800 font-['Poppins']">
                            {getTitle(note)}
                          </h3>
                        </div>
                        <p className="text-sm text-gray-600 line-clamp-2">
                          {getPreview(note.content)}
                        </p>
                        <p className="text-xs text-gray-400 mt-2">
                          {getRelativeTime(note.updatedAt)}
                        </p>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setMenuOpen(menuOpen === note.id ? null : note.id);
                        }}
                        className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center"
                      >
                        <span className="text-gray-400">⋮</span>
                      </button>
                    </div>
                  </div>

                  {/* Color indicator */}
                  {note.colorHex && note.colorHex !== '#FFFFFF' && (
                    <div 
                      className="h-1"
                      style={{ backgroundColor: note.colorHex === '#FCE4EC' ? '#E91E63' : note.colorHex === '#E3F2FD' ? '#2196F3' : note.colorHex === '#E8F5E9' ? '#4CAF50' : note.colorHex === '#FFF3E0' ? '#FF9800' : note.colorHex === '#F3E5F5' ? '#9C27B0' : note.colorHex === '#FFFDE7' ? '#FFC107' : '#E91E63' }}
                    />
                  )}
                </div>

                {/* Menu */}
                {menuOpen === note.id && (
                  <div className="absolute top-12 right-4 bg-white rounded-xl shadow-lg border border-gray-100 py-2 z-10">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleTogglePin(note.id);
                      }}
                      className="w-full px-4 py-2 text-left hover:bg-gray-50 flex items-center gap-2"
                    >
                      <span>{note.pinned ? '📌' : '📍'}</span>
                      <span>{note.pinned ? 'Desafixar' : 'Fixar'}</span>
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setConfirmDelete(note.id);
                        setMenuOpen(null);
                      }}
                      className="w-full px-4 py-2 text-left hover:bg-gray-50 flex items-center gap-2 text-red-500"
                    >
                      <span>🗑️</span>
                      <span>Excluir</span>
                    </button>
                  </div>
                )}

                {/* Delete confirmation */}
                {confirmDelete === note.id && (
                  <div className="absolute inset-0 bg-white/95 rounded-2xl flex items-center justify-center p-4">
                    <div className="text-center">
                      <p className="text-gray-700 mb-3 font-medium">Excluir esta nota?</p>
                      <div className="flex gap-2 justify-center">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setConfirmDelete(null);
                          }}
                          className="px-4 py-2 rounded-lg bg-gray-100 text-gray-600"
                        >
                          Cancelar
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDelete(note.id);
                          }}
                          className="px-4 py-2 rounded-lg bg-red-500 text-white"
                        >
                          Excluir
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* FAB */}
      <button
        onClick={() => setScreen({ name: 'notepad-edit' })}
        className="fixed bottom-6 right-6 bg-gradient-to-r from-pink-500 to-rose-500 text-white px-6 py-4 rounded-full shadow-lg flex items-center gap-2 hover:shadow-xl transition-shadow font-['Poppins'] font-semibold"
      >
        <span className="text-xl">+</span>
        <span>Nova Nota</span>
      </button>

      {/* Click outside to close menu */}
      {menuOpen && (
        <div 
          className="fixed inset-0 z-0" 
          onClick={() => setMenuOpen(null)}
        />
      )}
    </div>
  );
};

// ==================== EDIT SCREEN ====================

interface EditProps {
  setScreen: (screen: Screen) => void;
  noteId?: string;
}

export const NotepadEditScreen: React.FC<EditProps> = ({ setScreen, noteId }) => {
  const { notes, createNote, updateNote, loadNotes } = useNotepadStore();
  
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [colorHex, setColorHex] = useState('#FFFFFF');
  const [isSaving, setIsSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [noteIdState, setNoteIdState] = useState<string | null>(noteId || null);

  useEffect(() => {
    loadNotes();
  }, [loadNotes]);

  useEffect(() => {
    if (noteId) {
      const note = notes.find(n => n.id === noteId);
      if (note) {
        setTitle(note.title);
        setContent(note.content);
        setColorHex(note.colorHex || '#FFFFFF');
        setNoteIdState(note.id);
      }
    }
  }, [noteId, notes]);

  // Auto-save with debounce
  useEffect(() => {
    const timer = setTimeout(async () => {
      if (content.trim() || title.trim()) {
        setIsSaving(true);
        
        if (noteIdState) {
          await updateNote(noteIdState, { title, content, colorHex });
        } else {
          const newNote = await createNote({ title, content, colorHex, pinned: false });
          setNoteIdState(newNote.id);
        }
        
        setLastSaved(new Date());
        setIsSaving(false);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [title, content, colorHex, noteIdState, createNote, updateNote]);

  return (
    <div 
      className="min-h-screen flex flex-col"
      style={{ backgroundColor: colorHex || '#FFF5F8' }}
    >
      {/* Header */}
      <div className="bg-gradient-to-r from-pink-500 to-rose-500 p-4">
        <div className="flex items-center justify-between">
          <button
            onClick={() => setScreen({ name: 'notepad' })}
            className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center"
          >
            <span className="text-white text-xl">←</span>
          </button>
          
          <div className="flex items-center gap-2">
            {isSaving ? (
              <span className="text-white/80 text-sm">Salvando...</span>
            ) : lastSaved ? (
              <span className="text-white/80 text-sm">✓ Salvo</span>
            ) : null}
          </div>
        </div>
      </div>

      {/* Hero Card */}
      <div className="p-4 -mt-2">
        <div className="bg-gradient-to-br from-pink-400 to-rose-500 rounded-2xl p-4 shadow-lg">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-xl bg-white/20 flex items-center justify-center">
              <span className="text-3xl">✏️</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-white font-['Poppins']">
                {noteId ? 'Editar Nota' : 'Nova Nota'}
              </h1>
              <p className="text-white/80 text-sm">Salvo automaticamente</p>
            </div>
          </div>
        </div>
      </div>

      {/* Color Picker */}
      <div className="px-4 mb-4">
        <p className="text-sm font-medium text-gray-600 mb-2 font-['Poppins']">Cor da nota</p>
        <div className="flex gap-2">
          {NOTE_COLORS.map((color) => (
            <button
              key={color.hex}
              onClick={() => setColorHex(color.hex)}
              className={`w-10 h-10 rounded-xl border-2 transition-all ${
                colorHex === color.hex 
                  ? 'border-pink-500 scale-110' 
                  : 'border-gray-200'
              }`}
              style={{ backgroundColor: color.hex }}
            >
              {colorHex === color.hex && (
                <span className="text-pink-500 text-sm">✓</span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Title */}
      <div className="px-4 mb-4">
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Título (opcional)"
          className="w-full text-xl font-bold text-gray-800 bg-transparent outline-none placeholder-gray-400 font-['Poppins']"
        />
      </div>

      {/* Content */}
      <div className="flex-1 px-4 pb-20">
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Escreva sua nota aqui..."
          className="w-full h-full min-h-[300px] text-gray-700 bg-transparent outline-none resize-none placeholder-gray-400 font-['Poppins'] leading-relaxed"
        />
      </div>
    </div>
  );
};
