import { useState, useEffect } from 'react';
import { 
  ArrowLeft, Check, FileText, Link as LinkIcon, CheckSquare, Plus, 
  Trash2, ExternalLink, GripVertical
} from 'lucide-react';
import { Screen } from '../types/screens';
import { useFolderStore, FolderItemType, ChecklistItem } from '../store/useFolderStore';

interface FolderItemEditScreenProps {
  onNavigate: (screen: Screen) => void;
  folderId: string;
  itemId?: string;
  itemType?: FolderItemType;
}

export default function FolderItemEditScreen({ 
  onNavigate, 
  folderId, 
  itemId,
  itemType: initialType
}: FolderItemEditScreenProps) {
  const { getItemById, getFolderById, createItem, updateItem } = useFolderStore();
  
  const existingItem = itemId ? getItemById(itemId) : null;
  const folder = getFolderById(folderId);
  
  const [title, setTitle] = useState(existingItem?.title || '');
  const [type, setType] = useState<FolderItemType>(existingItem?.type || initialType || 'NOTE');
  const [content, setContent] = useState(existingItem?.content || '');
  const [checklistItems, setChecklistItems] = useState<ChecklistItem[]>(
    existingItem?.checklistItems || []
  );
  const [newCheckItem, setNewCheckItem] = useState('');
  
  const isEditing = !!existingItem;
  
  useEffect(() => {
    if (existingItem) {
      setTitle(existingItem.title);
      setType(existingItem.type);
      setContent(existingItem.content || '');
      setChecklistItems(existingItem.checklistItems || []);
    }
  }, [existingItem]);
  
  const handleSave = async () => {
    if (!title.trim()) {
      alert('Digite um título');
      return;
    }
    
    if (type === 'LINK' && content && !content.match(/^https?:\/\//)) {
      alert('URL deve começar com http:// ou https://');
      return;
    }
    
    const itemData = {
      folderId,
      type,
      title,
      content: type !== 'CHECKLIST' ? content : undefined,
      checklistItems: type === 'CHECKLIST' ? checklistItems : undefined,
    };
    
    if (isEditing && itemId) {
      await updateItem(itemId, itemData);
    } else {
      await createItem(itemData);
    }
    
    onNavigate({ name: 'folder-detail', folderId });
  };
  
  const addChecklistItem = () => {
    if (!newCheckItem.trim()) return;
    setChecklistItems([...checklistItems, { text: newCheckItem.trim(), done: false }]);
    setNewCheckItem('');
  };
  
  const removeChecklistItem = (index: number) => {
    setChecklistItems(checklistItems.filter((_, i) => i !== index));
  };
  
  const toggleChecklistItem = (index: number) => {
    const updated = [...checklistItems];
    updated[index] = { ...updated[index], done: !updated[index].done };
    setChecklistItems(updated);
  };
  
  const getTypeInfo = () => {
    switch (type) {
      case 'NOTE':
        return { icon: FileText, label: 'Nota', color: '#E91E63', bg: 'bg-pink-50' };
      case 'LINK':
        return { icon: LinkIcon, label: 'Link', color: '#2196F3', bg: 'bg-blue-50' };
      case 'CHECKLIST':
        return { icon: CheckSquare, label: 'Checklist', color: '#4CAF50', bg: 'bg-green-50' };
    }
  };
  
  const typeInfo = getTypeInfo();
  const TypeIcon = typeInfo.icon;
  
  return (
    <div className="min-h-screen bg-[#FFF5F8]">
      {/* Header */}
      <div 
        className="pt-12 pb-6 px-4"
        style={{ 
          background: `linear-gradient(135deg, ${folder?.colorHex || '#E91E63'}90, ${folder?.colorHex || '#E91E63'})` 
        }}
      >
        <div className="flex items-center justify-between">
          <button 
            onClick={() => onNavigate({ name: 'folder-detail', folderId })}
            className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <h1 className="text-xl font-bold text-white font-['Poppins']">
            {isEditing ? 'Editar Item' : `Nova ${typeInfo.label}`}
          </h1>
          <button 
            onClick={handleSave}
            className="bg-white text-pink-500 px-4 py-2 rounded-full font-semibold flex items-center gap-1"
          >
            <Check className="w-4 h-4" />
            Salvar
          </button>
        </div>
      </div>
      
      <div className="px-4 py-6 space-y-4">
        {/* Tipo (apenas se for novo) */}
        {!isEditing && (
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
            <label className="text-lg font-bold text-gray-800 font-['Poppins'] mb-3 block">
              Tipo
            </label>
            <div className="flex gap-2">
              {(['NOTE', 'LINK', 'CHECKLIST'] as FolderItemType[]).map((t) => {
                const info = t === 'NOTE' 
                  ? { icon: FileText, label: '📝 Nota', color: '#E91E63' }
                  : t === 'LINK'
                  ? { icon: LinkIcon, label: '🔗 Link', color: '#2196F3' }
                  : { icon: CheckSquare, label: '☑️ Check', color: '#4CAF50' };
                  
                return (
                  <button
                    key={t}
                    onClick={() => setType(t)}
                    className={`flex-1 py-3 rounded-xl font-semibold transition-all ${
                      type === t
                        ? 'text-white'
                        : 'bg-gray-50 text-gray-600'
                    }`}
                    style={{ backgroundColor: type === t ? info.color : undefined }}
                  >
                    {info.label}
                  </button>
                );
              })}
            </div>
          </div>
        )}
        
        {/* Info do tipo */}
        <div className={`${typeInfo.bg} rounded-2xl p-4 flex items-center gap-3`}>
          <div 
            className="w-12 h-12 rounded-xl flex items-center justify-center"
            style={{ backgroundColor: `${typeInfo.color}30` }}
          >
            <TypeIcon className="w-6 h-6" style={{ color: typeInfo.color }} />
          </div>
          <div>
            <h3 className="font-bold text-gray-800">{typeInfo.label}</h3>
            <p className="text-sm text-gray-500">
              {type === 'NOTE' && 'Escreva suas ideias e pensamentos'}
              {type === 'LINK' && 'Salve URLs importantes'}
              {type === 'CHECKLIST' && 'Crie uma lista de tarefas'}
            </p>
          </div>
        </div>
        
        {/* Título */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
          <label className="text-lg font-bold text-gray-800 font-['Poppins'] mb-3 block">
            Título *
          </label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Ex: Minha anotação..."
            className="w-full px-4 py-3 rounded-xl border border-pink-200 focus:border-pink-400 focus:outline-none"
          />
        </div>
        
        {/* Conteúdo específico por tipo */}
        {type === 'NOTE' && (
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
            <label className="text-lg font-bold text-gray-800 font-['Poppins'] mb-3 block">
              Conteúdo
            </label>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Escreva aqui..."
              rows={8}
              className="w-full px-4 py-3 rounded-xl border border-pink-200 focus:border-pink-400 focus:outline-none resize-none"
            />
          </div>
        )}
        
        {type === 'LINK' && (
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
            <label className="text-lg font-bold text-gray-800 font-['Poppins'] mb-3 block">
              URL
            </label>
            <div className="flex gap-2">
              <input
                type="url"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="https://exemplo.com"
                className="flex-1 px-4 py-3 rounded-xl border border-pink-200 focus:border-pink-400 focus:outline-none"
              />
              {content && content.match(/^https?:\/\//) && (
                <a
                  href={content}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center text-white"
                >
                  <ExternalLink className="w-5 h-5" />
                </a>
              )}
            </div>
          </div>
        )}
        
        {type === 'CHECKLIST' && (
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
            <label className="text-lg font-bold text-gray-800 font-['Poppins'] mb-3 block">
              Itens da Lista
            </label>
            
            {/* Adicionar novo item */}
            <div className="flex gap-2 mb-4">
              <input
                type="text"
                value={newCheckItem}
                onChange={(e) => setNewCheckItem(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && addChecklistItem()}
                placeholder="Novo item..."
                className="flex-1 px-4 py-3 rounded-xl border border-pink-200 focus:border-pink-400 focus:outline-none"
              />
              <button
                onClick={addChecklistItem}
                className="w-12 h-12 bg-pink-500 rounded-xl flex items-center justify-center text-white"
              >
                <Plus className="w-5 h-5" />
              </button>
            </div>
            
            {/* Lista de itens */}
            {checklistItems.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                <CheckSquare className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>Adicione itens à sua lista</p>
              </div>
            ) : (
              <div className="space-y-2">
                {checklistItems.map((item, index) => (
                  <div
                    key={index}
                    className={`flex items-center gap-3 p-3 rounded-xl border ${
                      item.done ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'
                    }`}
                  >
                    <GripVertical className="w-4 h-4 text-gray-300" />
                    
                    <button
                      onClick={() => toggleChecklistItem(index)}
                      className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center flex-shrink-0 ${
                        item.done 
                          ? 'bg-green-500 border-green-500' 
                          : 'border-gray-300'
                      }`}
                    >
                      {item.done && <Check className="w-4 h-4 text-white" />}
                    </button>
                    
                    <span className={`flex-1 ${item.done ? 'line-through text-gray-400' : 'text-gray-700'}`}>
                      {item.text}
                    </span>
                    
                    <button
                      onClick={() => removeChecklistItem(index)}
                      className="w-8 h-8 flex items-center justify-center text-red-400 hover:bg-red-50 rounded-lg"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
            
            {/* Progresso */}
            {checklistItems.length > 0 && (
              <div className="mt-4 pt-4 border-t border-gray-100">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-500">Progresso</span>
                  <span className="text-sm font-bold text-green-600">
                    {checklistItems.filter(i => i.done).length}/{checklistItems.length}
                  </span>
                </div>
                <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-green-500 rounded-full transition-all"
                    style={{ 
                      width: `${(checklistItems.filter(i => i.done).length / checklistItems.length) * 100}%` 
                    }}
                  />
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
