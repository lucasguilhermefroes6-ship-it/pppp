import { useState } from 'react';
import { ArrowLeft, Plus, List, Kanban, Calendar } from 'lucide-react';
import { format, parseISO, startOfMonth, endOfMonth, eachDayOfInterval, getDay, addMonths, subMonths } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useStore } from '@/store/useStore';
import { Screen } from '@/types/screens';
import { SegmentedTabs } from '@/components/ui/SegmentedTabs';
import { FilterChips } from '@/components/ui/FilterChips';
import { TaskCard } from '@/components/ui/TaskCard';
import { PrimaryButton } from '@/components/ui/PrimaryButton';
import { AppCard } from '@/components/ui/AppCard';
import { ViewMode, OccurrenceStatus } from '@/types';
import { cn } from '@/utils/cn';

interface TasksScreenProps {
  onNavigate: (screen: Screen) => void;
}

const viewTabs = [
  { id: 'list', label: 'Lista', icon: <List className="w-4 h-4" /> },
  { id: 'kanban', label: 'Kanban', icon: <Kanban className="w-4 h-4" /> },
  { id: 'calendar', label: 'Calendário', icon: <Calendar className="w-4 h-4" /> },
];

export function TasksScreen({ onNavigate }: TasksScreenProps) {
  const {
    viewMode,
    setViewMode,
    activeFilter,
    setActiveFilter,
    selectedDate,
    setSelectedDate,
    getTasksForDisplay,
    toggleTaskDone,
  } = useStore();

  const [calendarMonth, setCalendarMonth] = useState(new Date());
  const tasks = getTasksForDisplay();

  const handleToggle = async (taskId: string) => {
    const task = tasks.find(t => t.id === taskId);
    if (task) {
      // Para tarefas recorrentes, usar a data de HOJE
      // Para não recorrentes, usar a dueDate ou 'no-date'
      const today = format(new Date(), 'yyyy-MM-dd');
      const date = task.recurrenceEnabled ? today : (task.dueDate || 'no-date');
      await toggleTaskDone(task, date);
    }
  };

  return (
    <div className="min-h-screen bg-[#FFF5F8]">
      {/* Header */}
      <header className="bg-gradient-to-br from-pink-400 to-pink-500 text-white px-4 pt-10 pb-6 shadow-[0_4px_16px_rgba(236,72,153,0.3)]">
        <div className="max-w-lg mx-auto">
          <div className="flex items-center gap-3 mb-4">
            <button
              onClick={() => onNavigate({ name: 'home' })}
              className="p-2 -ml-2 rounded-lg hover:bg-white/10 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-xl font-bold font-poppins">Tarefas</h1>
          </div>
          
          <SegmentedTabs
            tabs={viewTabs}
            activeTab={viewMode}
            onChange={(id) => setViewMode(id as ViewMode)}
            className="bg-white/20"
          />
        </div>
      </header>

      {/* Filters */}
      <div className="px-4 py-4 max-w-lg mx-auto">
        <FilterChips activeFilter={activeFilter} onChange={setActiveFilter} />
      </div>

      {/* Content based on view mode */}
      <main className="px-4 pb-24 max-w-lg mx-auto">
        {viewMode === 'list' && (
          <ListView
            tasks={tasks}
            onToggle={handleToggle}
            onTaskClick={(id) => onNavigate({ name: 'task-form', taskId: id })}
          />
        )}
        
        {viewMode === 'kanban' && (
          <KanbanView
            tasks={tasks}
            onTaskClick={(id) => onNavigate({ name: 'task-form', taskId: id })}
          />
        )}
        
        {viewMode === 'calendar' && (
          <CalendarView
            tasks={tasks}
            selectedDate={selectedDate}
            onSelectDate={setSelectedDate}
            calendarMonth={calendarMonth}
            onChangeMonth={setCalendarMonth}
            onToggle={handleToggle}
            onTaskClick={(id) => onNavigate({ name: 'task-form', taskId: id })}
          />
        )}
      </main>

      {/* FAB */}
      <div className="fixed bottom-6 right-6 left-6 flex justify-center">
        <PrimaryButton
          icon={<Plus className="w-5 h-5" />}
          size="lg"
          onClick={() => onNavigate({ name: 'task-form' })}
        >
          Nova Tarefa
        </PrimaryButton>
      </div>
    </div>
  );
}

// ListView Component
interface ListViewProps {
  tasks: ReturnType<typeof useStore.getState>['tasks'] extends (infer U)[] ? U[] : never;
  onToggle: (taskId: string) => void;
  onTaskClick: (taskId: string) => void;
}

function ListView({ tasks, onToggle, onTaskClick }: ListViewProps) {
  if (tasks.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="w-20 h-20 bg-gradient-to-br from-pink-100 to-pink-200 rounded-full flex items-center justify-center mx-auto mb-4 shadow-[0_6px_16px_rgba(236,72,153,0.2)]">
          <List className="w-10 h-10 text-pink-500" />
        </div>
        <p className="text-pink-600 font-semibold font-poppins">Nenhuma tarefa encontrada</p>
        <p className="text-sm text-pink-400 mt-1">Crie sua primeira tarefa!</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {(tasks as any[]).map((task) => (
        <TaskCard
          key={task.id}
          task={task}
          onToggle={() => onToggle(task.id)}
          onClick={() => onTaskClick(task.id)}
        />
      ))}
    </div>
  );
}

// KanbanView Component
function KanbanView({ tasks, onTaskClick }: Omit<ListViewProps, 'onToggle'>) {
  const pendingTasks = (tasks as any[]).filter(t => t.occurrence?.status !== OccurrenceStatus.DONE);
  const completedTasks = (tasks as any[]).filter(t => t.occurrence?.status === OccurrenceStatus.DONE);

  return (
    <div className="grid grid-cols-2 gap-4">
      {/* Pending Column */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <div className="w-3 h-3 rounded-full bg-pink-400" />
          <h3 className="font-semibold font-poppins text-pink-600">Pendentes</h3>
          <span className="text-sm text-pink-400">({pendingTasks.length})</span>
        </div>
        <div className="space-y-2">
          {pendingTasks.map((task) => (
            <AppCard key={task.id} className="p-3" hoverable onClick={() => onTaskClick(task.id)}>
              <p className="text-sm font-medium text-pink-700 line-clamp-2">{task.title}</p>
              {task.dueTime && (
                <p className="text-xs text-pink-400 mt-1">{task.dueTime}</p>
              )}
            </AppCard>
          ))}
        </div>
      </div>

      {/* Completed Column */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <div className="w-3 h-3 rounded-full bg-pink-300" />
          <h3 className="font-semibold font-poppins text-pink-500">Concluídas</h3>
          <span className="text-sm text-pink-300">({completedTasks.length})</span>
        </div>
        <div className="space-y-2">
          {completedTasks.map((task) => (
            <AppCard key={task.id} className="p-3 opacity-60" hoverable onClick={() => onTaskClick(task.id)}>
              <p className="text-sm font-medium text-pink-400 line-through line-clamp-2">{task.title}</p>
            </AppCard>
          ))}
        </div>
      </div>
    </div>
  );
}

// CalendarView Component
interface CalendarViewProps {
  tasks: ReturnType<typeof useStore.getState>['tasks'] extends (infer U)[] ? U[] : never;
  onToggle: (taskId: string) => void;
  onTaskClick: (taskId: string) => void;
  selectedDate: string;
  onSelectDate: (date: string) => void;
  calendarMonth: Date;
  onChangeMonth: (date: Date) => void;
}

function CalendarView({
  tasks,
  selectedDate,
  onSelectDate,
  calendarMonth,
  onChangeMonth,
  onToggle,
  onTaskClick,
}: CalendarViewProps) {
  const monthStart = startOfMonth(calendarMonth);
  const monthEnd = endOfMonth(calendarMonth);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });
  const startDayOfWeek = getDay(monthStart);

  const weekDays = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

  return (
    <div>
      {/* Calendar */}
      <AppCard className="mb-4">
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() => onChangeMonth(subMonths(calendarMonth, 1))}
            className="p-2 hover:bg-pink-50 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-pink-500" />
          </button>
          <h3 className="font-semibold font-poppins text-pink-600 capitalize">
            {format(calendarMonth, 'MMMM yyyy', { locale: ptBR })}
          </h3>
          <button
            onClick={() => onChangeMonth(addMonths(calendarMonth, 1))}
            className="p-2 hover:bg-pink-50 rounded-lg transition-colors rotate-180"
          >
            <ArrowLeft className="w-5 h-5 text-pink-500" />
          </button>
        </div>

        <div className="grid grid-cols-7 gap-1 mb-2">
          {weekDays.map((day) => (
            <div key={day} className="text-center text-xs font-medium text-pink-400 py-2">
              {day}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-1">
          {/* Empty cells for days before month start */}
          {Array.from({ length: startDayOfWeek }).map((_, i) => (
            <div key={`empty-${i}`} className="h-10" />
          ))}
          
          {days.map((day) => {
            const dateStr = format(day, 'yyyy-MM-dd');
            const isSelected = dateStr === selectedDate;
            const isToday = dateStr === format(new Date(), 'yyyy-MM-dd');
            
            return (
              <button
                key={dateStr}
                onClick={() => onSelectDate(dateStr)}
                className={cn(
                  'h-10 rounded-lg text-sm font-medium transition-all',
                  isSelected
                    ? 'bg-gradient-to-r from-pink-400 to-pink-500 text-white shadow-[0_4px_12px_rgba(236,72,153,0.35)]'
                    : isToday
                      ? 'bg-pink-100 text-pink-600'
                      : 'text-pink-600 hover:bg-pink-50'
                )}
              >
                {format(day, 'd')}
              </button>
            );
          })}
        </div>
      </AppCard>

      {/* Tasks for selected date */}
      <div className="mb-2">
        <h3 className="font-semibold font-poppins text-pink-600">
          {format(parseISO(selectedDate), "d 'de' MMMM", { locale: ptBR })}
        </h3>
      </div>
      
      <ListView tasks={tasks} onToggle={onToggle} onTaskClick={onTaskClick} />
    </div>
  );
}
