import { useState, useEffect, useMemo } from 'react';
import {
  CheckSquare,
  Target,
  Timer,
  FileText,
  Droplets,
  Moon,
  Dumbbell,
  Heart,
  DollarSign,
  BarChart3,
  Folder,
  Scale,
  Sparkles,
  TrendingUp,
  LineChart,
  Lock,
  Edit3,
  Archive,
  Zap,
  Briefcase,
} from 'lucide-react';
import { useStore } from '@/store/useStore';
import { useGoalStore } from '@/store/useGoalStore';
import { useWaterStore } from '@/store/useWaterStore';
import { useSleepStore } from '@/store/useSleepStore';
import { useFinanceStore } from '@/store/useFinanceStore';
import { useFemininityStore } from '@/store/useFemininityStore';
import { useWorkoutStore } from '@/store/useWorkoutStore';
import { useMoodStore } from '@/store/useMoodStore';
import { useNotesStore } from '@/store/useNotesStore';
import { useFolderStore } from '@/store/useFolderStore';
import { useMeasurementsStore } from '@/store/useMeasurementsStore';
import { useNotepadStore } from '@/store/useNotepadStore';
import { useSecretDiaryStore } from '@/store/useSecretDiaryStore';
import { useThemeStore } from '@/store/useThemeStore';
import { useMyRecordsStore } from '@/store/useMyRecordsStore';
import { Screen } from '@/types/screens';
import { DashboardHeader } from '@/components/dashboard/DashboardHeader';
import { AssistantCard } from '@/components/dashboard/AssistantCard';
import { DashboardRangeToggle, DashboardRange } from '@/components/dashboard/DashboardRangeToggle';
import { SectionTitle } from '@/components/dashboard/SectionTitle';
import { ModuleCard } from '@/components/dashboard/ModuleCard';
import { SideDrawer } from '@/components/dashboard/SideDrawer';
import { DatePickerModal } from '@/components/dashboard/DatePickerModal';

// Helper functions
const getToday = () => new Date().toISOString().split('T')[0];

const getStartOfWeek = (date: Date): Date => {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1); // Monday
  d.setDate(diff);
  d.setHours(0, 0, 0, 0);
  return d;
};

const getEndOfWeek = (weekStart: Date): Date => {
  const end = new Date(weekStart);
  end.setDate(weekStart.getDate() + 6);
  return end;
};

const formatDateKey = (date: Date): string => {
  return date.toISOString().split('T')[0];
};

const getDaysOfWeek = (weekStart: Date): string[] => {
  const days: string[] = [];
  for (let i = 0; i < 7; i++) {
    const day = new Date(weekStart);
    day.setDate(weekStart.getDate() + i);
    days.push(formatDateKey(day));
  }
  return days;
};

interface HomeScreenProps {
  onNavigate: (screen: Screen) => void;
}

export function HomeScreen({ onNavigate }: HomeScreenProps) {
  const { pendingCount, occurrences } = useStore();
  const { goals, initialize: initGoals, getActiveGoalsCount } = useGoalStore();
  const { getTodayTotal, initialize: initWater, addWater, getTotalForDate } = useWaterStore();
  const { getLastNightSleep, formatDuration, initialize: initSleep, entries: sleepEntries } = useSleepStore();
  const { transactions, initialize: initFinance } = useFinanceStore();
  const { getProgressLabel, logs: femininityLogs, initialize: initFemininity } = useFemininityStore();
  const { getTodayLabel: getWorkoutLabel, workouts, initialize: initWorkout } = useWorkoutStore();
  const { getTodayMoodLabel, initialize: initMood } = useMoodStore();
  const { countNotes, initialize: initNotes } = useNotesStore();
  const { countFolders, countPinnedItems, loadFolders } = useFolderStore();
  const { loadEntries: loadMeasurements, getHomeLabel: getMeasurementsLabel } = useMeasurementsStore();
  const { countNotes: countNotepadNotes, loadNotes: loadNotepad } = useNotepadStore();
  const { countEntries: countDiaryEntries, loadSettings: loadDiarySettings, settings: diarySettings } = useSecretDiaryStore();
  const { mode: themeMode, toggleTheme, initialize: initTheme } = useThemeStore();
  const { getTodayLabel: getMyRecordsLabel, initDB: initMyRecords } = useMyRecordsStore();
  
  const [range, setRange] = useState<DashboardRange>('today');
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isDatePickerOpen, setIsDatePickerOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date());

  const isDarkMode = themeMode === 'dark';

  useEffect(() => {
    initGoals();
    initWater();
    initSleep();
    initFinance();
    initFemininity();
    initWorkout();
    initMood();
    initNotes();
    loadFolders();
    loadMeasurements();
    loadNotepad();
    loadDiarySettings();
    initTheme();
    initMyRecords();
  }, [initGoals, initWater, initSleep, initFinance, initFemininity, initWorkout, initMood, initNotes, loadMeasurements, loadNotepad, loadDiarySettings, initTheme, initMyRecords]);

  // Calculate week data
  const weekData = useMemo(() => {
    const weekStart = getStartOfWeek(new Date());
    const weekEnd = getEndOfWeek(weekStart);
    const daysOfWeek = getDaysOfWeek(weekStart);
    
    // Water: sum of week
    const weekWaterTotal = daysOfWeek.reduce((sum, day) => {
      return sum + getTotalForDate(day);
    }, 0);
    
    // Sleep: average of week
    const weekSleepEntries = sleepEntries.filter(e => {
      return e.date >= formatDateKey(weekStart) && e.date <= formatDateKey(weekEnd);
    });
    const weekSleepTotal = weekSleepEntries.reduce((sum, e) => sum + e.durationMinutes, 0);
    const weekSleepAvg = weekSleepEntries.length > 0 ? Math.round(weekSleepTotal / weekSleepEntries.length) : 0;
    
    // Workout: count of days
    const weekWorkouts = workouts.filter(w => {
      return w.dateKey >= formatDateKey(weekStart) && w.dateKey <= formatDateKey(weekEnd) && w.intensity !== 'NONE';
    });
    
    // Expenses: sum of week
    const weekExpenses = transactions
      .filter(t => t.type === 'EXPENSE' && t.date >= formatDateKey(weekStart) && t.date <= formatDateKey(weekEnd))
      .reduce((sum, t) => sum + t.amountCents, 0);
    
    // Tasks: completed this week
    const weekTasksCompleted = Array.from(occurrences.values()).filter(occ => {
      return occ.occurrenceDate >= formatDateKey(weekStart) && 
             occ.occurrenceDate <= formatDateKey(weekEnd) && 
             occ.status === 'DONE';
    }).length;
    
    // Femininity: average of week
    const weekFemLogs = Object.values(femininityLogs).filter(log => {
      return log.dateKey >= formatDateKey(weekStart) && log.dateKey <= formatDateKey(weekEnd);
    });
    const weekFemTotal = weekFemLogs.reduce((sum, log) => {
      const answered = Object.values(log.answers).filter(Boolean).length;
      return sum + answered;
    }, 0);
    const weekFemAvg = weekFemLogs.length > 0 ? Math.round((weekFemTotal / weekFemLogs.length / 20) * 100) : 0;
    
    return {
      waterTotal: weekWaterTotal,
      sleepAvg: weekSleepAvg,
      workoutDays: weekWorkouts.length,
      expenses: weekExpenses,
      tasksCompleted: weekTasksCompleted,
      femininityAvg: weekFemAvg
    };
  }, [sleepEntries, workouts, transactions, occurrences, femininityLogs, getTotalForDate]);

  // Get today data
  const todayData = useMemo(() => {
    const today = getToday();
    
    // Water today
    const waterTotal = getTodayTotal();
    
    // Sleep last night
    const lastSleep = getLastNightSleep();
    const sleepDuration = lastSleep ? lastSleep.durationMinutes : 0;
    
    // Expenses today
    const todayExpenses = transactions
      .filter(t => t.type === 'EXPENSE' && t.date === today)
      .reduce((sum, t) => sum + t.amountCents, 0);
    
    // Tasks completed today
    const todayTasksCompleted = Array.from(occurrences.values()).filter(occ => {
      return occ.occurrenceDate === today && occ.status === 'DONE';
    }).length;
    
    return {
      waterTotal,
      sleepDuration,
      expenses: todayExpenses,
      tasksCompleted: todayTasksCompleted
    };
  }, [getTodayTotal, getLastNightSleep, transactions, occurrences]);

  // Format helpers
  const formatCurrency = (cents: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(cents / 100);
  };

  const formatSleepDuration = (minutes: number) => {
    if (minutes === 0) return '—';
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h${mins.toString().padStart(2, '0')}`;
  };

  // Dynamic subtitles based on range
  const getWaterSubtitle = () => {
    if (range === 'today') {
      return `${todayData.waterTotal} ml`;
    }
    const liters = (weekData.waterTotal / 1000).toFixed(1);
    return `${liters}L semana`;
  };

  const getSleepSubtitle = () => {
    if (range === 'today') {
      const lastSleep = getLastNightSleep();
      return lastSleep ? formatDuration(lastSleep.durationMinutes) : '—';
    }
    return `${formatSleepDuration(weekData.sleepAvg)} média`;
  };

  const getWorkoutSubtitle = () => {
    if (range === 'today') {
      return getWorkoutLabel();
    }
    return `${weekData.workoutDays} treinos`;
  };

  const getExpensesSubtitle = () => {
    if (range === 'today') {
      return `${formatCurrency(todayData.expenses)} hoje`;
    }
    return `${formatCurrency(weekData.expenses)} semana`;
  };

  const getTasksSubtitle = () => {
    if (range === 'today') {
      return `${pendingCount} pendentes`;
    }
    return `${weekData.tasksCompleted} concluídas`;
  };

  const getFemininitySubtitle = () => {
    if (range === 'today') {
      return getProgressLabel();
    }
    return `${weekData.femininityAvg}% média`;
  };

  // Handle date selection
  const handleDateSelect = (date: Date) => {
    setSelectedDate(date);
    console.log('Date selected:', date);
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      isDarkMode ? 'bg-[#1a1a2e]' : 'bg-[#FFF8FC]'
    }`}>
      {/* Side Drawer */}
      <SideDrawer 
        isOpen={isDrawerOpen}
        isDarkMode={isDarkMode}
        onClose={() => setIsDrawerOpen(false)}
        onNavigate={onNavigate}
      />

      {/* Date Picker Modal */}
      <DatePickerModal
        isOpen={isDatePickerOpen}
        selectedDate={selectedDate}
        isDarkMode={isDarkMode}
        onClose={() => setIsDatePickerOpen(false)}
        onSelectDate={handleDateSelect}
      />

      {/* Header */}
      <DashboardHeader 
        selectedDate={selectedDate}
        isDarkMode={isDarkMode}
        onMenuClick={() => setIsDrawerOpen(true)}
        onCalendarClick={() => setIsDatePickerOpen(true)}
        onThemeToggle={toggleTheme}
      />

      {/* Content */}
      <main className="px-4 pb-8 max-w-lg mx-auto space-y-6">
        {/* Assistant Card */}
        <AssistantCard isDarkMode={isDarkMode} />

        {/* Range Toggle */}
        <div className="flex justify-center">
          <DashboardRangeToggle value={range} onChange={setRange} isDarkMode={isDarkMode} />
        </div>

        {/* Range Info Badge */}
        {range === 'week' && (
          <div className="flex justify-center">
            <span className={`text-xs px-3 py-1 rounded-full ${
              isDarkMode ? 'bg-pink-900/30 text-pink-300' : 'bg-[#FFD6EA] text-[#D8247C]'
            }`}>
              📊 Mostrando dados da semana atual (Seg-Dom)
            </span>
          </div>
        )}

        {/* Produtividade Section */}
        <section>
          <SectionTitle title="Produtividade" icon={Zap} isDarkMode={isDarkMode} />
          <div className="grid grid-cols-2 gap-3">
            <ModuleCard
              icon={CheckSquare}
              title="Tarefas"
              subtitle={getTasksSubtitle()}
              onClick={() => onNavigate({ name: 'tasks' })}
              isDarkMode={isDarkMode}
            />
            <ModuleCard
              icon={Target}
              title="Metas"
              subtitle={`${getActiveGoalsCount()} ${goals.length === 1 ? 'objetivo' : 'objetivos'}`}
              onClick={() => onNavigate({ name: 'goals' })}
              isDarkMode={isDarkMode}
            />
            <ModuleCard
              icon={Timer}
              title="Pomodoro"
              subtitle="Foco e produtividade"
              onClick={() => onNavigate({ name: 'pomodoro' })  }
              isDarkMode={isDarkMode}
            />
            <ModuleCard
              icon={FileText}
              title="Anotações"
              subtitle={`${countNotes()} notas`}
              onClick={() => onNavigate({ name: 'notes' })}
              isDarkMode={isDarkMode}
            />
          </div>
        </section>

        {/* Saúde & Bem-estar Section */}
        <section>
          <SectionTitle title="Saúde & Bem-estar" icon={Heart} isDarkMode={isDarkMode} />
          <div className="grid grid-cols-2 gap-3">
            <ModuleCard
              icon={Droplets}
              title="Água"
              subtitle={getWaterSubtitle()}
              onClick={() => onNavigate({ name: 'water' })}
              showAddButton={range === 'today'}
              onAddClick={() => addWater(250)}
              isDarkMode={isDarkMode}
            />
            <ModuleCard
              icon={Moon}
              title="Sono"
              subtitle={getSleepSubtitle()}
              onClick={() => onNavigate({ name: 'sleep' })}
              isDarkMode={isDarkMode}
            />
            <ModuleCard
              icon={Dumbbell}
              title="Treino"
              subtitle={getWorkoutSubtitle()}
              onClick={() => onNavigate({ name: 'workout' })}
              isDarkMode={isDarkMode}
            />
            <ModuleCard
              icon={Heart}
              title="Humor"
              subtitle={getTodayMoodLabel()}
              onClick={() => onNavigate({ name: 'mood' })}
              isDarkMode={isDarkMode}
            />
            <ModuleCard
              icon={Moon}
              title="Resumo do Sono"
              subtitle="Análise semanal"
              onClick={() => onNavigate({ name: 'sleep-weekly-summary' })}
              isDarkMode={isDarkMode}
            />
          </div>
        </section>

        {/* Finanças Section */}
        <section>
          <SectionTitle title="Finanças" icon={DollarSign} isDarkMode={isDarkMode} />
          <div className="grid grid-cols-2 gap-3">
            <ModuleCard
              icon={DollarSign}
              title="Gastos"
              subtitle={getExpensesSubtitle()}
              onClick={() => onNavigate({ name: 'expenses' })}
              isDarkMode={isDarkMode}
            />
            <ModuleCard
              icon={BarChart3}
              title="Estatísticas"
              subtitle="Análises financeiras"
              onClick={() => onNavigate({ name: 'stats' })}
              isDarkMode={isDarkMode}
            />
          </div>
        </section>

        {/* Organização Section */}
        <section>
          <SectionTitle title="Organização" icon={Briefcase} isDarkMode={isDarkMode} />
          <div className="grid grid-cols-2 gap-3">
            <ModuleCard
              icon={Folder}
              title="Pastas"
              subtitle={`${countFolders()} coleções • ${countPinnedItems()} favoritos`}
              onClick={() => onNavigate({ name: 'folders' })}
              isDarkMode={isDarkMode}
            />
            <ModuleCard
              icon={Scale}
              title="Medidas"
              subtitle={getMeasurementsLabel()}
              onClick={() => onNavigate({ name: 'measurements' })}
              isDarkMode={isDarkMode}
            />
            <ModuleCard
              icon={Sparkles}
              title="Feminilidade"
              subtitle={getFemininitySubtitle()}
              onClick={() => onNavigate({ name: 'femininity' })}
              isDarkMode={isDarkMode}
            />
            <ModuleCard
              icon={TrendingUp}
              title="Resumo Saúde"
              subtitle="Evolução semanal"
              onClick={() => onNavigate({ name: 'health-summary' })}
              isDarkMode={isDarkMode}
            />
            <ModuleCard
              icon={LineChart}
              title="Resumo Bem-Estar"
              subtitle="Desenvolvimento pessoal"
              onClick={() => onNavigate({ name: 'wellbeing-summary' })}
              isDarkMode={isDarkMode}
            />
            <ModuleCard
              icon={Lock}
              title="Diário Secreto"
              subtitle={diarySettings.hasPin ? `🔒 ${countDiaryEntries()} registros` : '🔒 Com senha'}
              onClick={() => onNavigate({ name: 'secret-diary' })}
              isDarkMode={isDarkMode}
            />
            <ModuleCard
              icon={Edit3}
              title="Bloco de Notas"
              subtitle={`${countNotepadNotes()} notas`}
              onClick={() => onNavigate({ name: 'notepad' })}
              isDarkMode={isDarkMode}
            />
            <ModuleCard
              icon={Archive}
              title="Meus Registros"
              subtitle={getMyRecordsLabel() || 'Calorias & Jejum'}
              onClick={() => onNavigate({ name: 'my-records' })}
              isDarkMode={isDarkMode}
            />
          </div>
        </section>
      </main>
    </div>
  );
}
