import { useState, useEffect } from 'react';
import { 
  ArrowLeft, Search, Plus, FileText, X, Trash2, 
  MoreVertical, Clock, Tag, BookOpen
} from 'lucide-react';
import { Screen } from '@/types/screens';
import { useNotesStore, Note, getRelativeTime, CATEGORY_ICONS } from '@/store/useNotesStore';

interface NotesScreenProps {
  onNavigate: (screen: Screen) => void;
}

export default function NotesScreen({ onNavigate }: NotesScreenProps) {
  const { 
    initialize, 
    isLoading, 
    searchQuery, 
    setSearchQuery,
    getFilteredNotes,
    deleteNote,
    countNotes
  } = useNotesStore();
  
  const [isSearching, setIsSearching] = useState(false);
  const [menuOpen, setMenuOpen] = useState<string | null>(null);

  useEffect(() => {
    initialize();
  }, [initialize]);

  const filteredNotes = getFilteredNotes();
  const totalNotes = countNotes();

  const handleDeleteNote = async (id: string) => {
    if (confirm('Tem certeza que deseja excluir esta anotação?')) {
      await deleteNote(id);
    }
    setMenuOpen(null);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#FFF5F8] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-pink-200 border-t-pink-500 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FFF5F8]">
      {/* Header */}
      <div className="bg-gradient-to-r from-pink-400 to-pink-500 px-4 pt-12 pb-6">
        <div className="flex items-center justify-between">
          <button
            onClick={() => onNavigate({ name: 'home' })}
            className="w-10 h-10 flex items-center justify-center rounded-full bg-white/20 text-white"
          >
            <ArrowLeft size={24} />
          </button>
          
          {isSearching ? (
            <div className="flex-1 mx-3">
              <div className="relative">
                <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-pink-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Buscar anotações..."
                  autoFocus
                  className="w-full pl-10 pr-10 py-2 rounded-full bg-white text-gray-800 placeholder-pink-300 font-poppins text-sm focus:outline-none focus:ring-2 focus:ring-pink-300"
                />
                <button
                  onClick={() => {
                    setIsSearching(false);
                    setSearchQuery('');
                  }}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-pink-400"
                >
                  <X size={18} />
                </button>
              </div>
            </div>
          ) : (
            <h1 className="text-xl font-bold text-white font-poppins">Anotações</h1>
          )}
          
          {!isSearching && (
            <button
              onClick={() => setIsSearching(true)}
              className="w-10 h-10 flex items-center justify-center rounded-full bg-white/20 text-white"
            >
              <Search size={22} />
            </button>
          )}
        </div>
      </div>

      <div className="px-4 -mt-3 pb-24">
        {/* Summary Card */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100 mb-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-pink-100 to-pink-200 flex items-center justify-center">
              <FileText size={28} className="text-pink-500" />
            </div>
            <div className="flex-1">
              <h2 className="text-xl font-bold text-gray-800 font-poppins">Suas Anotações</h2>
              <p className="text-gray-500 text-sm font-poppins">{totalNotes} nota(s)</p>
            </div>
            <div className="w-10 h-10 rounded-full bg-pink-100 flex items-center justify-center">
              <span className="text-pink-500 font-bold font-poppins">{totalNotes}</span>
            </div>
          </div>
        </div>

        {/* Category Stats */}
        <div className="flex gap-2 mb-4 overflow-x-auto pb-2 scrollbar-hide">
          {Object.entries(
            filteredNotes.reduce((acc, note) => {
              acc[note.category] = (acc[note.category] || 0) + 1;
              return acc;
            }, {} as Record<string, number>)
          ).map(([category, count]) => (
            <div
              key={category}
              className="flex items-center gap-2 px-3 py-2 bg-white rounded-xl border border-pink-100 whitespace-nowrap"
            >
              <span className="text-sm">{CATEGORY_ICONS[category as keyof typeof CATEGORY_ICONS]}</span>
              <span className="text-sm font-medium text-gray-700 font-poppins">{category}</span>
              <span className="text-xs bg-pink-100 text-pink-600 px-2 py-0.5 rounded-full font-poppins">{count}</span>
            </div>
          ))}
        </div>

        {/* Search Results Info */}
        {searchQuery && (
          <div className="bg-pink-50 border border-pink-200 rounded-xl p-3 mb-4">
            <p className="text-pink-700 text-sm font-poppins">
              🔍 {filteredNotes.length} resultado(s) para "{searchQuery}"
            </p>
          </div>
        )}

        {/* Notes List */}
        {filteredNotes.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 shadow-sm border border-pink-100 text-center">
            <div className="w-16 h-16 rounded-full bg-pink-100 flex items-center justify-center mx-auto mb-4">
              <BookOpen size={32} className="text-pink-400" />
            </div>
            <h3 className="text-lg font-semibold text-gray-700 font-poppins mb-2">
              {searchQuery ? 'Nenhum resultado encontrado' : 'Nenhuma anotação ainda'}
            </h3>
            <p className="text-gray-500 text-sm font-poppins mb-4">
              {searchQuery 
                ? 'Tente buscar por outro termo' 
                : 'Crie sua primeira anotação e comece a organizar suas ideias!'}
            </p>
            {!searchQuery && (
              <button
                onClick={() => onNavigate({ name: 'note-edit' })}
                className="px-6 py-2 bg-pink-500 text-white rounded-full font-poppins font-medium"
              >
                Criar primeira nota
              </button>
            )}
          </div>
        ) : (
          <div className="space-y-3">
            {filteredNotes.map((note) => (
              <NoteCard
                key={note.id}
                note={note}
                onView={() => onNavigate({ name: 'note-view', noteId: note.id })}
                onDelete={() => handleDeleteNote(note.id)}
                menuOpen={menuOpen === note.id}
                onMenuToggle={() => setMenuOpen(menuOpen === note.id ? null : note.id)}
              />
            ))}
          </div>
        )}
      </div>

      {/* FAB */}
      <button
        onClick={() => onNavigate({ name: 'note-edit' })}
        className="fixed bottom-6 right-4 flex items-center gap-2 px-5 py-3 bg-gradient-to-r from-pink-500 to-pink-600 text-white rounded-full shadow-lg font-poppins font-semibold"
      >
        <Plus size={20} />
        Nova Anotação
      </button>
    </div>
  );
}

// Note Card Component
interface NoteCardProps {
  note: Note;
  onView: () => void;
  onDelete: () => void;
  menuOpen: boolean;
  onMenuToggle: () => void;
}

function NoteCard({ note, onView, onDelete, menuOpen, onMenuToggle }: NoteCardProps) {
  const relativeTime = getRelativeTime(note.updatedAt);

  return (
    <div 
      className="bg-white rounded-2xl shadow-sm border border-pink-100 overflow-hidden cursor-pointer active:scale-[0.98] transition-transform"
      onClick={onView}
    >
      <div className="flex">
        {/* Color Bar */}
        <div 
          className="w-2 flex-shrink-0"
          style={{ backgroundColor: note.colorHex }}
        />
        
        {/* Content */}
        <div className="flex-1 p-4">
          <div className="flex justify-between items-start mb-2">
            <h3 className="text-lg font-bold text-gray-800 font-poppins flex-1 pr-2">
              {note.title || 'Sem título'}
            </h3>
            <div className="relative">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onMenuToggle();
                }}
                className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-pink-50"
              >
                <MoreVertical size={18} className="text-gray-400" />
              </button>
              
              {menuOpen && (
                <div className="absolute right-0 top-full mt-1 bg-white rounded-xl shadow-lg border border-pink-100 py-1 z-10 min-w-[120px]">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDelete();
                    }}
                    className="w-full flex items-center gap-2 px-4 py-2 text-red-500 hover:bg-red-50 font-poppins text-sm"
                  >
                    <Trash2 size={16} />
                    Excluir
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Category Chip */}
          <div className="flex items-center gap-2 mb-2">
            <span className="inline-flex items-center gap-1 px-2 py-1 bg-pink-100 text-pink-600 rounded-lg text-xs font-medium font-poppins">
              {CATEGORY_ICONS[note.category]} {note.category}
            </span>
          </div>

          {/* Content Preview */}
          {note.content && (
            <p className="text-gray-500 text-sm font-poppins mb-3 line-clamp-2">
              {note.content.replace(/[#*_\[\]()]/g, '').substring(0, 100)}
              {note.content.length > 100 ? '...' : ''}
            </p>
          )}

          {/* Bottom Row */}
          <div className="flex items-center justify-between">
            {/* Tags */}
            <div className="flex items-center gap-1 flex-wrap flex-1">
              {note.tags.slice(0, 3).map((tag, index) => (
                <span
                  key={index}
                  className="inline-flex items-center gap-1 px-2 py-0.5 bg-gray-100 text-gray-600 rounded-full text-xs font-poppins"
                >
                  <Tag size={10} />
                  {tag}
                </span>
              ))}
              {note.tags.length > 3 && (
                <span className="text-xs text-gray-400 font-poppins">+{note.tags.length - 3}</span>
              )}
            </div>

            {/* Time */}
            <div className="flex items-center gap-1 text-gray-400 text-xs font-poppins">
              <Clock size={12} />
              {relativeTime}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
