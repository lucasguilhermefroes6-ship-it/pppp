import { useState, useEffect, useRef } from 'react';
import { 
  ArrowLeft, Search, FileText, Link as LinkIcon, CheckSquare, Pin,
  Folder, Sparkles, Sun, Moon, GraduationCap, Briefcase, Home,
  ChefHat, Dumbbell, Wallet, Heart, Plane, BookOpen, Star,
  Music, Camera, Gift, Coffee, Flower2
} from 'lucide-react';
import { Screen } from '../types/screens';
import { useFolderStore } from '../store/useFolderStore';

interface FoldersSearchScreenProps {
  onNavigate: (screen: Screen) => void;
}

// Mapeamento de ícones
const iconMap: Record<string, React.ElementType> = {
  Folder, Sparkles, Sun, Moon, GraduationCap, Briefcase, Home,
  ChefHat, Dumbbell, Wallet, Heart, Plane, BookOpen, Star,
  Music, Camera, Gift, Coffee, Flower2
};

function getIcon(name: string): React.ElementType {
  return iconMap[name] || Folder;
}

function getItemIcon(type: string): React.ElementType {
  switch (type) {
    case 'NOTE': return FileText;
    case 'LINK': return LinkIcon;
    case 'CHECKLIST': return CheckSquare;
    default: return FileText;
  }
}

function getRelativeTime(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffSecs = Math.floor(diffMs / 1000);
  const diffMins = Math.floor(diffSecs / 60);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffSecs < 60) return 'Agora';
  if (diffMins < 60) return `${diffMins} min`;
  if (diffHours < 24) return `${diffHours}h`;
  if (diffDays === 1) return 'Ontem';
  if (diffDays < 7) return `${diffDays} dias`;
  if (diffDays < 30) return `${Math.floor(diffDays / 7)} sem`;
  return `${Math.floor(diffDays / 30)} mês`;
}

export default function FoldersSearchScreen({ onNavigate }: FoldersSearchScreenProps) {
  const { search, loadFolders } = useFolderStore();
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  
  const results = search(query);
  
  useEffect(() => {
    loadFolders();
    inputRef.current?.focus();
  }, [loadFolders]);
  
  return (
    <div className="min-h-screen bg-[#FFF5F8]">
      {/* Header */}
      <div className="bg-gradient-to-r from-pink-400 to-pink-500 pt-12 pb-4 px-4">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => onNavigate({ name: 'folders' })}
            className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          
          <div className="flex-1 relative">
            <Search className="w-5 h-5 text-gray-400 absolute left-4 top-1/2 -translate-y-1/2" />
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar em todas as pastas..."
              className="w-full pl-12 pr-4 py-3 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-pink-300"
            />
          </div>
        </div>
      </div>
      
      <div className="px-4 py-4">
        {/* Info */}
        {query && (
          <p className="text-sm text-gray-500 mb-4">
            {results.length} resultado{results.length !== 1 ? 's' : ''} para "{query}"
          </p>
        )}
        
        {/* Sugestões quando vazio */}
        {!query && (
          <div className="bg-white rounded-2xl p-6 text-center border border-pink-100">
            <div className="w-16 h-16 bg-pink-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-pink-300" />
            </div>
            <h3 className="text-lg font-semibold text-gray-700 mb-2">Buscar</h3>
            <p className="text-gray-500 text-sm">
              Digite para buscar em títulos, conteúdos, links e itens de checklist
            </p>
          </div>
        )}
        
        {/* Resultados */}
        {query && results.length === 0 && (
          <div className="bg-white rounded-2xl p-6 text-center border border-pink-100">
            <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-gray-300" />
            </div>
            <h3 className="text-lg font-semibold text-gray-700 mb-2">Nenhum resultado</h3>
            <p className="text-gray-500 text-sm">
              Tente buscar por outros termos
            </p>
          </div>
        )}
        
        {results.length > 0 && (
          <div className="space-y-3">
            {results.map((item) => {
              const ItemIcon = getItemIcon(item.type);
              const FolderIconComponent = getIcon(item.folderIconName);
              
              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate({ 
                    name: 'folder-item-edit', 
                    folderId: item.folderId, 
                    itemId: item.id 
                  })}
                  className="w-full bg-white rounded-2xl p-4 shadow-sm border border-pink-100 text-left"
                >
                  <div className="flex items-start gap-3">
                    <div 
                      className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: `${item.folderColorHex}20` }}
                    >
                      <ItemIcon className="w-5 h-5" style={{ color: item.folderColorHex }} />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-gray-800 truncate">{item.title}</h4>
                        {item.pinned && (
                          <Pin className="w-4 h-4 text-pink-400 flex-shrink-0" />
                        )}
                      </div>
                      
                      <div className="flex items-center gap-2 mt-1">
                        <FolderIconComponent 
                          className="w-3 h-3" 
                          style={{ color: item.folderColorHex }} 
                        />
                        <span className="text-xs text-gray-500">{item.folderName}</span>
                        <span className="text-xs text-gray-400">•</span>
                        <span className="text-xs text-gray-400">
                          {getRelativeTime(item.updatedAt)}
                        </span>
                      </div>
                      
                      {/* Preview do conteúdo */}
                      {item.content && (
                        <p className="text-sm text-gray-500 truncate mt-1">
                          {item.content.substring(0, 50)}
                        </p>
                      )}
                      
                      {item.type === 'CHECKLIST' && item.checklistItems && (
                        <p className="text-sm text-gray-500 mt-1">
                          ☑️ {item.checklistItems.filter(i => i.done).length}/
                          {item.checklistItems.length} itens
                        </p>
                      )}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
