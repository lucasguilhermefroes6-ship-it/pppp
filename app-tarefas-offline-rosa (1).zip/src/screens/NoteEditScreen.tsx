import { useState, useEffect, useRef } from 'react';
import { 
  ArrowLeft, Check, FileText, Type, Bold, Italic, 
  List, CheckSquare, Link, Plus, X, Tag
} from 'lucide-react';
import { Screen } from '@/types/screens';
import { useNotesStore, NOTE_CATEGORIES, NOTE_COLORS, NoteCategory, CATEGORY_ICONS } from '@/store/useNotesStore';

interface NoteEditScreenProps {
  onNavigate: (screen: Screen) => void;
  noteId?: string;
}

export default function NoteEditScreen({ onNavigate, noteId }: NoteEditScreenProps) {
  const { addNote, updateNote, getNoteById, initialize } = useNotesStore();
  
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState<NoteCategory>('Pessoal');
  const [tags, setTags] = useState<string[]>([]);
  const [newTag, setNewTag] = useState('');
  const [colorHex, setColorHex] = useState('#E91E63');
  const [isSaving, setIsSaving] = useState(false);
  
  // Ref para o textarea para controlar cursor e seleção
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const isEditing = !!noteId;

  useEffect(() => {
    initialize().then(() => {
      if (noteId) {
        const note = getNoteById(noteId);
        if (note) {
          setTitle(note.title);
          setContent(note.content);
          setCategory(note.category);
          setTags(note.tags);
          setColorHex(note.colorHex);
        }
      }
    });
  }, [noteId, initialize, getNoteById]);

  const handleSave = async () => {
    if (!title.trim()) {
      alert('Por favor, adicione um título');
      return;
    }

    setIsSaving(true);
    try {
      if (isEditing && noteId) {
        await updateNote(noteId, {
          title: title.trim(),
          content,
          category,
          tags,
          colorHex,
        });
      } else {
        await addNote({
          title: title.trim(),
          content,
          category,
          tags,
          colorHex,
        });
      }
      onNavigate({ name: 'notes' });
    } catch (error) {
      console.error('Error saving note:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const insertMarkdown = (type: 'bold' | 'italic' | 'list' | 'checkbox' | 'link') => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = content.substring(start, end);
    const beforeText = content.substring(0, start);
    const afterText = content.substring(end);

    let newText = '';
    let cursorOffset = 0;

    switch (type) {
      case 'bold':
        if (selectedText) {
          // Envolver texto selecionado com **
          newText = beforeText + '**' + selectedText + '**' + afterText;
          cursorOffset = start + 2 + selectedText.length + 2;
        } else {
          // Inserir placeholder e posicionar cursor no meio
          newText = beforeText + '**texto**' + afterText;
          cursorOffset = start + 2; // Posicionar antes de "texto"
        }
        break;
      case 'italic':
        if (selectedText) {
          newText = beforeText + '_' + selectedText + '_' + afterText;
          cursorOffset = start + 1 + selectedText.length + 1;
        } else {
          newText = beforeText + '_texto_' + afterText;
          cursorOffset = start + 1;
        }
        break;
      case 'list':
        if (selectedText) {
          // Transformar cada linha em item de lista
          const lines = selectedText.split('\n').map(line => '- ' + line).join('\n');
          newText = beforeText + '\n' + lines + afterText;
          cursorOffset = start + 1 + lines.length;
        } else {
          newText = beforeText + '\n- ' + afterText;
          cursorOffset = start + 3;
        }
        break;
      case 'checkbox':
        if (selectedText) {
          const lines = selectedText.split('\n').map(line => '- [ ] ' + line).join('\n');
          newText = beforeText + '\n' + lines + afterText;
          cursorOffset = start + 1 + lines.length;
        } else {
          newText = beforeText + '\n- [ ] ' + afterText;
          cursorOffset = start + 7;
        }
        break;
      case 'link':
        if (selectedText) {
          newText = beforeText + '[' + selectedText + '](url)' + afterText;
          cursorOffset = start + 1 + selectedText.length + 2; // Posicionar em "url"
        } else {
          newText = beforeText + '[texto](url)' + afterText;
          cursorOffset = start + 1; // Posicionar em "texto"
        }
        break;
    }

    setContent(newText);
    
    // Restaurar foco e posição do cursor após a atualização
    setTimeout(() => {
      textarea.focus();
      if (type === 'bold' && !selectedText) {
        textarea.setSelectionRange(start + 2, start + 2 + 5); // Selecionar "texto"
      } else if (type === 'italic' && !selectedText) {
        textarea.setSelectionRange(start + 1, start + 1 + 5); // Selecionar "texto"
      } else if (type === 'link' && !selectedText) {
        textarea.setSelectionRange(start + 1, start + 1 + 5); // Selecionar "texto"
      } else {
        textarea.setSelectionRange(cursorOffset, cursorOffset);
      }
    }, 0);
  };

  const handleAddTag = () => {
    const trimmedTag = newTag.trim().toLowerCase();
    if (trimmedTag && !tags.includes(trimmedTag)) {
      setTags([...tags, trimmedTag]);
      setNewTag('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  // Função para renderizar Markdown simples em HTML
  const renderMarkdown = (text: string): string => {
    if (!text) return '';
    
    let html = text
      // Escapar HTML
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      // Negrito: **texto** ou __texto__
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/__(.+?)__/g, '<strong>$1</strong>')
      // Itálico: _texto_ ou *texto*
      .replace(/(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)/g, '<em>$1</em>')
      .replace(/_(.+?)_/g, '<em>$1</em>')
      // Checkbox marcado: - [x]
      .replace(/^- \[x\] (.+)$/gm, '☑️ $1')
      // Checkbox desmarcado: - [ ]
      .replace(/^- \[ \] (.+)$/gm, '☐ $1')
      // Lista: - item
      .replace(/^- (.+)$/gm, '• $1')
      // Link: [texto](url)
      .replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2" class="text-pink-500 underline">$1</a>')
      // Quebras de linha
      .replace(/\n/g, '<br/>');
    
    return html;
  };

  return (
    <div className="min-h-screen bg-[#FFF5F8]">
      {/* Header */}
      <div className="bg-white border-b border-pink-100 px-4 pt-12 pb-4">
        <div className="flex items-center justify-between">
          <button
            onClick={() => onNavigate({ name: 'notes' })}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-pink-50"
          >
            <ArrowLeft size={24} className="text-gray-600" />
          </button>
          
          <button
            onClick={handleSave}
            disabled={isSaving}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-pink-500 to-pink-600 text-white rounded-full font-poppins font-medium shadow-md disabled:opacity-50"
          >
            <Check size={18} />
            {isSaving ? 'Salvando...' : 'Salvar'}
          </button>
        </div>
      </div>

      <div className="px-4 py-4 pb-8 space-y-6">
        {/* Hero Card */}
        <div className="bg-gradient-to-br from-pink-400 to-pink-600 rounded-3xl p-5 shadow-lg">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-white/20 flex items-center justify-center">
              <FileText size={32} className="text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white font-poppins">
                {isEditing ? 'Editar Anotação' : 'Nova Anotação'}
              </h1>
              <p className="text-white/80 font-poppins text-sm">
                Registre suas ideias e pensamentos
              </p>
            </div>
          </div>
        </div>

        {/* Title Field */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
          <label className="block text-gray-700 font-semibold font-poppins mb-3">
            Título
          </label>
          <div className="relative">
            <Type size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-pink-400" />
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Digite o título da anotação"
              className="w-full pl-10 pr-4 py-3 border border-pink-200 rounded-xl font-poppins text-gray-700 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-pink-300"
            />
          </div>
        </div>

        {/* Category Field */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
          <label className="block text-gray-700 font-semibold font-poppins mb-3">
            Categoria
          </label>
          <div className="flex flex-wrap gap-2">
            {NOTE_CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setCategory(cat)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl border-2 font-poppins text-sm font-medium transition-all ${
                  category === cat
                    ? 'bg-pink-100 border-pink-500 text-pink-700'
                    : 'bg-white border-pink-200 text-gray-600 hover:border-pink-300'
                }`}
              >
                <span>{CATEGORY_ICONS[cat]}</span>
                {cat}
                {category === cat && <Check size={14} className="text-pink-500" />}
              </button>
            ))}
          </div>
        </div>

        {/* Content Field */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
          <label className="block text-gray-700 font-semibold font-poppins mb-3">
            Conteúdo
          </label>
          
          {/* Markdown Toolbar */}
          <div className="flex items-center gap-1 mb-3 p-2 bg-pink-50 rounded-xl">
            <button
              onClick={() => insertMarkdown('bold')}
              className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-pink-200 text-pink-600"
              title="Negrito"
            >
              <Bold size={16} />
            </button>
            <button
              onClick={() => insertMarkdown('italic')}
              className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-pink-200 text-pink-600"
              title="Itálico"
            >
              <Italic size={16} />
            </button>
            <button
              onClick={() => insertMarkdown('list')}
              className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-pink-200 text-pink-600"
              title="Lista"
            >
              <List size={16} />
            </button>
            <button
              onClick={() => insertMarkdown('checkbox')}
              className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-pink-200 text-pink-600"
              title="Checkbox"
            >
              <CheckSquare size={16} />
            </button>
            <button
              onClick={() => insertMarkdown('link')}
              className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-pink-200 text-pink-600"
              title="Link"
            >
              <Link size={16} />
            </button>
          </div>

          <textarea
            ref={textareaRef}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Escreva sua anotação aqui...&#10;Dica: Use Markdown para formatar o texto"
            rows={10}
            className="w-full px-4 py-3 border border-pink-200 rounded-xl font-poppins text-gray-700 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-pink-300 resize-none"
          />
        </div>

        {/* Tags Field */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
          <label className="block text-gray-700 font-semibold font-poppins mb-3">
            Tags
          </label>
          
          {/* Add Tag */}
          <div className="flex gap-2 mb-3">
            <div className="relative flex-1">
              <Tag size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-pink-400" />
              <input
                type="text"
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleAddTag()}
                placeholder="Adicionar tag"
                className="w-full pl-9 pr-4 py-2 border border-pink-200 rounded-xl font-poppins text-sm text-gray-700 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-pink-300"
              />
            </div>
            <button
              onClick={handleAddTag}
              disabled={!newTag.trim()}
              className="px-4 py-2 bg-pink-500 text-white rounded-xl font-poppins font-medium text-sm disabled:opacity-50"
            >
              <Plus size={18} />
            </button>
          </div>

          {/* Tags List */}
          {tags.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {tags.map((tag, index) => (
                <span
                  key={index}
                  className="inline-flex items-center gap-1 px-3 py-1 bg-pink-100 text-pink-700 rounded-full text-sm font-poppins"
                >
                  #{tag}
                  <button
                    onClick={() => handleRemoveTag(tag)}
                    className="w-4 h-4 flex items-center justify-center rounded-full hover:bg-pink-200"
                  >
                    <X size={12} />
                  </button>
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Color Field */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
          <label className="block text-gray-700 font-semibold font-poppins mb-3">
            Cor de Identificação
          </label>
          <div className="grid grid-cols-5 gap-3">
            {NOTE_COLORS.map((color) => (
              <button
                key={color}
                onClick={() => setColorHex(color)}
                className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all ${
                  colorHex === color ? 'ring-2 ring-offset-2 ring-gray-800 scale-110' : ''
                }`}
                style={{ backgroundColor: color }}
              >
                {colorHex === color && (
                  <Check size={20} className="text-white drop-shadow" />
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Preview */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
          <label className="block text-gray-700 font-semibold font-poppins mb-3">
            Preview
          </label>
          <div className="flex">
            <div 
              className="w-2 rounded-l-xl"
              style={{ backgroundColor: colorHex }}
            />
            <div className="flex-1 p-4 bg-gray-50 rounded-r-xl border border-l-0 border-gray-200">
              <h3 className="text-lg font-bold text-gray-800 font-poppins mb-1">
                {title || 'Título da nota'}
              </h3>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-pink-100 text-pink-600 rounded-lg text-xs font-medium font-poppins mb-2">
                {CATEGORY_ICONS[category]} {category}
              </span>
              <div 
                className="text-gray-500 text-sm font-poppins line-clamp-2"
                dangerouslySetInnerHTML={{ 
                  __html: content 
                    ? renderMarkdown(content) 
                    : 'Conteúdo da sua anotação aparecerá aqui...' 
                }}
              />
              {tags.length > 0 && (
                <div className="flex gap-1 mt-2 flex-wrap">
                  {tags.slice(0, 3).map((tag, idx) => (
                    <span key={idx} className="text-xs text-gray-400 font-poppins">#{tag}</span>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
