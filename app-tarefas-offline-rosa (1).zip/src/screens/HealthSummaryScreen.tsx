import { useState, useEffect } from 'react';
import { useWaterStore } from '../store/useWaterStore';
import { useMoodStore } from '../store/useMoodStore';
import { useWorkoutStore } from '../store/useWorkoutStore';
import { useFinanceStore } from '../store/useFinanceStore';

interface HealthSummaryScreenProps {
  setScreen: (screen: any) => void;
}

// Helpers
const getWeekDays = (weekStart: Date): Date[] => {
  const days: Date[] = [];
  for (let i = 0; i < 7; i++) {
    const day = new Date(weekStart);
    day.setDate(weekStart.getDate() + i);
    days.push(day);
  }
  return days;
};

const getStartOfWeek = (date: Date): Date => {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  d.setDate(diff);
  d.setHours(0, 0, 0, 0);
  return d;
};

const formatDateKey = (date: Date): string => {
  return date.toISOString().split('T')[0];
};

const formatMinutes = (minutes: number): string => {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${h}h${m.toString().padStart(2, '0')}`;
};

const WEEKDAYS = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];

const CATEGORY_COLORS: Record<string, string> = {
  'Alimentação': '#FF7043',
  'Transporte': '#42A5F5',
  'Moradia': '#AB47BC',
  'Saúde': '#66BB6A',
  'Educação': '#FFA726',
  'Lazer': '#EC407A',
  'Vestuário': '#7E57C2',
  'Contas': '#26A69A',
  'Outros': '#BDBDBD',
};

export default function HealthSummaryScreen({ setScreen }: HealthSummaryScreenProps) {
  const [weekStart, setWeekStart] = useState(() => getStartOfWeek(new Date()));
  const [isReady, setIsReady] = useState(false);
  const weekDays = getWeekDays(weekStart);
  
  // Stores - acessar dados diretamente
  const waterEntries = useWaterStore(state => state.entries);
  const moodEntries = useMoodStore(state => state.entries);
  const workouts = useWorkoutStore(state => state.workouts);
  const transactions = useFinanceStore(state => state.transactions);
  
  // Carregar dados de sono diretamente do localStorage (SOLUÇÃO SIMPLES E DIRETA)
  const [sleepEntries, setSleepEntries] = useState<any[]>(() => {
    try {
      const data = localStorage.getItem('vida-rosa-sleep-entries');
      console.log('[HealthSummary] Initial sleep load:', data);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  });
  
  // Inicializar stores
  useEffect(() => {
    useWaterStore.getState().initialize();
    useMoodStore.getState().initialize();
    useWorkoutStore.getState().initialize();
    useFinanceStore.getState().initialize();
    
    // Recarregar sono do localStorage
    const sleepData = localStorage.getItem('vida-rosa-sleep-entries');
    if (sleepData) {
      try {
        const parsed = JSON.parse(sleepData);
        console.log('[HealthSummary] Sleep entries loaded:', parsed);
        setSleepEntries(parsed);
      } catch (e) {
        console.error('[HealthSummary] Error loading sleep:', e);
      }
    }
    
    setIsReady(true);
  }, []);

  const isCurrentWeek = formatDateKey(weekStart) === formatDateKey(getStartOfWeek(new Date()));

  // Calculate weekly data
  const weekData = weekDays.map(day => {
    const dateKey = formatDateKey(day);
    
    // Water - campo é 'date' não 'dateKey'
    const dayWater = waterEntries.filter(e => e.date === dateKey);
    const waterTotal = dayWater.reduce((sum, e) => sum + e.amount, 0);
    
    // Sleep
    const daySleep = sleepEntries.find(e => e.date === dateKey);
    const sleepMinutes = daySleep?.durationMinutes || 0;
    
    // Mood
    const dayMood = moodEntries.find(e => e.dateKey === dateKey);
    
    // Workout
    const dayWorkout = workouts.find(e => e.dateKey === dateKey);
    
    // Expenses
    const dayExpenses = transactions.filter(t => t.date === dateKey && t.type === 'EXPENSE');
    const expenseTotal = dayExpenses.reduce((sum, t) => sum + t.amountCents, 0);
    
    return {
      date: day,
      dateKey,
      water: waterTotal,
      sleep: sleepMinutes,
      mood: dayMood,
      workout: dayWorkout,
      expenses: expenseTotal,
    };
  });

  // Totals
  const totalWater = weekData.reduce((sum, d) => sum + d.water, 0);
  const avgWater = Math.round(totalWater / 7);
  
  const sleepDays = weekData.filter(d => d.sleep > 0);
  const totalSleep = weekData.reduce((sum, d) => sum + d.sleep, 0);
  const avgSleep = sleepDays.length > 0 ? Math.round(totalSleep / sleepDays.length) : 0;
  
  const trainDays = weekData.filter(d => d.workout && d.workout.intensity !== 'NONE').length;
  
  const totalExpenses = weekData.reduce((sum, d) => sum + d.expenses, 0);

  // Top mood
  const moodCounts: Record<string, number> = {};
  weekData.forEach(d => {
    if (d.mood) {
      moodCounts[d.mood.moodId] = (moodCounts[d.mood.moodId] || 0) + 1;
    }
  });
  const topMoodEntry = Object.entries(moodCounts).sort((a, b) => b[1] - a[1])[0];
  const topMoodData = topMoodEntry ? moodEntries.find(m => m.moodId === topMoodEntry[0]) : null;

  // Top categories
  const categoryCounts: Record<string, number> = {};
  transactions
    .filter(t => {
      const tDate = t.date;
      const startKey = formatDateKey(weekStart);
      const endKey = formatDateKey(weekDays[6]);
      return t.type === 'EXPENSE' && tDate >= startKey && tDate <= endKey;
    })
    .forEach(t => {
      categoryCounts[t.category] = (categoryCounts[t.category] || 0) + t.amountCents;
    });
  const topCategories = Object.entries(categoryCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3);

  // Max values for bars
  const maxWater = Math.max(...weekData.map(d => d.water), 1);
  const maxSleep = Math.max(...weekData.map(d => d.sleep), 1);
  const maxExpense = Math.max(...weekData.map(d => d.expenses), 1);

  const navigateWeek = (delta: number) => {
    const newStart = new Date(weekStart);
    newStart.setDate(newStart.getDate() + (delta * 7));
    setWeekStart(newStart);
  };

  const formatWeekRange = () => {
    const end = new Date(weekStart);
    end.setDate(end.getDate() + 6);
    const startStr = weekStart.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
    const endStr = end.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
    return `${startStr} a ${endStr}`;
  };

  // Mostrar loading enquanto os dados não estão prontos
  if (!isReady) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#FFF8FC' }}>
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-pink-200 border-t-pink-500 rounded-full animate-spin mx-auto mb-4" />
          <p style={{ color: '#7A5A73' }}>Carregando dados...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-6" style={{ backgroundColor: '#FFF8FC' }}>
      {/* Header */}
      <div 
        className="px-4 pt-12 pb-6"
        style={{ background: 'linear-gradient(135deg, #FFE0F0 0%, #FFF0F7 100%)' }}
      >
        <div className="flex items-center gap-3 mb-4">
          <button
            onClick={() => setScreen({ name: 'home' })}
            className="w-10 h-10 rounded-full bg-white shadow flex items-center justify-center"
          >
            <svg className="w-5 h-5" fill="none" stroke="#F0609E" strokeWidth={2} viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <div>
            <h1 className="text-2xl font-bold" style={{ color: '#2D1F2D', fontFamily: 'Poppins, sans-serif' }}>
              Resumo Saúde
            </h1>
            <p style={{ color: '#7A5A73', fontSize: 14 }}>Evolução semanal</p>
          </div>
        </div>
      </div>

      <div className="px-4 -mt-2 space-y-4">
        {/* Week Selector */}
        <div className="bg-white rounded-2xl p-4 shadow-sm" style={{ border: '1px solid #F3C9DF' }}>
          <div className="flex items-center justify-between">
            <button 
              onClick={() => navigateWeek(-1)}
              className="w-10 h-10 rounded-full flex items-center justify-center"
              style={{ backgroundColor: '#FFF0F7' }}
            >
              <svg className="w-5 h-5" fill="none" stroke="#F0609E" strokeWidth={2} viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <div className="text-center">
              <p className="font-semibold" style={{ color: '#2D1F2D' }}>Semana de {formatWeekRange()}</p>
              {isCurrentWeek && (
                <span className="text-xs px-2 py-0.5 rounded-full" style={{ backgroundColor: '#FFE0F0', color: '#F0609E' }}>
                  Esta semana
                </span>
              )}
            </div>
            <button 
              onClick={() => navigateWeek(1)}
              className="w-10 h-10 rounded-full flex items-center justify-center"
              style={{ backgroundColor: '#FFF0F7' }}
            >
              <svg className="w-5 h-5" fill="none" stroke="#F0609E" strokeWidth={2} viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 gap-3">
          {/* Sono */}
          <div className="bg-white rounded-2xl p-4 shadow-sm" style={{ border: '1px solid #F3C9DF' }}>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: '#E8DEF8' }}>
                <span>🌙</span>
              </div>
              <span className="text-sm" style={{ color: '#7A5A73' }}>Sono médio</span>
            </div>
            <p className="text-xl font-bold" style={{ color: '#7C3AED' }}>{formatMinutes(avgSleep)}</p>
          </div>

          {/* Água */}
          <div className="bg-white rounded-2xl p-4 shadow-sm" style={{ border: '1px solid #F3C9DF' }}>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: '#E0F7FA' }}>
                <span>💧</span>
              </div>
              <span className="text-sm" style={{ color: '#7A5A73' }}>Água total</span>
            </div>
            <p className="text-xl font-bold" style={{ color: '#00ACC1' }}>{(totalWater / 1000).toFixed(1)}L</p>
          </div>

          {/* Treino */}
          <div className="bg-white rounded-2xl p-4 shadow-sm" style={{ border: '1px solid #F3C9DF' }}>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: '#E8F5E9' }}>
                <span>🏋️</span>
              </div>
              <span className="text-sm" style={{ color: '#7A5A73' }}>Treinos</span>
            </div>
            <p className="text-xl font-bold" style={{ color: '#43A047' }}>{trainDays} dias</p>
          </div>

          {/* Gastos */}
          <div className="bg-white rounded-2xl p-4 shadow-sm" style={{ border: '1px solid #F3C9DF' }}>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: '#FFEBEE' }}>
                <span>💰</span>
              </div>
              <span className="text-sm" style={{ color: '#7A5A73' }}>Gastos</span>
            </div>
            <p className="text-xl font-bold" style={{ color: '#E53935' }}>
              R$ {(totalExpenses / 100).toFixed(2)}
            </p>
          </div>
        </div>

        {/* Sono Chart */}
        <div className="bg-white rounded-2xl p-4 shadow-sm" style={{ border: '1px solid #F3C9DF' }}>
          <div className="flex items-center gap-2 mb-4">
            <span className="text-lg">🌙</span>
            <h3 className="font-semibold" style={{ color: '#2D1F2D' }}>Sono da Semana</h3>
          </div>
          <div className="flex justify-between items-end h-24 mb-2">
            {weekData.map((day, i) => (
              <div key={i} className="flex flex-col items-center flex-1">
                <div 
                  className="w-6 rounded-t-lg transition-all"
                  style={{ 
                    height: `${(day.sleep / maxSleep) * 80}px`,
                    backgroundColor: day.sleep > 0 ? '#7C3AED' : '#E8E8E8',
                    minHeight: 4
                  }}
                />
              </div>
            ))}
          </div>
          <div className="flex justify-between">
            {WEEKDAYS.map((d, i) => (
              <span key={i} className="text-xs text-center flex-1" style={{ color: '#7A5A73' }}>{d}</span>
            ))}
          </div>
          <div className="mt-3 pt-3 border-t flex justify-between text-sm" style={{ borderColor: '#F3C9DF' }}>
            <span style={{ color: '#7A5A73' }}>Total: {formatMinutes(totalSleep)}</span>
            <span style={{ color: '#7A5A73' }}>Média: {formatMinutes(avgSleep)}/noite</span>
          </div>
        </div>

        {/* Água Chart */}
        <div className="bg-white rounded-2xl p-4 shadow-sm" style={{ border: '1px solid #F3C9DF' }}>
          <div className="flex items-center gap-2 mb-4">
            <span className="text-lg">💧</span>
            <h3 className="font-semibold" style={{ color: '#2D1F2D' }}>Água da Semana</h3>
          </div>
          <div className="flex justify-between items-end h-24 mb-2">
            {weekData.map((day, i) => (
              <div key={i} className="flex flex-col items-center flex-1">
                <div 
                  className="w-6 rounded-t-lg transition-all"
                  style={{ 
                    height: `${(day.water / maxWater) * 80}px`,
                    backgroundColor: day.water > 0 ? '#00ACC1' : '#E8E8E8',
                    minHeight: 4
                  }}
                />
              </div>
            ))}
          </div>
          <div className="flex justify-between">
            {WEEKDAYS.map((d, i) => (
              <span key={i} className="text-xs text-center flex-1" style={{ color: '#7A5A73' }}>{d}</span>
            ))}
          </div>
          <div className="mt-3 pt-3 border-t flex justify-between text-sm" style={{ borderColor: '#F3C9DF' }}>
            <span style={{ color: '#7A5A73' }}>Total: {(totalWater / 1000).toFixed(1)}L</span>
            <span style={{ color: '#7A5A73' }}>Média: {avgWater}ml/dia</span>
          </div>
        </div>

        {/* Humor */}
        <div className="bg-white rounded-2xl p-4 shadow-sm" style={{ border: '1px solid #F3C9DF' }}>
          <div className="flex items-center gap-2 mb-4">
            <span className="text-lg">😊</span>
            <h3 className="font-semibold" style={{ color: '#2D1F2D' }}>Humor da Semana</h3>
          </div>
          <div className="flex justify-between mb-2">
            {weekData.map((day, i) => (
              <div key={i} className="flex flex-col items-center flex-1">
                <span className="text-2xl">{day.mood?.emoji || '—'}</span>
              </div>
            ))}
          </div>
          <div className="flex justify-between">
            {WEEKDAYS.map((d, i) => (
              <span key={i} className="text-xs text-center flex-1" style={{ color: '#7A5A73' }}>{d}</span>
            ))}
          </div>
          {topMoodData && (
            <div className="mt-3 pt-3 border-t text-sm text-center" style={{ borderColor: '#F3C9DF', color: '#7A5A73' }}>
              Humor mais frequente: <span className="font-medium">{topMoodData.emoji} {topMoodData.label}</span>
            </div>
          )}
        </div>

        {/* Treino */}
        <div className="bg-white rounded-2xl p-4 shadow-sm" style={{ border: '1px solid #F3C9DF' }}>
          <div className="flex items-center gap-2 mb-4">
            <span className="text-lg">🏋️</span>
            <h3 className="font-semibold" style={{ color: '#2D1F2D' }}>Treino da Semana</h3>
          </div>
          <div className="flex justify-between mb-2">
            {weekData.map((day, i) => {
              const intensity = day.workout?.intensity || 'NONE';
              const icon = intensity === 'INTENSE' ? '🔥' : intensity === 'MEDIUM' ? '🏃‍♀️' : intensity === 'LIGHT' ? '🚶‍♀️' : '—';
              return (
                <div key={i} className="flex flex-col items-center flex-1">
                  <span className="text-2xl">{icon}</span>
                </div>
              );
            })}
          </div>
          <div className="flex justify-between">
            {WEEKDAYS.map((d, i) => (
              <span key={i} className="text-xs text-center flex-1" style={{ color: '#7A5A73' }}>{d}</span>
            ))}
          </div>
          <div className="mt-3 pt-3 border-t text-sm text-center" style={{ borderColor: '#F3C9DF', color: '#7A5A73' }}>
            Total: <span className="font-medium">{trainDays} dias de treino</span>
          </div>
        </div>

        {/* Gastos Chart */}
        <div className="bg-white rounded-2xl p-4 shadow-sm" style={{ border: '1px solid #F3C9DF' }}>
          <div className="flex items-center gap-2 mb-4">
            <span className="text-lg">💰</span>
            <h3 className="font-semibold" style={{ color: '#2D1F2D' }}>Gastos da Semana</h3>
          </div>
          <div className="flex justify-between items-end h-24 mb-2">
            {weekData.map((day, i) => (
              <div key={i} className="flex flex-col items-center flex-1">
                <div 
                  className="w-6 rounded-t-lg transition-all"
                  style={{ 
                    height: `${(day.expenses / maxExpense) * 80}px`,
                    backgroundColor: day.expenses > 0 ? '#E53935' : '#E8E8E8',
                    minHeight: 4
                  }}
                />
              </div>
            ))}
          </div>
          <div className="flex justify-between">
            {WEEKDAYS.map((d, i) => (
              <span key={i} className="text-xs text-center flex-1" style={{ color: '#7A5A73' }}>{d}</span>
            ))}
          </div>
          <div className="mt-3 pt-3 border-t" style={{ borderColor: '#F3C9DF' }}>
            <p className="text-sm mb-2" style={{ color: '#7A5A73' }}>Total: <span className="font-bold" style={{ color: '#E53935' }}>R$ {(totalExpenses / 100).toFixed(2)}</span></p>
            {topCategories.length > 0 && (
              <div className="space-y-1">
                <p className="text-xs font-medium" style={{ color: '#7A5A73' }}>Top categorias:</p>
                {topCategories.map(([cat, amount]) => (
                  <div key={cat} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <div 
                        className="w-3 h-3 rounded-full" 
                        style={{ backgroundColor: CATEGORY_COLORS[cat] || '#BDBDBD' }}
                      />
                      <span style={{ color: '#2D1F2D' }}>{cat}</span>
                    </div>
                    <span style={{ color: '#7A5A73' }}>R$ {(amount / 100).toFixed(2)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
