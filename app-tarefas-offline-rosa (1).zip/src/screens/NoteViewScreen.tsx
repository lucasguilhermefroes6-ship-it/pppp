import { useState, useEffect } from 'react';
import { ArrowLeft, Edit2, Trash2, Clock, Tag, Calendar, Folder } from 'lucide-react';
import { Screen } from '@/types/screens';
import { useNotesStore, Note, getRelativeTime, CATEGORY_ICONS } from '@/store/useNotesStore';

interface NoteViewScreenProps {
  noteId: string;
  onNavigate: (screen: Screen) => void;
}

// Função para renderizar Markdown
function renderMarkdown(text: string): string {
  if (!text) return '';
  
  let html = text
    // Escape HTML first
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    // Headers
    .replace(/^### (.+)$/gm, '<h3 class="text-lg font-bold text-gray-800 mt-4 mb-2">$1</h3>')
    .replace(/^## (.+)$/gm, '<h2 class="text-xl font-bold text-gray-800 mt-4 mb-2">$1</h2>')
    .replace(/^# (.+)$/gm, '<h1 class="text-2xl font-bold text-gray-800 mt-4 mb-2">$1</h1>')
    // Bold
    .replace(/\*\*(.+?)\*\*/g, '<strong class="font-bold">$1</strong>')
    // Italic
    .replace(/_(.+?)_/g, '<em class="italic">$1</em>')
    // Strikethrough
    .replace(/~~(.+?)~~/g, '<del class="line-through">$1</del>')
    // Links
    .replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2" target="_blank" class="text-pink-500 underline">$1</a>')
    // Checkbox checked
    .replace(/- \[x\] (.+)/g, '<div class="flex items-center gap-2 my-1"><span class="text-green-500">☑️</span><span class="line-through text-gray-400">$1</span></div>')
    // Checkbox unchecked
    .replace(/- \[ \] (.+)/g, '<div class="flex items-center gap-2 my-1"><span class="text-gray-400">☐</span><span>$1</span></div>')
    // List items
    .replace(/^- (.+)$/gm, '<li class="ml-4 list-disc">$1</li>')
    // Numbered list
    .replace(/^\d+\. (.+)$/gm, '<li class="ml-4 list-decimal">$1</li>')
    // Line breaks
    .replace(/\n/g, '<br>');
  
  return html;
}

export default function NoteViewScreen({ noteId, onNavigate }: NoteViewScreenProps) {
  const { initialize, getNoteById, deleteNote } = useNotesStore();
  const [note, setNote] = useState<Note | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadNote = async () => {
      await initialize();
      const foundNote = getNoteById(noteId);
      setNote(foundNote || null);
      setIsLoading(false);
    };
    loadNote();
  }, [initialize, getNoteById, noteId]);

  const handleDelete = async () => {
    if (confirm('Tem certeza que deseja excluir esta anotação?')) {
      await deleteNote(noteId);
      onNavigate({ name: 'notes' });
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
      weekday: 'long',
      day: '2-digit',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#FFF5F8] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-pink-200 border-t-pink-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (!note) {
    return (
      <div className="min-h-screen bg-[#FFF5F8]">
        <div className="bg-gradient-to-r from-pink-400 to-pink-500 px-4 pt-12 pb-6">
          <div className="flex items-center gap-4">
            <button
              onClick={() => onNavigate({ name: 'notes' })}
              className="w-10 h-10 flex items-center justify-center rounded-full bg-white/20 text-white"
            >
              <ArrowLeft size={24} />
            </button>
            <h1 className="text-xl font-bold text-white font-poppins">Anotação</h1>
          </div>
        </div>
        <div className="px-4 py-8 text-center">
          <p className="text-gray-500 font-poppins">Anotação não encontrada</p>
          <button
            onClick={() => onNavigate({ name: 'notes' })}
            className="mt-4 px-6 py-2 bg-pink-500 text-white rounded-full font-poppins"
          >
            Voltar para lista
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FFF5F8]">
      {/* Header */}
      <div 
        className="px-4 pt-12 pb-6"
        style={{ 
          background: `linear-gradient(135deg, ${note.colorHex}dd, ${note.colorHex}99)` 
        }}
      >
        <div className="flex items-center justify-between">
          <button
            onClick={() => onNavigate({ name: 'notes' })}
            className="w-10 h-10 flex items-center justify-center rounded-full bg-white/20 text-white"
          >
            <ArrowLeft size={24} />
          </button>
          
          <div className="flex items-center gap-2">
            <button
              onClick={() => onNavigate({ name: 'note-edit', noteId: note.id })}
              className="w-10 h-10 flex items-center justify-center rounded-full bg-white/20 text-white"
            >
              <Edit2 size={20} />
            </button>
            <button
              onClick={handleDelete}
              className="w-10 h-10 flex items-center justify-center rounded-full bg-white/20 text-white"
            >
              <Trash2 size={20} />
            </button>
          </div>
        </div>

        {/* Title in header */}
        <h1 className="text-2xl font-bold text-white font-poppins mt-4">
          {note.title || 'Sem título'}
        </h1>
        
        {/* Category */}
        <div className="flex items-center gap-2 mt-3">
          <span className="inline-flex items-center gap-1 px-3 py-1 bg-white/20 text-white rounded-full text-sm font-medium font-poppins">
            {CATEGORY_ICONS[note.category as keyof typeof CATEGORY_ICONS]} {note.category}
          </span>
        </div>
      </div>

      <div className="px-4 py-4 space-y-4">
        {/* Meta info */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
          <div className="flex flex-wrap gap-4 text-sm text-gray-500 font-poppins">
            <div className="flex items-center gap-2">
              <Calendar size={16} className="text-pink-400" />
              <span>Criado: {formatDate(note.createdAt)}</span>
            </div>
            {note.updatedAt !== note.createdAt && (
              <div className="flex items-center gap-2">
                <Clock size={16} className="text-pink-400" />
                <span>Editado: {getRelativeTime(note.updatedAt)}</span>
              </div>
            )}
          </div>
        </div>

        {/* Tags */}
        {note.tags.length > 0 && (
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
            <h3 className="text-sm font-semibold text-gray-700 font-poppins mb-3 flex items-center gap-2">
              <Tag size={16} className="text-pink-400" />
              Tags
            </h3>
            <div className="flex flex-wrap gap-2">
              {note.tags.map((tag, index) => (
                <span
                  key={index}
                  className="px-3 py-1 bg-pink-100 text-pink-600 rounded-full text-sm font-poppins"
                >
                  #{tag}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Content */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
          <h3 className="text-sm font-semibold text-gray-700 font-poppins mb-3 flex items-center gap-2">
            <Folder size={16} className="text-pink-400" />
            Conteúdo
          </h3>
          
          {note.content ? (
            <div 
              className="prose prose-sm max-w-none text-gray-700 font-poppins leading-relaxed"
              dangerouslySetInnerHTML={{ __html: renderMarkdown(note.content) }}
            />
          ) : (
            <p className="text-gray-400 italic font-poppins">Sem conteúdo</p>
          )}
        </div>

        {/* Edit Button */}
        <button
          onClick={() => onNavigate({ name: 'note-edit', noteId: note.id })}
          className="w-full py-4 bg-gradient-to-r from-pink-500 to-pink-600 text-white rounded-2xl font-poppins font-semibold flex items-center justify-center gap-2 shadow-lg"
        >
          <Edit2 size={20} />
          Editar Anotação
        </button>
      </div>
    </div>
  );
}
