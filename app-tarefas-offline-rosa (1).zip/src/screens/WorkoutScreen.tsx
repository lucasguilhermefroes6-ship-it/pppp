import { useState, useEffect } from 'react';
import { 
  ArrowLeft, Dumbbell, X, Clock, Flame, Calendar,
  TrendingUp, Check, ChevronRight, Zap, Heart
} from 'lucide-react';
import { Screen } from '@/types/screens';
import { 
  useWorkoutStore, 
  WorkoutIntensity, 
  WorkoutType,
  WorkoutDay,
  intensityLabels,
  workoutTypeLabels,
  workoutTypeConfig,
  intensityConfig
} from '@/store/useWorkoutStore';

interface WorkoutScreenProps {
  onNavigate: (screen: Screen) => void;
}

export default function WorkoutScreen({ onNavigate }: WorkoutScreenProps) {
  const { 
    initialize, 
    saveWorkout, 
    getTodayWorkout,
    getWorkoutByDate,
    getTodayLabel,
    getWeekStats
  } = useWorkoutStore();
  
  const [showModal, setShowModal] = useState(false);
  const [editingDate, setEditingDate] = useState<string | null>(null);
  
  useEffect(() => {
    initialize();
  }, [initialize]);
  
  const todayWorkout = getTodayWorkout();
  const weekStats = getWeekStats();
  const todayLabel = getTodayLabel();
  
  // Get last 14 days
  const getLast14Days = () => {
    const days = [];
    for (let i = 0; i < 14; i++) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateKey = date.toISOString().split('T')[0];
      const workout = getWorkoutByDate(dateKey);
      days.push({
        dateKey,
        date,
        workout
      });
    }
    return days;
  };
  
  const formatDate = (date: Date) => {
    return date.toLocaleDateString('pt-BR', { weekday: 'short', day: '2-digit', month: '2-digit' });
  };
  
  const openModal = (dateKey?: string) => {
    setEditingDate(dateKey || new Date().toISOString().split('T')[0]);
    setShowModal(true);
  };
  
  const last14Days = getLast14Days();
  
  return (
    <div className="min-h-screen bg-[#FFF5F8]">
      {/* Header */}
      <div className="bg-gradient-to-br from-purple-400 via-pink-400 to-rose-400 text-white">
        <div className="p-4">
          <div className="flex items-center gap-3 mb-6">
            <button
              onClick={() => onNavigate({ name: 'home' })}
              className="p-2 hover:bg-white/20 rounded-full transition-colors"
            >
              <ArrowLeft size={24} />
            </button>
            <div>
              <h1 className="text-2xl font-bold font-poppins">Treino</h1>
              <p className="text-white/80 text-sm">Registre seus exercícios</p>
            </div>
          </div>
          
          {/* Today Summary */}
          <div className="bg-white/20 backdrop-blur-sm rounded-3xl p-5 mb-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/80 text-sm mb-1">Hoje</p>
                <p className="text-2xl font-bold">{todayLabel}</p>
              </div>
              <div className="w-16 h-16 rounded-full bg-white/30 flex items-center justify-center">
                {todayWorkout && todayWorkout.intensity !== 'NONE' ? (
                  <span className="text-3xl">{intensityConfig[todayWorkout.intensity].emoji}</span>
                ) : (
                  <Dumbbell size={32} className="text-white/60" />
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="p-4 -mt-2">
        {/* Stats Row */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
            <div className="w-10 h-10 rounded-xl bg-orange-100 flex items-center justify-center mb-2">
              <Flame size={20} className="text-orange-500" />
            </div>
            <p className="text-2xl font-bold text-gray-800">{weekStats.streak}</p>
            <p className="text-xs text-gray-500">Sequência</p>
          </div>
          
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
            <div className="w-10 h-10 rounded-xl bg-purple-100 flex items-center justify-center mb-2">
              <Zap size={20} className="text-purple-500" />
            </div>
            <p className="text-2xl font-bold text-gray-800">{weekStats.totalWorkouts}</p>
            <p className="text-xs text-gray-500">Esta semana</p>
          </div>
          
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-pink-100">
            <div className="w-10 h-10 rounded-xl bg-pink-100 flex items-center justify-center mb-2">
              <Clock size={20} className="text-pink-500" />
            </div>
            <p className="text-2xl font-bold text-gray-800">{weekStats.totalMinutes}</p>
            <p className="text-xs text-gray-500">Minutos</p>
          </div>
        </div>
        
        {/* Register Button */}
        <button
          onClick={() => openModal()}
          className="w-full bg-gradient-to-r from-pink-500 to-rose-500 text-white py-4 px-6 rounded-2xl font-semibold shadow-lg shadow-pink-200 flex items-center justify-center gap-3 mb-6 hover:shadow-xl transition-shadow"
        >
          <Dumbbell size={24} />
          Registrar Treino de Hoje
        </button>
        
        {/* Week Chart */}
        <div className="bg-white rounded-3xl p-5 shadow-sm border border-pink-100 mb-6">
          <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <TrendingUp size={18} className="text-pink-500" />
            Últimos 7 dias
          </h3>
          <div className="flex justify-between gap-2">
            {last14Days.slice(0, 7).reverse().map((day) => {
              const hasWorkout = day.workout && day.workout.intensity !== 'NONE';
              const intensity = day.workout?.intensity || 'NONE';
              const config = intensityConfig[intensity];
              const isToday = day.dateKey === new Date().toISOString().split('T')[0];
              
              return (
                <div 
                  key={day.dateKey} 
                  className="flex-1 flex flex-col items-center"
                  onClick={() => openModal(day.dateKey)}
                >
                  <div 
                    className={`w-10 h-10 rounded-xl flex items-center justify-center mb-2 cursor-pointer transition-all hover:scale-110 ${
                      hasWorkout 
                        ? `bg-gradient-to-br ${config.gradient}` 
                        : 'bg-gray-100'
                    } ${isToday ? 'ring-2 ring-pink-500 ring-offset-2' : ''}`}
                  >
                    {hasWorkout ? (
                      <span className="text-lg">{config.emoji}</span>
                    ) : (
                      <span className="text-gray-300 text-lg">•</span>
                    )}
                  </div>
                  <p className={`text-xs ${isToday ? 'text-pink-600 font-bold' : 'text-gray-500'}`}>
                    {day.date.toLocaleDateString('pt-BR', { weekday: 'short' }).replace('.', '')}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
        
        {/* History */}
        <div className="bg-white rounded-3xl p-5 shadow-sm border border-pink-100">
          <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <Calendar size={18} className="text-pink-500" />
            Histórico
          </h3>
          
          <div className="space-y-2">
            {last14Days.map((day) => {
              const hasWorkout = day.workout && day.workout.intensity !== 'NONE';
              const intensity = day.workout?.intensity || 'NONE';
              const types = day.workout?.workoutTypes?.filter(t => t !== 'NONE') || [];
              const config = intensityConfig[intensity];
              const isToday = day.dateKey === new Date().toISOString().split('T')[0];
              
              return (
                <button
                  key={day.dateKey}
                  onClick={() => openModal(day.dateKey)}
                  className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-pink-50 transition-colors text-left"
                >
                  <div 
                    className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      hasWorkout 
                        ? `bg-gradient-to-br ${config.gradient}` 
                        : 'bg-gray-100'
                    }`}
                  >
                    {hasWorkout ? (
                      <span className="text-xl">{config.emoji}</span>
                    ) : (
                      <Dumbbell size={20} className="text-gray-300" />
                    )}
                  </div>
                  
                  <div className="flex-1">
                    <p className={`font-medium ${isToday ? 'text-pink-600' : 'text-gray-800'}`}>
                      {isToday ? 'Hoje' : formatDate(day.date)}
                    </p>
                    <p className="text-sm text-gray-500">
                      {hasWorkout ? (
                        <>
                          {types.map(t => workoutTypeLabels[t]).join(', ') || 'Exercício'} • {intensityLabels[intensity]}
                          {day.workout?.duration && ` • ${day.workout.duration}min`}
                        </>
                      ) : (
                        'Nenhum treino registrado'
                      )}
                    </p>
                  </div>
                  
                  <ChevronRight size={20} className="text-gray-400" />
                </button>
              );
            })}
          </div>
        </div>
        
        {/* Tips */}
        <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-3xl p-5 mt-6 border border-pink-100">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-pink-100 flex items-center justify-center flex-shrink-0">
              <Heart size={18} className="text-pink-500" />
            </div>
            <div>
              <h4 className="font-semibold text-gray-800 mb-1">Dica do dia 💪</h4>
              <p className="text-sm text-gray-600">
                Lembre-se: consistência é mais importante que intensidade. Mesmo um treino leve conta!
              </p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Modal */}
      {showModal && editingDate && (
        <WorkoutModal
          dateKey={editingDate}
          onClose={() => setShowModal(false)}
          onSave={saveWorkout}
          existingWorkout={getWorkoutByDate(editingDate)}
        />
      )}
    </div>
  );
}

// Workout Modal Component
interface WorkoutModalProps {
  dateKey: string;
  onClose: () => void;
  onSave: (workout: any) => Promise<void>;
  existingWorkout: WorkoutDay | null;
}

function WorkoutModal({ dateKey, onClose, onSave, existingWorkout }: WorkoutModalProps) {
  const [intensity, setIntensity] = useState<WorkoutIntensity>(existingWorkout?.intensity || 'NONE');
  const [selectedTypes, setSelectedTypes] = useState<WorkoutType[]>(existingWorkout?.workoutTypes || []);
  const [duration, setDuration] = useState(existingWorkout?.duration || 30);
  const [notes, setNotes] = useState(existingWorkout?.notes || '');
  
  const isToday = dateKey === new Date().toISOString().split('T')[0];
  const date = new Date(dateKey + 'T12:00:00');
  
  const toggleType = (type: WorkoutType) => {
    if (type === 'NONE') {
      setSelectedTypes([]);
      return;
    }
    
    if (selectedTypes.includes(type)) {
      setSelectedTypes(selectedTypes.filter(t => t !== type));
    } else {
      setSelectedTypes([...selectedTypes.filter(t => t !== 'NONE'), type]);
    }
  };
  
  const handleSave = async () => {
    await onSave({
      dateKey,
      intensity,
      workoutTypes: intensity === 'NONE' ? ['NONE'] : selectedTypes.length > 0 ? selectedTypes : ['OTHER'],
      duration: intensity === 'NONE' ? 0 : duration,
      notes
    });
    onClose();
  };
  
  const intensityOptions: WorkoutIntensity[] = ['NONE', 'LIGHT', 'MEDIUM', 'INTENSE'];
  const workoutTypes: WorkoutType[] = ['CARDIO', 'STRENGTH', 'YOGA', 'STRETCHING', 'FUNCTIONAL', 'HIIT', 'DANCE', 'OTHER'];
  
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
      <div 
        className="bg-[#FFF5F8] w-full rounded-t-3xl max-h-[90vh] overflow-hidden flex flex-col animate-slide-up"
        style={{ animation: 'slideUp 0.3s ease-out' }}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-pink-200 to-rose-200 p-5 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-rose-900 font-poppins">
              {isToday ? 'Treino de Hoje' : 'Editar Treino'} 🏋️‍♀️
            </h2>
            <p className="text-rose-700 text-sm">
              {date.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' })}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/30 rounded-full transition-colors"
          >
            <X size={24} className="text-rose-900" />
          </button>
        </div>
        
        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5">
          {/* Intensity Section */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-3 text-center">
              Como foi seu treino? Selecione a intensidade:
            </h3>
            
            <div className="grid grid-cols-2 gap-3">
              {intensityOptions.map((opt) => {
                const config = intensityConfig[opt];
                const isSelected = intensity === opt;
                
                return (
                  <button
                    key={opt}
                    onClick={() => setIntensity(opt)}
                    className={`p-5 rounded-2xl border-2 transition-all ${
                      isSelected
                        ? `bg-gradient-to-br ${config.gradient} border-transparent shadow-lg`
                        : 'bg-white border-pink-200 hover:border-pink-300'
                    }`}
                  >
                    <div className="text-center">
                      <span className="text-4xl block mb-2">{config.emoji}</span>
                      <p className={`font-semibold ${isSelected ? 'text-white' : 'text-gray-800'}`}>
                        {intensityLabels[opt]}
                      </p>
                    </div>
                    {isSelected && (
                      <div className="absolute top-2 right-2 w-6 h-6 bg-white rounded-full flex items-center justify-center">
                        <Check size={14} className="text-pink-500" />
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
          
          {/* Workout Types Section */}
          {intensity !== 'NONE' && (
            <>
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-3">
                  Tipo de treino
                  <span className="text-sm font-normal text-gray-500 ml-2">(pode marcar vários)</span>
                </h3>
                
                <div className="flex flex-wrap gap-2">
                  {workoutTypes.map((type) => {
                    const config = workoutTypeConfig[type];
                    const isSelected = selectedTypes.includes(type);
                    
                    return (
                      <button
                        key={type}
                        onClick={() => toggleType(type)}
                        className={`px-4 py-3 rounded-2xl border-2 transition-all flex items-center gap-2 ${
                          isSelected
                            ? 'bg-pink-500 border-pink-500 text-white shadow-lg'
                            : 'bg-white border-pink-200 text-gray-700 hover:border-pink-300'
                        }`}
                      >
                        <span className="text-lg">{config.emoji}</span>
                        <span className="font-medium">{workoutTypeLabels[type]}</span>
                        {isSelected && <Check size={16} />}
                      </button>
                    );
                  })}
                </div>
              </div>
              
              {/* Duration */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-3">
                  Duração
                </h3>
                
                <div className="bg-white rounded-2xl p-4 border border-pink-100">
                  <div className="flex items-center justify-between mb-3">
                    <button
                      onClick={() => setDuration(Math.max(5, duration - 5))}
                      className="w-12 h-12 rounded-full bg-pink-100 text-pink-600 font-bold text-xl hover:bg-pink-200 transition-colors"
                    >
                      -
                    </button>
                    <div className="text-center">
                      <span className="text-4xl font-bold text-pink-600">{duration}</span>
                      <span className="text-lg text-gray-500 ml-1">min</span>
                    </div>
                    <button
                      onClick={() => setDuration(Math.min(180, duration + 5))}
                      className="w-12 h-12 rounded-full bg-pink-100 text-pink-600 font-bold text-xl hover:bg-pink-200 transition-colors"
                    >
                      +
                    </button>
                  </div>
                  
                  <div className="flex gap-2 justify-center">
                    {[15, 30, 45, 60, 90].map((min) => (
                      <button
                        key={min}
                        onClick={() => setDuration(min)}
                        className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                          duration === min
                            ? 'bg-pink-500 text-white'
                            : 'bg-pink-100 text-pink-600 hover:bg-pink-200'
                        }`}
                      >
                        {min}min
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </>
          )}
          
          {/* Notes */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-3">
              Observações <span className="text-sm font-normal text-gray-500">(opcional)</span>
            </h3>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Como você se sentiu? Alguma observação?"
              className="w-full bg-white border border-pink-200 rounded-2xl p-4 text-gray-700 placeholder:text-gray-400 focus:ring-2 focus:ring-pink-300 focus:border-pink-300 transition-all resize-none"
              rows={3}
            />
          </div>
        </div>
        
        {/* Save Button */}
        <div className="p-5 bg-white border-t border-pink-100">
          <button
            onClick={handleSave}
            className="w-full bg-gradient-to-r from-pink-500 to-rose-500 text-white py-4 rounded-2xl font-semibold shadow-lg shadow-pink-200 flex items-center justify-center gap-2"
          >
            <Check size={20} />
            Salvar Treino
          </button>
        </div>
      </div>
      
      <style>{`
        @keyframes slideUp {
          from {
            transform: translateY(100%);
          }
          to {
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}
