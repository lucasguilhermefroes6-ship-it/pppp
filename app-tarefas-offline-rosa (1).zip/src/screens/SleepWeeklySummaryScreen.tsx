import { useState, useEffect } from 'react';
import { Screen } from '../types/screens';

// Cores do app
const COLORS = {
  primary: '#FF2D95',
  primaryLight: '#FF6EB5',
  primarySoft: '#FFD6EC',
  background: '#FFF3FA',
  surface: '#FFFFFF',
  border: '#F5D0DC',
  textPrimary: '#3D2B3D',
  textSecondary: '#8B7A8B',
  success: '#4CAF50',
  warning: '#FF9800',
  purple: '#9C27B0',
  purpleLight: '#E1BEE7',
};

interface SleepEntry {
  id: string;
  date: string;
  sleepTime: string;
  wakeTime: string;
  durationMinutes: number;
  quality: 'bad' | 'ok' | 'good' | 'great';
  notes?: string;
}

interface Props {
  setScreen: (screen: Screen) => void;
}

// Carregar dados do localStorage
const loadSleepEntries = (): SleepEntry[] => {
  try {
    const data = localStorage.getItem('vida-rosa-sleep-entries');
    console.log('[SleepWeeklySummary] Loaded from localStorage:', data);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    console.error('[SleepWeeklySummary] Error loading:', e);
    return [];
  }
};

// Carregar meta de sono
const loadIdealHours = (): number => {
  try {
    const data = localStorage.getItem('vida-rosa-sleep-settings');
    const settings = data ? JSON.parse(data) : { idealHours: 8 };
    return settings.idealHours || 8;
  } catch {
    return 8;
  }
};

// Helpers de data
const getWeekStart = (date: Date): Date => {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1); // Segunda-feira
  d.setDate(diff);
  d.setHours(0, 0, 0, 0);
  return d;
};

const getWeekEnd = (weekStart: Date): Date => {
  const d = new Date(weekStart);
  d.setDate(d.getDate() + 6);
  d.setHours(23, 59, 59, 999);
  return d;
};

const formatDate = (date: Date): string => {
  return date.toISOString().split('T')[0];
};

const formatDateShort = (date: Date): string => {
  return date.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' }).replace('.', '');
};

const formatDuration = (minutes: number): string => {
  if (minutes <= 0) return '0h00';
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return `${hours}h${mins.toString().padStart(2, '0')}`;
};

const DAY_NAMES = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];

const QUALITY_MAP: Record<string, { label: string; emoji: string; value: number; color: string }> = {
  'bad': { label: 'Ruim', emoji: '😴', value: 1, color: '#F44336' },
  'ok': { label: 'Ok', emoji: '😐', value: 2, color: '#FF9800' },
  'good': { label: 'Bom', emoji: '😊', value: 3, color: '#8BC34A' },
  'great': { label: 'Ótimo', emoji: '🌟', value: 4, color: '#4CAF50' },
};

export default function SleepWeeklySummaryScreen({ setScreen }: Props) {
  const [weekOffset, setWeekOffset] = useState(0);
  const [entries, setEntries] = useState<SleepEntry[]>([]);
  const [idealHours, setIdealHours] = useState(8);
  const [showHistory, setShowHistory] = useState(false);

  // Carregar dados
  useEffect(() => {
    const loadedEntries = loadSleepEntries();
    const loadedIdealHours = loadIdealHours();
    console.log('[SleepWeeklySummary] Entries loaded:', loadedEntries.length, loadedEntries);
    console.log('[SleepWeeklySummary] Ideal hours:', loadedIdealHours);
    setEntries(loadedEntries);
    setIdealHours(loadedIdealHours);
  }, []);

  // Calcular datas da semana
  const today = new Date();
  const currentWeekStart = getWeekStart(today);
  const selectedWeekStart = new Date(currentWeekStart);
  selectedWeekStart.setDate(selectedWeekStart.getDate() + (weekOffset * 7));
  const selectedWeekEnd = getWeekEnd(selectedWeekStart);

  // Filtrar entradas da semana selecionada
  const weekEntries: (SleepEntry | null)[] = [];
  for (let i = 0; i < 7; i++) {
    const date = new Date(selectedWeekStart);
    date.setDate(date.getDate() + i);
    const dateKey = formatDate(date);
    const entry = entries.find(e => e.date === dateKey) || null;
    weekEntries.push(entry);
  }

  console.log('[SleepWeeklySummary] Week entries:', weekEntries);

  // Calcular métricas
  const entriesWithData = weekEntries.filter((e): e is SleepEntry => e !== null);
  const nightsCount = entriesWithData.length;

  // Média de duração (apenas dias com registro)
  const avgDurationMinutes = nightsCount > 0
    ? Math.round(entriesWithData.reduce((sum, e) => sum + e.durationMinutes, 0) / nightsCount)
    : 0;

  // Meta em minutos
  const idealMinutes = idealHours * 60;

  // Débito/Superávit (baseado apenas nos dias com registro)
  const totalSlept = entriesWithData.reduce((sum, e) => sum + e.durationMinutes, 0);
  const totalIdeal = nightsCount * idealMinutes;
  const debtMinutes = totalSlept - totalIdeal;

  // Quantas noites atingiram a meta
  const metGoalCount = entriesWithData.filter(e => e.durationMinutes >= idealMinutes).length;

  // Qualidade média
  const avgQuality = nightsCount > 0
    ? entriesWithData.reduce((sum, e) => sum + (QUALITY_MAP[e.quality]?.value || 0), 0) / nightsCount
    : 0;

  // Distribuição de qualidade
  const qualityDistribution = {
    bad: entriesWithData.filter(e => e.quality === 'bad').length,
    ok: entriesWithData.filter(e => e.quality === 'ok').length,
    good: entriesWithData.filter(e => e.quality === 'good').length,
    great: entriesWithData.filter(e => e.quality === 'great').length,
  };

  // Horário médio de dormir e acordar
  const avgSleepTime = nightsCount > 0
    ? (() => {
        const totalMinutes = entriesWithData.reduce((sum, e) => {
          const [h, m] = e.sleepTime.split(':').map(Number);
          let mins = h * 60 + m;
          if (mins < 12 * 60) mins += 24 * 60; // Ajustar para depois da meia-noite
          return sum + mins;
        }, 0);
        const avg = Math.round(totalMinutes / nightsCount);
        const hours = Math.floor(avg / 60) % 24;
        const mins = avg % 60;
        return `${hours.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}`;
      })()
    : '--:--';

  const avgWakeTime = nightsCount > 0
    ? (() => {
        const totalMinutes = entriesWithData.reduce((sum, e) => {
          const [h, m] = e.wakeTime.split(':').map(Number);
          return sum + h * 60 + m;
        }, 0);
        const avg = Math.round(totalMinutes / nightsCount);
        const hours = Math.floor(avg / 60);
        const mins = avg % 60;
        return `${hours.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}`;
      })()
    : '--:--';

  // Melhor e pior noite
  const bestNight = entriesWithData.length > 0
    ? entriesWithData.reduce((best, e) => e.durationMinutes > best.durationMinutes ? e : best)
    : null;
  const worstNight = entriesWithData.length > 0
    ? entriesWithData.reduce((worst, e) => e.durationMinutes < worst.durationMinutes ? e : worst)
    : null;

  // Consistência (desvio padrão do horário de dormir)
  const consistency = nightsCount > 1
    ? (() => {
        const sleepTimes = entriesWithData.map(e => {
          const [h, m] = e.sleepTime.split(':').map(Number);
          let mins = h * 60 + m;
          if (mins < 12 * 60) mins += 24 * 60;
          return mins;
        });
        const mean = sleepTimes.reduce((a, b) => a + b, 0) / sleepTimes.length;
        const variance = sleepTimes.reduce((sum, t) => sum + Math.pow(t - mean, 2), 0) / sleepTimes.length;
        const stdDev = Math.sqrt(variance);
        return stdDev < 30 ? 'Excelente' : stdDev < 60 ? 'Boa' : stdDev < 90 ? 'Regular' : 'Irregular';
      })()
    : 'N/A';

  // Insights
  const insights: string[] = [];
  if (nightsCount > 0) {
    insights.push(`Você bateu sua meta em ${metGoalCount} de ${nightsCount} noites`);
    if (bestNight) {
      const bestDate = new Date(bestNight.date);
      insights.push(`Melhor noite: ${bestDate.toLocaleDateString('pt-BR', { weekday: 'long' })} com ${formatDuration(bestNight.durationMinutes)}`);
    }
    if (worstNight && worstNight !== bestNight) {
      const worstDate = new Date(worstNight.date);
      insights.push(`Menor sono: ${worstDate.toLocaleDateString('pt-BR', { weekday: 'long' })} com ${formatDuration(worstNight.durationMinutes)}`);
    }
    insights.push(`Horário médio de dormir: ${avgSleepTime}`);
    insights.push(`Horário médio de acordar: ${avgWakeTime}`);
  } else {
    insights.push('Nenhum registro de sono nesta semana');
    insights.push('Registre suas noites de sono para ver insights');
  }

  // Determinar cor da barra baseado na meta
  const getBarColor = (minutes: number): string => {
    if (minutes >= idealMinutes) return COLORS.success;
    if (minutes >= idealMinutes * 0.8) return COLORS.purple;
    return COLORS.warning;
  };

  // Máximo para escala do gráfico
  const maxMinutes = Math.max(...entriesWithData.map(e => e.durationMinutes), idealMinutes);

  return (
    <div className="min-h-screen" style={{ background: COLORS.background }}>
      {/* Header */}
      <div 
        className="px-4 pt-6 pb-8"
        style={{ 
          background: `linear-gradient(135deg, ${COLORS.purple} 0%, ${COLORS.primary} 100%)`,
        }}
      >
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() => setScreen({ name: 'home' })}
            className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center"
          >
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <h1 className="text-xl font-bold text-white">Resumo do Sono</h1>
          <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
            <span className="text-2xl">🌙</span>
          </div>
        </div>

        {/* Seletor de Semana */}
        <div className="flex items-center justify-center gap-4 bg-white/10 rounded-2xl p-3">
          <button
            onClick={() => setWeekOffset(weekOffset - 1)}
            className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center hover:bg-white/30 transition-colors"
          >
            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <div className="text-center text-white">
            <p className="text-sm opacity-80">Semana</p>
            <p className="font-semibold">
              {formatDateShort(selectedWeekStart)} – {formatDateShort(selectedWeekEnd)}
            </p>
          </div>
          <button
            onClick={() => weekOffset < 0 && setWeekOffset(weekOffset + 1)}
            disabled={weekOffset >= 0}
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
              weekOffset >= 0 ? 'bg-white/5 opacity-50' : 'bg-white/20 hover:bg-white/30'
            }`}
          >
            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="px-4 -mt-4 pb-6 space-y-4">
        {/* KPI Cards */}
        <div className="grid grid-cols-2 gap-3">
          {/* Média por Noite */}
          <div 
            className="rounded-2xl p-4"
            style={{ 
              background: COLORS.surface, 
              border: `1.5px solid ${COLORS.border}`,
              boxShadow: '0 2px 8px rgba(0,0,0,0.04)'
            }}
          >
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: COLORS.purpleLight }}>
                <span className="text-lg">⏱️</span>
              </div>
              <span className="text-sm" style={{ color: COLORS.textSecondary }}>Média/noite</span>
            </div>
            <p className="text-2xl font-bold" style={{ color: COLORS.purple }}>
              {formatDuration(avgDurationMinutes)}
            </p>
          </div>

          {/* Meta */}
          <div 
            className="rounded-2xl p-4"
            style={{ 
              background: COLORS.surface, 
              border: `1.5px solid ${COLORS.border}`,
              boxShadow: '0 2px 8px rgba(0,0,0,0.04)'
            }}
          >
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: COLORS.primarySoft }}>
                <span className="text-lg">🎯</span>
              </div>
              <span className="text-sm" style={{ color: COLORS.textSecondary }}>Meta ideal</span>
            </div>
            <p className="text-2xl font-bold" style={{ color: COLORS.primary }}>
              {idealHours}h00
            </p>
          </div>

          {/* Débito/Superávit */}
          <div 
            className="rounded-2xl p-4"
            style={{ 
              background: COLORS.surface, 
              border: `1.5px solid ${COLORS.border}`,
              boxShadow: '0 2px 8px rgba(0,0,0,0.04)'
            }}
          >
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: debtMinutes >= 0 ? '#C8E6C9' : '#FFCDD2' }}>
                <span className="text-lg">{debtMinutes >= 0 ? '✅' : '⚠️'}</span>
              </div>
              <span className="text-sm" style={{ color: COLORS.textSecondary }}>
                {debtMinutes >= 0 ? 'Superávit' : 'Débito'}
              </span>
            </div>
            <p className="text-2xl font-bold" style={{ color: debtMinutes >= 0 ? COLORS.success : COLORS.warning }}>
              {debtMinutes >= 0 ? '+' : ''}{formatDuration(Math.abs(debtMinutes))}
            </p>
          </div>

          {/* Consistência */}
          <div 
            className="rounded-2xl p-4"
            style={{ 
              background: COLORS.surface, 
              border: `1.5px solid ${COLORS.border}`,
              boxShadow: '0 2px 8px rgba(0,0,0,0.04)'
            }}
          >
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: '#E3F2FD' }}>
                <span className="text-lg">📊</span>
              </div>
              <span className="text-sm" style={{ color: COLORS.textSecondary }}>Consistência</span>
            </div>
            <p className="text-2xl font-bold" style={{ color: '#2196F3' }}>
              {consistency}
            </p>
          </div>
        </div>

        {/* Gráfico de Barras */}
        <div 
          className="rounded-2xl p-4"
          style={{ 
            background: COLORS.surface, 
            border: `1.5px solid ${COLORS.border}`,
            boxShadow: '0 2px 8px rgba(0,0,0,0.04)'
          }}
        >
          <h3 className="font-semibold mb-4" style={{ color: COLORS.textPrimary }}>
            Horas de Sono por Dia
          </h3>
          <div className="space-y-3">
            {weekEntries.map((entry, index) => {
              const date = new Date(selectedWeekStart);
              date.setDate(date.getDate() + index);
              const isToday = formatDate(date) === formatDate(new Date());
              const duration = entry?.durationMinutes || 0;
              const percentage = maxMinutes > 0 ? (duration / maxMinutes) * 100 : 0;
              const barColor = duration > 0 ? getBarColor(duration) : '#E0E0E0';

              return (
                <div key={index} className="flex items-center gap-3">
                  <div className="w-12 flex-shrink-0">
                    <span 
                      className={`text-sm font-medium ${isToday ? 'text-pink-500' : ''}`}
                      style={{ color: isToday ? COLORS.primary : COLORS.textSecondary }}
                    >
                      {DAY_NAMES[index]}
                    </span>
                  </div>
                  <div className="flex-1 h-8 bg-gray-100 rounded-lg overflow-hidden relative">
                    <div
                      className="h-full rounded-lg transition-all duration-500"
                      style={{
                        width: `${percentage}%`,
                        background: duration > 0 
                          ? `linear-gradient(90deg, ${barColor}DD, ${barColor})` 
                          : 'transparent',
                        minWidth: duration > 0 ? '4px' : '0',
                      }}
                    />
                    {/* Linha da meta */}
                    <div 
                      className="absolute top-0 h-full w-0.5 bg-pink-400"
                      style={{ left: `${(idealMinutes / maxMinutes) * 100}%` }}
                    />
                  </div>
                  <div className="w-16 text-right">
                    <span 
                      className="text-sm font-semibold"
                      style={{ color: duration > 0 ? barColor : COLORS.textSecondary }}
                    >
                      {duration > 0 ? formatDuration(duration) : '—'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
          <div className="flex items-center justify-center gap-4 mt-4 pt-3 border-t" style={{ borderColor: COLORS.border }}>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full" style={{ background: COLORS.success }} />
              <span className="text-xs" style={{ color: COLORS.textSecondary }}>Atingiu meta</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full" style={{ background: COLORS.purple }} />
              <span className="text-xs" style={{ color: COLORS.textSecondary }}>Quase lá</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full" style={{ background: COLORS.warning }} />
              <span className="text-xs" style={{ color: COLORS.textSecondary }}>Pouco sono</span>
            </div>
          </div>
        </div>

        {/* Qualidade do Sono */}
        <div 
          className="rounded-2xl p-4"
          style={{ 
            background: COLORS.surface, 
            border: `1.5px solid ${COLORS.border}`,
            boxShadow: '0 2px 8px rgba(0,0,0,0.04)'
          }}
        >
          <h3 className="font-semibold mb-4" style={{ color: COLORS.textPrimary }}>
            Qualidade do Sono
          </h3>
          <div className="grid grid-cols-4 gap-2 mb-4">
            {Object.entries(QUALITY_MAP).map(([key, { label, emoji, color }]) => (
              <div 
                key={key}
                className="rounded-xl p-3 text-center"
                style={{ background: `${color}15` }}
              >
                <span className="text-2xl block mb-1">{emoji}</span>
                <span className="text-xs font-medium" style={{ color }}>{label}</span>
                <p className="text-lg font-bold mt-1" style={{ color }}>
                  {qualityDistribution[key as keyof typeof qualityDistribution]}
                </p>
              </div>
            ))}
          </div>
          <div className="flex items-center justify-between p-3 rounded-xl" style={{ background: COLORS.primarySoft }}>
            <span style={{ color: COLORS.textPrimary }}>Qualidade média:</span>
            <span className="font-bold" style={{ color: COLORS.primary }}>
              {nightsCount > 0 ? avgQuality.toFixed(1) + ' / 4.0' : 'N/A'}
            </span>
          </div>
        </div>

        {/* Insights */}
        <div 
          className="rounded-2xl p-4"
          style={{ 
            background: COLORS.surface, 
            border: `1.5px solid ${COLORS.border}`,
            boxShadow: '0 2px 8px rgba(0,0,0,0.04)'
          }}
        >
          <h3 className="font-semibold mb-4 flex items-center gap-2" style={{ color: COLORS.textPrimary }}>
            <span>💡</span> Insights da Semana
          </h3>
          <div className="space-y-3">
            {insights.map((insight, index) => (
              <div 
                key={index}
                className="flex items-start gap-3 p-3 rounded-xl"
                style={{ background: COLORS.background }}
              >
                <div className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: COLORS.primarySoft }}>
                  <span className="text-xs" style={{ color: COLORS.primary }}>✓</span>
                </div>
                <p className="text-sm" style={{ color: COLORS.textPrimary }}>{insight}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Botão Ver Histórico */}
        <button
          onClick={() => setShowHistory(!showHistory)}
          className="w-full py-4 rounded-2xl font-semibold flex items-center justify-center gap-2"
          style={{ 
            background: `linear-gradient(135deg, ${COLORS.purple} 0%, ${COLORS.primary} 100%)`,
            color: 'white'
          }}
        >
          <span>📋</span>
          {showHistory ? 'Ocultar Histórico' : 'Ver Histórico do Sono'}
        </button>

        {/* Histórico */}
        {showHistory && (
          <div 
            className="rounded-2xl p-4"
            style={{ 
              background: COLORS.surface, 
              border: `1.5px solid ${COLORS.border}`,
              boxShadow: '0 2px 8px rgba(0,0,0,0.04)'
            }}
          >
            <h3 className="font-semibold mb-4" style={{ color: COLORS.textPrimary }}>
              Histórico Completo
            </h3>
            {entries.length === 0 ? (
              <p className="text-center py-8" style={{ color: COLORS.textSecondary }}>
                Nenhum registro encontrado
              </p>
            ) : (
              <div className="space-y-2 max-h-80 overflow-y-auto">
                {entries.slice(0, 30).map((entry) => {
                  const date = new Date(entry.date);
                  const quality = QUALITY_MAP[entry.quality];
                  return (
                    <div 
                      key={entry.id}
                      className="flex items-center justify-between p-3 rounded-xl"
                      style={{ background: COLORS.background }}
                    >
                      <div>
                        <p className="font-medium" style={{ color: COLORS.textPrimary }}>
                          {date.toLocaleDateString('pt-BR', { weekday: 'short', day: '2-digit', month: 'short' })}
                        </p>
                        <p className="text-xs" style={{ color: COLORS.textSecondary }}>
                          {entry.sleepTime} → {entry.wakeTime}
                        </p>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-xl">{quality?.emoji}</span>
                        <span 
                          className="font-bold"
                          style={{ color: getBarColor(entry.durationMinutes) }}
                        >
                          {formatDuration(entry.durationMinutes)}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Espaço no final */}
        <div className="h-4" />
      </div>
    </div>
  );
}
