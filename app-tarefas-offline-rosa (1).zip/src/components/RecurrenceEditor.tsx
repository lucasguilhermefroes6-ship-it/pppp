import { useState, useEffect } from 'react';
import {
  RecurrenceRule,
  RecurrenceType,
  MonthlyMode,
  EndMode,
  Weekday,
  NthWeek
} from '@/types';
import { cn } from '@/utils/cn';

interface RecurrenceEditorProps {
  value: RecurrenceRule | null;
  onChange: (rule: RecurrenceRule) => void;
}

const weekdays: { id: Weekday; label: string }[] = [
  { id: 'MON', label: 'Seg' },
  { id: 'TUE', label: 'Ter' },
  { id: 'WED', label: 'Qua' },
  { id: 'THU', label: 'Qui' },
  { id: 'FRI', label: 'Sex' },
  { id: 'SAT', label: 'Sáb' },
  { id: 'SUN', label: 'Dom' }
];

const nthOptions: { value: NthWeek; label: string }[] = [
  { value: 1, label: 'Primeira' },
  { value: 2, label: 'Segunda' },
  { value: 3, label: 'Terceira' },
  { value: 4, label: 'Quarta' },
  { value: 'LAST', label: 'Última' }
];

export function RecurrenceEditor({ value, onChange }: RecurrenceEditorProps) {
  const [type, setType] = useState<RecurrenceType>(value?.type || RecurrenceType.DAILY);
  const [interval, setInterval] = useState(value?.interval || 1);
  const [selectedWeekdays, setSelectedWeekdays] = useState<Weekday[]>(
    value?.type === RecurrenceType.WEEKLY ? value.weekdays : ['MON']
  );
  const [biweeklyDay, setBiweeklyDay] = useState(
    value?.type === RecurrenceType.BIWEEKLY ? value.dayOfPeriod : 1
  );
  const [monthlyMode, setMonthlyMode] = useState<MonthlyMode>(
    value?.type === RecurrenceType.MONTHLY ? value.monthlyMode : MonthlyMode.DAY_OF_MONTH
  );
  const [dayOfMonth, setDayOfMonth] = useState(
    value?.type === RecurrenceType.MONTHLY && value.monthlyMode === MonthlyMode.DAY_OF_MONTH
      ? value.dayOfMonth : 1
  );
  const [nth, setNth] = useState<NthWeek>(
    value?.type === RecurrenceType.MONTHLY && value.monthlyMode === MonthlyMode.NTH_WEEKDAY
      ? value.nth : 1
  );
  const [nthWeekday, setNthWeekday] = useState<Weekday>(
    value?.type === RecurrenceType.MONTHLY && value.monthlyMode === MonthlyMode.NTH_WEEKDAY
      ? value.weekday : 'MON'
  );
  const [endMode, setEndMode] = useState<EndMode>(value?.end.mode || EndMode.NEVER);
  const [untilDate, setUntilDate] = useState(
    value?.end.mode === EndMode.UNTIL_DATE ? value.end.untilDate || '' : ''
  );
  const [endCount, setEndCount] = useState(
    value?.end.mode === EndMode.AFTER_COUNT ? value.end.count || 10 : 10
  );
  
  useEffect(() => {
    const buildRule = (): RecurrenceRule => {
      const end = endMode === EndMode.NEVER
        ? { mode: EndMode.NEVER as const }
        : endMode === EndMode.UNTIL_DATE
          ? { mode: EndMode.UNTIL_DATE as const, untilDate }
          : { mode: EndMode.AFTER_COUNT as const, count: endCount };
      
      switch (type) {
        case RecurrenceType.DAILY:
          return { type: RecurrenceType.DAILY, interval, end };
        case RecurrenceType.WEEKLY:
          return { type: RecurrenceType.WEEKLY, interval, weekdays: selectedWeekdays, end };
        case RecurrenceType.BIWEEKLY:
          return { type: RecurrenceType.BIWEEKLY, interval, dayOfPeriod: biweeklyDay, end };
        case RecurrenceType.MONTHLY:
          if (monthlyMode === MonthlyMode.DAY_OF_MONTH) {
            return {
              type: RecurrenceType.MONTHLY,
              interval,
              monthlyMode: MonthlyMode.DAY_OF_MONTH,
              dayOfMonth,
              end
            };
          } else {
            return {
              type: RecurrenceType.MONTHLY,
              interval,
              monthlyMode: MonthlyMode.NTH_WEEKDAY,
              nth,
              weekday: nthWeekday,
              end
            };
          }
      }
    };
    
    onChange(buildRule());
  }, [type, interval, selectedWeekdays, biweeklyDay, monthlyMode, dayOfMonth, nth, nthWeekday, endMode, untilDate, endCount, onChange]);
  
  const toggleWeekday = (day: Weekday) => {
    setSelectedWeekdays(prev =>
      prev.includes(day)
        ? prev.filter(d => d !== day)
        : [...prev, day]
    );
  };
  
  return (
    <div className="space-y-4">
      {/* Type selector */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Frequência</label>
        <div className="flex flex-wrap gap-2">
          {[
            { id: RecurrenceType.DAILY, label: 'Diário' },
            { id: RecurrenceType.WEEKLY, label: 'Semanal' },
            { id: RecurrenceType.BIWEEKLY, label: 'Quinzenal' },
            { id: RecurrenceType.MONTHLY, label: 'Mensal' }
          ].map(opt => (
            <button
              key={opt.id}
              type="button"
              onClick={() => setType(opt.id)}
              className={cn(
                'px-4 py-2 rounded-lg text-sm font-medium transition-all',
                type === opt.id
                  ? 'bg-pink-500 text-white'
                  : 'bg-pink-50 text-pink-600 hover:bg-pink-100'
              )}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>
      
      {/* Interval */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          A cada {type === RecurrenceType.DAILY ? 'dias' : type === RecurrenceType.WEEKLY ? 'semanas' : 'meses'}
        </label>
        <input
          type="number"
          min="1"
          max="365"
          value={interval}
          onChange={(e) => setInterval(Math.max(1, parseInt(e.target.value) || 1))}
          className="w-24 px-3 py-2 border border-pink-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
        />
      </div>
      
      {/* Weekly: Weekdays */}
      {type === RecurrenceType.WEEKLY && (
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Dias da semana</label>
          <div className="flex flex-wrap gap-2">
            {weekdays.map(day => (
              <button
                key={day.id}
                type="button"
                onClick={() => toggleWeekday(day.id)}
                className={cn(
                  'w-10 h-10 rounded-full text-sm font-medium transition-all',
                  selectedWeekdays.includes(day.id)
                    ? 'bg-pink-500 text-white'
                    : 'bg-pink-50 text-pink-600 hover:bg-pink-100'
                )}
              >
                {day.label.charAt(0)}
              </button>
            ))}
          </div>
        </div>
      )}
      
      {/* Biweekly: Day of period */}
      {type === RecurrenceType.BIWEEKLY && (
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Dia dentro da quinzena (1-15)
          </label>
          <input
            type="number"
            min="1"
            max="15"
            value={biweeklyDay}
            onChange={(e) => setBiweeklyDay(Math.min(15, Math.max(1, parseInt(e.target.value) || 1)))}
            className="w-24 px-3 py-2 border border-pink-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
          />
          <p className="mt-2 text-xs text-gray-500">
            1ª quinzena: dias 1-15 | 2ª quinzena: dias 16-fim do mês
          </p>
        </div>
      )}
      
      {/* Monthly options */}
      {type === RecurrenceType.MONTHLY && (
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Tipo mensal</label>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setMonthlyMode(MonthlyMode.DAY_OF_MONTH)}
                className={cn(
                  'px-4 py-2 rounded-lg text-sm font-medium transition-all',
                  monthlyMode === MonthlyMode.DAY_OF_MONTH
                    ? 'bg-pink-500 text-white'
                    : 'bg-pink-50 text-pink-600 hover:bg-pink-100'
                )}
              >
                Dia do mês
              </button>
              <button
                type="button"
                onClick={() => setMonthlyMode(MonthlyMode.NTH_WEEKDAY)}
                className={cn(
                  'px-4 py-2 rounded-lg text-sm font-medium transition-all',
                  monthlyMode === MonthlyMode.NTH_WEEKDAY
                    ? 'bg-pink-500 text-white'
                    : 'bg-pink-50 text-pink-600 hover:bg-pink-100'
                )}
              >
                Dia da semana
              </button>
            </div>
          </div>
          
          {monthlyMode === MonthlyMode.DAY_OF_MONTH ? (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Dia</label>
              <input
                type="number"
                min="1"
                max="31"
                value={dayOfMonth}
                onChange={(e) => setDayOfMonth(Math.min(31, Math.max(1, parseInt(e.target.value) || 1)))}
                className="w-24 px-3 py-2 border border-pink-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
              />
            </div>
          ) : (
            <div className="flex gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Qual</label>
                <select
                  value={String(nth)}
                  onChange={(e) => {
                    const val = e.target.value;
                    setNth(val === 'LAST' ? 'LAST' : parseInt(val) as 1 | 2 | 3 | 4);
                  }}
                  className="px-3 py-2 border border-pink-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
                >
                  {nthOptions.map(opt => (
                    <option key={String(opt.value)} value={String(opt.value)}>{opt.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Dia</label>
                <select
                  value={nthWeekday}
                  onChange={(e) => setNthWeekday(e.target.value as Weekday)}
                  className="px-3 py-2 border border-pink-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-500"
                >
                  {weekdays.map(day => (
                    <option key={day.id} value={day.id}>{day.label}</option>
                  ))}
                </select>
              </div>
            </div>
          )}
        </div>
      )}
      
      {/* End condition */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Termina</label>
        <div className="space-y-2">
          <label className="flex items-center gap-2">
            <input
              type="radio"
              checked={endMode === EndMode.NEVER}
              onChange={() => setEndMode(EndMode.NEVER)}
              className="text-pink-500 focus:ring-pink-500"
            />
            <span className="text-sm text-gray-700">Nunca</span>
          </label>
          <label className="flex items-center gap-2">
            <input
              type="radio"
              checked={endMode === EndMode.UNTIL_DATE}
              onChange={() => setEndMode(EndMode.UNTIL_DATE)}
              className="text-pink-500 focus:ring-pink-500"
            />
            <span className="text-sm text-gray-700">Até a data:</span>
            {endMode === EndMode.UNTIL_DATE && (
              <input
                type="date"
                value={untilDate}
                onChange={(e) => setUntilDate(e.target.value)}
                className="px-2 py-1 border border-pink-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-pink-500"
              />
            )}
          </label>
          <label className="flex items-center gap-2">
            <input
              type="radio"
              checked={endMode === EndMode.AFTER_COUNT}
              onChange={() => setEndMode(EndMode.AFTER_COUNT)}
              className="text-pink-500 focus:ring-pink-500"
            />
            <span className="text-sm text-gray-700">Após</span>
            {endMode === EndMode.AFTER_COUNT && (
              <>
                <input
                  type="number"
                  min="1"
                  max="999"
                  value={endCount}
                  onChange={(e) => setEndCount(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-16 px-2 py-1 border border-pink-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-pink-500"
                />
                <span className="text-sm text-gray-700">ocorrências</span>
              </>
            )}
          </label>
        </div>
      </div>
    </div>
  );
}
