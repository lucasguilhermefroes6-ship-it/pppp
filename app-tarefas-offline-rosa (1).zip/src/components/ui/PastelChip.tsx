import { cn } from '@/utils/cn';

interface PastelChipProps {
  children: React.ReactNode;
  color?: 'pink' | 'blue' | 'green' | 'orange' | 'purple' | 'gray';
  size?: 'sm' | 'md';
  className?: string;
  onClick?: () => void;
  active?: boolean;
}

// Tudo em tons de rosa!
const colorStyles = {
  pink: 'bg-pink-100 text-pink-600',
  blue: 'bg-pink-50 text-pink-500',
  green: 'bg-pink-100 text-pink-600',
  orange: 'bg-pink-200 text-pink-700',
  purple: 'bg-pink-100 text-pink-600',
  gray: 'bg-pink-50 text-pink-400'
};

const activeStyles = {
  pink: 'bg-pink-500 text-white',
  blue: 'bg-pink-500 text-white',
  green: 'bg-pink-500 text-white',
  orange: 'bg-pink-500 text-white',
  purple: 'bg-pink-500 text-white',
  gray: 'bg-pink-400 text-white'
};

export function PastelChip({
  children,
  color = 'pink',
  size = 'sm',
  className,
  onClick,
  active = false
}: PastelChipProps) {
  return (
    <span
      onClick={onClick}
      className={cn(
        'inline-flex items-center font-medium rounded-full font-poppins',
        size === 'sm' ? 'px-2.5 py-0.5 text-xs' : 'px-3 py-1 text-sm',
        active ? activeStyles[color] : colorStyles[color],
        onClick && 'cursor-pointer hover:opacity-80 transition-opacity',
        className
      )}
    >
      {children}
    </span>
  );
}
