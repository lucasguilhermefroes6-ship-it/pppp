import { cn } from '@/utils/cn';

interface PrimaryButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  type?: 'button' | 'submit';
  disabled?: boolean;
  variant?: 'solid' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  icon?: React.ReactNode;
  fullWidth?: boolean;
}

export function PrimaryButton({
  children,
  onClick,
  type = 'button',
  disabled = false,
  variant = 'solid',
  size = 'md',
  className,
  icon,
  fullWidth = false
}: PrimaryButtonProps) {
  const baseStyles = 'inline-flex items-center justify-center font-bold font-poppins rounded-xl transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:ring-offset-2';
  
  const variants = {
    solid: 'bg-gradient-to-r from-pink-400 to-pink-500 text-white hover:from-pink-500 hover:to-pink-600 shadow-[0_6px_16px_rgba(236,72,153,0.35)]',
    outline: 'border-2 border-pink-400 text-pink-500 hover:bg-pink-50',
    ghost: 'text-pink-500 hover:bg-pink-50'
  };
  
  const sizes = {
    sm: 'px-3 py-1.5 text-sm gap-1.5',
    md: 'px-5 py-2.5 text-sm gap-2',
    lg: 'px-6 py-3 text-base gap-2'
  };
  
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={cn(
        baseStyles,
        variants[variant],
        sizes[size],
        fullWidth && 'w-full',
        disabled && 'opacity-50 cursor-not-allowed',
        className
      )}
    >
      {icon}
      {children}
    </button>
  );
}
