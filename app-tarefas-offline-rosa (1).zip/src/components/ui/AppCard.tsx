import { cn } from '@/utils/cn';

interface AppCardProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
  hoverable?: boolean;
}

export function AppCard({ children, className, onClick, hoverable = false }: AppCardProps) {
  return (
    <div
      onClick={onClick}
      className={cn(
        'bg-white rounded-2xl shadow-sm border border-pink-100/50',
        'p-4',
        hoverable && 'cursor-pointer hover:shadow-md hover:border-pink-200 transition-all duration-200',
        onClick && 'cursor-pointer',
        className
      )}
    >
      {children}
    </div>
  );
}
