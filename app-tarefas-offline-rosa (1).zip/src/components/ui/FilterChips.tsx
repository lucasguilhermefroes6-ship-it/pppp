import { FilterType } from '@/types';
import { cn } from '@/utils/cn';

interface FilterChipsProps {
  activeFilter: FilterType;
  onChange: (filter: FilterType) => void;
}

const filters: { id: FilterType; label: string }[] = [
  { id: 'all', label: 'Todas' },
  { id: 'today', label: 'Hoje' },
  { id: 'pending', label: 'Pendentes' },
  { id: 'completed', label: 'Concluídas' },
  { id: 'high', label: 'Alta' },
  { id: 'medium', label: 'Média' },
  { id: 'low', label: 'Baixa' }
];

export function FilterChips({ activeFilter, onChange }: FilterChipsProps) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
      {filters.map((filter) => (
        <button
          key={filter.id}
          onClick={() => onChange(filter.id)}
          className={cn(
            'flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-all duration-200',
            activeFilter === filter.id
              ? 'bg-pink-500 text-white shadow-md shadow-pink-500/30'
              : 'bg-pink-50 text-pink-600 hover:bg-pink-100'
          )}
        >
          {filter.label}
        </button>
      ))}
    </div>
  );
}
