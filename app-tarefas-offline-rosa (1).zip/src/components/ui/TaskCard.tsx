import React from 'react';
import { Check, Clock, Repeat, Tag, ChevronRight } from 'lucide-react';
import { cn } from '@/utils/cn';
import { TaskWithRelations, Priority, OccurrenceStatus } from '@/types';
import { PastelChip } from './PastelChip';
import { parseRecurrenceRule } from '@/services/recurrenceService';
import { RecurrenceType } from '@/types';

interface TaskCardProps {
  task: TaskWithRelations;
  onToggle: () => void;
  onClick: () => void;
}

const priorityConfig = {
  [Priority.HIGH]: { label: 'Alta', color: 'orange' as const },
  [Priority.MEDIUM]: { label: 'Média', color: 'blue' as const },
  [Priority.LOW]: { label: 'Baixa', color: 'gray' as const }
};

function getRecurrenceLabel(ruleJson?: string): string | null {
  if (!ruleJson) return null;
  const rule = parseRecurrenceRule(ruleJson);
  if (!rule) return null;
  
  switch (rule.type) {
    case RecurrenceType.DAILY:
      return rule.interval === 1 ? 'Diário' : `A cada ${rule.interval} dias`;
    case RecurrenceType.WEEKLY:
      if (rule.weekdays.length === 7) return 'Todo dia';
      if (rule.weekdays.length === 5 && 
          rule.weekdays.includes('MON') && 
          rule.weekdays.includes('TUE') && 
          rule.weekdays.includes('WED') && 
          rule.weekdays.includes('THU') && 
          rule.weekdays.includes('FRI')) {
        return 'Dias úteis';
      }
      const days = rule.weekdays.map(d => {
        const dayMap: Record<string, string> = {
          'MON': 'Seg', 'TUE': 'Ter', 'WED': 'Qua',
          'THU': 'Qui', 'FRI': 'Sex', 'SAT': 'Sáb', 'SUN': 'Dom'
        };
        return dayMap[d];
      });
      return days.join(', ');
    case RecurrenceType.MONTHLY:
      return 'Mensal';
    default:
      return 'Recorrente';
  }
}

export function TaskCard({ task, onToggle, onClick }: TaskCardProps) {
  const isDone = task.occurrence?.status === OccurrenceStatus.DONE;
  const priority = priorityConfig[task.priority];
  const doneSubtasks = task.subtasks.filter(s => s.done).length;
  const totalSubtasks = task.subtasks.length;
  const recurrenceLabel = getRecurrenceLabel(task.recurrenceRuleJson);
  
  // Debug state para tarefas semanais
  const [debugInfo, setDebugInfo] = React.useState<string>('');
  const [clickCount, setClickCount] = React.useState(0);
  
  // Verificar se é tarefa semanal
  const isWeekly = task.recurrenceRuleJson?.includes('"type":"WEEKLY"');
  
  // Handler de clique com debug
  const handleToggleWithDebug = () => {
    setClickCount(prev => prev + 1);
    setDebugInfo(`Clique ${clickCount + 1} - Chamando onToggle...`);
    try {
      onToggle();
      setDebugInfo(`Clique ${clickCount + 1} - onToggle executado!`);
    } catch (error: any) {
      setDebugInfo(`Erro: ${error.message}`);
    }
  };
  
  return (
    <div
      className={cn(
        'bg-white rounded-2xl border border-pink-100 p-4',
        'shadow-[0_2px_8px_rgba(236,72,153,0.08)]',
        'hover:shadow-[0_4px_16px_rgba(236,72,153,0.15)] hover:border-pink-200 transition-all duration-200',
        isDone && 'opacity-60'
      )}
    >
      <div className="flex items-start gap-3">
        {/* Checkbox */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            handleToggleWithDebug();
          }}
          className={cn(
            'flex-shrink-0 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all mt-0.5',
            isDone
              ? 'bg-gradient-to-r from-pink-400 to-pink-500 border-pink-500 text-white'
              : 'border-pink-300 hover:border-pink-500'
          )}
        >
          {isDone && <Check className="w-4 h-4" />}
        </button>
        
        {/* Content */}
        <div className="flex-1 min-w-0" onClick={onClick}>
          <div className="flex items-center justify-between gap-2">
            <h3
              className={cn(
                'font-semibold font-poppins text-pink-700 truncate cursor-pointer',
                isDone && 'line-through text-pink-400'
              )}
            >
              {task.title}
            </h3>
            <div className="flex items-center gap-2 flex-shrink-0">
              <PastelChip color={priority.color}>{priority.label}</PastelChip>
              <ChevronRight className="w-4 h-4 text-pink-300" />
            </div>
          </div>
          
          {/* Time */}
          {task.dueTime && (
            <div className="flex items-center gap-1.5 mt-1.5 text-sm text-pink-400">
              <Clock className="w-3.5 h-3.5" />
              <span>{task.dueTime}</span>
            </div>
          )}
          
          {/* Chips */}
          <div className="flex flex-wrap items-center gap-2 mt-2">
            {/* Status do Ciclo - Mostrar apenas Atrasada (não mostrar Pendente) */}
            {task.recurrenceEnabled && task.cycleStatus === 'overdue' && (
              <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-orange-100 text-orange-700">
                ⚠️ Atrasada
              </span>
            )}
            
            {recurrenceLabel && (
              <PastelChip color="purple" size="sm">
                <Repeat className="w-3 h-3 mr-1" />
                {recurrenceLabel}
              </PastelChip>
            )}
            
            {totalSubtasks > 0 && (
              <PastelChip color="blue" size="sm">
                {doneSubtasks}/{totalSubtasks}
              </PastelChip>
            )}
            
            {task.tags.map(tag => (
              <PastelChip key={tag.id} color="green" size="sm">
                <Tag className="w-3 h-3 mr-1" />
                {tag.name}
              </PastelChip>
            ))}
          </div>
          
          {/* Debug Info - apenas para tarefas semanais */}
          {isWeekly && (
            <div className="mt-2 p-2 bg-yellow-50 border border-yellow-200 rounded text-xs">
              <div><strong>DEBUG (Semanal):</strong></div>
              <div>ID: {task.id.substring(0, 8)}...</div>
              <div>cycleStatus: {task.cycleStatus || 'N/A'}</div>
              <div>isDone: {isDone ? 'SIM' : 'NÃO'}</div>
              <div>occurrence: {task.occurrence ? 'existe' : 'null'}</div>
              <div>Cliques: {clickCount}</div>
              {debugInfo && <div className="text-blue-600">{debugInfo}</div>}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
