import { cn } from '@/utils/cn';

interface Tab {
  id: string;
  label: string;
  icon?: React.ReactNode;
}

interface SegmentedTabsProps {
  tabs: Tab[];
  activeTab: string;
  onChange: (id: string) => void;
  className?: string;
}

export function SegmentedTabs({ tabs, activeTab, onChange, className }: SegmentedTabsProps) {
  return (
    <div className={cn('inline-flex bg-pink-100 rounded-xl p-1 shadow-[0_2px_8px_rgba(236,72,153,0.1)]', className)}>
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => onChange(tab.id)}
          className={cn(
            'flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold font-poppins transition-all duration-200',
            activeTab === tab.id
              ? 'bg-gradient-to-r from-pink-400 to-pink-500 text-white shadow-[0_4px_12px_rgba(236,72,153,0.3)]'
              : 'hover:opacity-80'
          )}
          style={activeTab !== tab.id ? { color: '#6D1E4B' } : undefined}
        >
          {tab.icon}
          {tab.label}
        </button>
      ))}
    </div>
  );
}
