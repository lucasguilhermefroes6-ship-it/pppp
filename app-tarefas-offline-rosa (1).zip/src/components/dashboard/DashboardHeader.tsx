import { Menu, Calendar, Moon, Sun, Trophy } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface DashboardHeaderProps {
  selectedDate?: Date;
  isDarkMode?: boolean;
  onMenuClick?: () => void;
  onCalendarClick?: () => void;
  onThemeToggle?: () => void;
}

export function DashboardHeader({ 
  selectedDate,
  isDarkMode = false,
  onMenuClick, 
  onCalendarClick, 
  onThemeToggle 
}: DashboardHeaderProps) {
  const displayDate = selectedDate || new Date();
  const dayOfWeek = format(displayDate, 'EEEE', { locale: ptBR });
  const dateFormatted = format(displayDate, "dd 'de' MMMM 'de' yyyy", { locale: ptBR });

  // Check if selected date is today
  const isToday = displayDate.toDateString() === new Date().toDateString();

  return (
    <div className={`${isDarkMode 
      ? 'bg-gradient-to-b from-pink-900/50 via-pink-900/30 to-[#1a1a2e]' 
      : 'bg-gradient-to-b from-[#FFC8E6] via-[#FFE0F2] to-[#FFF5FA]'
    }`}>
      <div className="px-4 pt-10 pb-6 max-w-lg mx-auto">
        {/* Top Row: Icons & Badge */}
        <div className="flex items-center justify-between mb-5">
          {/* Left Icons */}
          <div className="flex items-center gap-1">
            <button 
              onClick={onMenuClick}
              className={`w-11 h-11 flex items-center justify-center rounded-xl transition-all active:scale-95 ${
                isDarkMode 
                  ? 'bg-white/10 hover:bg-white/20' 
                  : 'bg-white/50 hover:bg-white/70'
              }`}
              style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}
              aria-label="Abrir menu"
            >
              <Menu className={`w-5 h-5 ${isDarkMode ? 'text-pink-400' : 'text-[#E84393]'}`} />
            </button>
            <button 
              onClick={onCalendarClick}
              className={`w-11 h-11 flex items-center justify-center rounded-xl transition-all active:scale-95 ${
                isDarkMode 
                  ? 'bg-white/10 hover:bg-white/20' 
                  : 'bg-white/50 hover:bg-white/70'
              }`}
              style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}
              aria-label="Selecionar data"
            >
              <Calendar className={`w-5 h-5 ${isDarkMode ? 'text-pink-400' : 'text-[#E84393]'}`} />
            </button>
            <button 
              onClick={onThemeToggle}
              className={`w-11 h-11 flex items-center justify-center rounded-xl transition-all active:scale-95 ${
                isDarkMode 
                  ? 'bg-white/10 hover:bg-white/20' 
                  : 'bg-white/50 hover:bg-white/70'
              }`}
              style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}
              aria-label={isDarkMode ? 'Modo claro' : 'Modo escuro'}
            >
              {isDarkMode ? (
                <Sun className="w-5 h-5 text-yellow-400" />
              ) : (
                <Moon className="w-5 h-5 text-[#E84393]" />
              )}
            </button>
          </div>

          {/* Level Badge */}
          <div 
            className={`flex items-center gap-1.5 backdrop-blur-sm px-4 py-2 rounded-full ${
              isDarkMode 
                ? 'bg-white/10 text-pink-400 border border-pink-500/30' 
                : 'bg-white/80 text-[#E84393] border border-[#F0A8C8]'
            }`}
            style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}
          >
            <Trophy className={`w-4 h-4 ${isDarkMode ? 'text-pink-400' : 'text-[#E84393]'}`} />
            <span className="text-sm font-bold font-poppins">Nv 1</span>
          </div>
        </div>

        {/* Date Display - Poppins Bold */}
        <div className="text-center">
          <h1 className={`text-2xl font-bold font-poppins capitalize tracking-tight ${
            isDarkMode ? 'text-pink-400' : 'text-[#2B1B2B]'
          }`}>
            {dayOfWeek}
          </h1>
          <p className={`text-sm mt-1 font-poppins font-medium ${
            isDarkMode ? 'text-pink-300' : 'text-[#7A5A73]'
          }`}>
            {dateFormatted}
          </p>
          
          {/* Show indicator if not today */}
          {!isToday && (
            <div className={`mt-2 inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium ${
              isDarkMode 
                ? 'bg-pink-500/20 text-pink-300' 
                : 'bg-[#FFCCE0] text-[#E84393]'
            }`}>
              <Calendar className="w-3 h-3" />
              <span>Visualizando outra data</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
