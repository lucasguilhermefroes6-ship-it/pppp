import { 
  X, 
  CheckSquare, 
  Target, 
  Timer, 
  FileText,
  Droplets,
  Moon,
  Dumbbell,
  Heart,
  DollarSign,
  BarChart3,
  Folder,
  Scale,
  Sparkles,
  Lock,
  Edit3,
  Home,
  Settings,
  User,
  HelpCircle,
  Star
} from 'lucide-react';
import { Screen } from '@/types/screens';

interface SideDrawerProps {
  isOpen: boolean;
  isDarkMode?: boolean;
  onClose: () => void;
  onNavigate: (screen: Screen) => void;
}

interface MenuItem {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  screen: Screen;
}

const menuItems: MenuItem[] = [
  { icon: Home, label: 'Início', screen: { name: 'home' } },
  { icon: CheckSquare, label: 'Tarefas', screen: { name: 'tasks' } },
  { icon: Target, label: 'Metas', screen: { name: 'goals' } },
  { icon: Timer, label: 'Pomodoro', screen: { name: 'pomodoro' } },
  { icon: FileText, label: 'Anotações', screen: { name: 'notes' } },
  { icon: Droplets, label: 'Água', screen: { name: 'water' } },
  { icon: Moon, label: 'Sono', screen: { name: 'sleep' } },
  { icon: Dumbbell, label: 'Treino', screen: { name: 'workout' } },
  { icon: Heart, label: 'Humor', screen: { name: 'mood' } },
  { icon: DollarSign, label: 'Finanças', screen: { name: 'expenses' } },
  { icon: BarChart3, label: 'Estatísticas', screen: { name: 'stats' } },
  { icon: Folder, label: 'Pastas', screen: { name: 'folders' } },
  { icon: Scale, label: 'Medidas', screen: { name: 'measurements' } },
  { icon: Sparkles, label: 'Feminilidade', screen: { name: 'femininity' } },
  { icon: Lock, label: 'Diário Secreto', screen: { name: 'secret-diary' } },
  { icon: Edit3, label: 'Bloco de Notas', screen: { name: 'notepad' } },
];

export function SideDrawer({ isOpen, isDarkMode = false, onClose, onNavigate }: SideDrawerProps) {
  const handleNavigate = (screen: Screen) => {
    onNavigate(screen);
    onClose();
  };

  return (
    <>
      {/* Backdrop */}
      <div 
        className={`fixed inset-0 bg-black/40 backdrop-blur-sm z-40 transition-opacity duration-300 ${
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onClose}
      />

      {/* Drawer */}
      <div 
        className={`fixed top-0 left-0 h-full w-80 z-50 transform transition-transform duration-300 ease-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } ${isDarkMode ? 'bg-gray-900' : 'bg-[#FFF8FC]'}`}
        style={{ boxShadow: '0 8px 32px rgba(0,0,0,0.15)' }}
      >
        {/* Header */}
        <div className={`p-6 ${
          isDarkMode 
            ? 'bg-gradient-to-r from-pink-900/50 to-purple-900/50' 
            : 'bg-gradient-to-r from-[#FF5DAF] to-[#FF7DC4]'
        }`}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold font-poppins text-white">
              Menu
            </h2>
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center hover:bg-white/30 transition-colors"
            >
              <X className="w-5 h-5 text-white" />
            </button>
          </div>

          {/* User Profile Area */}
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-full bg-white/20 flex items-center justify-center">
              <User className="w-7 h-7 text-white" />
            </div>
            <div>
              <p className="text-white font-semibold font-poppins">Olá, Querida! 💕</p>
              <div className="flex items-center gap-1 mt-0.5">
                <Star className="w-3.5 h-3.5 text-yellow-300 fill-yellow-300" />
                <span className="text-white/80 text-xs">Nível 1</span>
              </div>
            </div>
          </div>
        </div>

        {/* Menu Items */}
        <div className="flex-1 overflow-y-auto py-4 px-3" style={{ maxHeight: 'calc(100vh - 200px)' }}>
          <div className="space-y-1">
            {menuItems.map((item, index) => (
              <button
                key={index}
                onClick={() => handleNavigate(item.screen)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all active:scale-[0.98] ${
                  isDarkMode 
                    ? 'hover:bg-white/10 text-gray-200' 
                    : 'hover:bg-[#FFD6EA] text-[#2B1B2B]'
                }`}
              >
                <div 
                  className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    isDarkMode ? 'bg-pink-500/20' : 'bg-[#FFF0F8]'
                  }`}
                >
                  <item.icon className={`w-5 h-5 ${isDarkMode ? 'text-pink-400' : 'text-[#FF5DAF]'}`} />
                </div>
                <span className="font-medium font-poppins">{item.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className={`absolute bottom-0 left-0 right-0 p-4 border-t ${
          isDarkMode ? 'border-gray-800 bg-gray-900' : 'border-[#F3C9DF] bg-[#FFF8FC]'
        }`}>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => handleNavigate({ name: 'settings' })}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl transition-colors ${
                isDarkMode 
                  ? 'bg-white/10 hover:bg-white/20 text-gray-300' 
                  : 'bg-[#FFF0F8] hover:bg-[#FFD6EA] text-[#7A5A73]'
              }`}
            >
              <Settings className={`w-5 h-5 ${isDarkMode ? 'text-pink-400' : 'text-[#FF5DAF]'}`} />
              <span className="text-sm font-medium">Configurações</span>
            </button>
            <button 
              onClick={() => handleNavigate({ name: 'settings' })}
              className={`w-12 h-12 rounded-xl flex items-center justify-center transition-colors ${
                isDarkMode 
                  ? 'bg-white/10 hover:bg-white/20 text-gray-300' 
                  : 'bg-[#FFF0F8] hover:bg-[#FFD6EA] text-[#7A5A73]'
              }`}
            >
              <HelpCircle className={`w-5 h-5 ${isDarkMode ? 'text-pink-400' : 'text-[#FF5DAF]'}`} />
            </button>
          </div>

          <p className={`text-center text-xs mt-3 ${isDarkMode ? 'text-gray-500' : 'text-[#7A5A73]'}`}>
            Feito com 💕 para você
          </p>
        </div>
      </div>
    </>
  );
}
