import { Sparkles } from 'lucide-react';

const TIPS = [
  'Lembre-se de beber água, querida! Como você está se sentindo hoje?',
  'Você já fez uma pausa hoje? Cuide de você! 🌸',
  'Respire fundo e lembre-se: você é incrível! ✨',
  'Que tal um momento de autocuidado hoje?',
  'Você está cuidando bem de si mesma? 💖',
];

interface AssistantCardProps {
  isDarkMode?: boolean;
}

export function AssistantCard({ isDarkMode = false }: AssistantCardProps) {
  // Get a tip based on the current hour to vary throughout the day
  const tipIndex = new Date().getHours() % TIPS.length;
  const currentTip = TIPS[tipIndex];

  return (
    <div 
      className={`rounded-[20px] border p-4 transition-shadow ${
        isDarkMode 
          ? 'bg-gray-800/50 border-pink-500/20'
          : 'bg-white border-[#F3C9DF]'
      }`}
      style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}
    >
      <div className="flex items-start gap-4">
        {/* Icon */}
        <div 
          className={`w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0 ${
            isDarkMode 
              ? 'bg-gradient-to-br from-pink-400 to-pink-500'
              : 'bg-[#FFF0F8]'
          }`}
          style={{ boxShadow: isDarkMode ? '0 6px 16px rgba(236,72,153,0.4)' : '0 4px 12px rgba(255,93,175,0.2)' }}
        >
          <Sparkles className={`w-7 h-7 ${isDarkMode ? 'text-white' : 'text-[#FF5DAF]'}`} />
        </div>

        {/* Content */}
        <div className="flex-1 pt-1">
          <h3 className={`font-bold font-poppins flex items-center gap-1.5 ${
            isDarkMode ? 'text-pink-400' : 'text-[#2B1B2B]'
          }`}>
            Sua Assistente Pessoal 
            <span className="text-lg">💕</span>
          </h3>
          <p className={`text-sm mt-1.5 leading-relaxed ${
            isDarkMode ? 'text-pink-300/80' : 'text-[#7A5A73]'
          }`}>
            {currentTip}
          </p>
        </div>
      </div>
    </div>
  );
}
