import { LucideIcon } from 'lucide-react';

export interface SectionTitleProps {
  title: string;
  icon?: LucideIcon;
  isDarkMode?: boolean;
}

export function SectionTitle({ title, icon: Icon, isDarkMode = false }: SectionTitleProps) {
  return (
    <div className="flex items-center gap-2.5 mb-4">
      {Icon && (
        <div 
          className={`w-8 h-8 rounded-xl flex items-center justify-center ${
            isDarkMode 
              ? 'bg-gradient-to-br from-pink-400 to-pink-500'
              : 'bg-gradient-to-br from-[#FFEBF5] to-[#FFD6EC]'
          }`}
          style={{ boxShadow: isDarkMode ? '0 4px 12px rgba(236,72,153,0.3)' : '0 2px 8px rgba(232,67,147,0.2)' }}
        >
          <Icon className={`w-4 h-4 ${isDarkMode ? 'text-white' : 'text-[#E84393]'}`} />
        </div>
      )}
      <h2 className={`text-lg font-bold font-poppins ${
        isDarkMode ? 'text-pink-400' : 'text-[#FF5DAF]'
      }`}>
        {title}
      </h2>
    </div>
  );
}
