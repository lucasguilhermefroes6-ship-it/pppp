import { cn } from '@/utils/cn';

export type DashboardRange = 'today' | 'week';

export interface DashboardRangeToggleProps {
  value: DashboardRange;
  onChange: (range: DashboardRange) => void;
  isDarkMode?: boolean;
}

export function DashboardRangeToggle({ value, onChange, isDarkMode = false }: DashboardRangeToggleProps) {
  return (
    <div 
      className={cn(
        'flex rounded-full p-1',
        isDarkMode
          ? 'bg-gray-800/80'
          : 'bg-[#FFD6EA]'
      )}
      style={{ boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}
    >
      <button
        onClick={() => onChange('today')}
        className={cn(
          'flex-1 py-2.5 px-8 rounded-full text-sm font-bold font-poppins transition-all duration-200',
          value === 'today'
            ? isDarkMode
              ? 'bg-gradient-to-r from-pink-400 to-pink-500 text-white'
              : 'bg-[#FF5DAF] text-white'
            : isDarkMode
              ? 'text-pink-400 hover:text-pink-300'
              : 'text-[#7A5A73] hover:text-[#FF5DAF]'
        )}
        style={value === 'today' ? { boxShadow: '0 4px 12px rgba(255,93,175,0.35)' } : {}}
      >
        Hoje
      </button>
      <button
        onClick={() => onChange('week')}
        className={cn(
          'flex-1 py-2.5 px-8 rounded-full text-sm font-bold font-poppins transition-all duration-200',
          value === 'week'
            ? isDarkMode
              ? 'bg-gradient-to-r from-pink-400 to-pink-500 text-white'
              : 'bg-[#FF5DAF] text-white'
            : isDarkMode
              ? 'text-pink-400 hover:text-pink-300'
              : 'text-[#7A5A73] hover:text-[#FF5DAF]'
        )}
        style={value === 'week' ? { boxShadow: '0 4px 12px rgba(255,93,175,0.35)' } : {}}
      >
        Semana
      </button>
    </div>
  );
}
