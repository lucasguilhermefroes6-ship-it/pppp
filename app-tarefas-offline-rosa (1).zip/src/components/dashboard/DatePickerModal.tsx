import { useState } from 'react';
import { X, ChevronLeft, ChevronRight, Calendar } from 'lucide-react';
import { format, addMonths, subMonths, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isSameMonth, isToday } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface DatePickerModalProps {
  isOpen: boolean;
  selectedDate: Date;
  isDarkMode?: boolean;
  onClose: () => void;
  onSelectDate: (date: Date) => void;
}

export function DatePickerModal({ 
  isOpen, 
  selectedDate, 
  isDarkMode = false,
  onClose, 
  onSelectDate 
}: DatePickerModalProps) {
  const [currentMonth, setCurrentMonth] = useState(selectedDate);

  if (!isOpen) return null;

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });

  // Get day of week for first day (0 = Sunday, 1 = Monday, etc.)
  const startDayOfWeek = monthStart.getDay();

  // Create empty cells for days before the start of the month
  const emptyCells = Array(startDayOfWeek).fill(null);

  const handleSelectDate = (date: Date) => {
    onSelectDate(date);
    onClose();
  };

  const handleGoToToday = () => {
    const today = new Date();
    setCurrentMonth(today);
    onSelectDate(today);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className={`relative w-full max-w-sm rounded-3xl overflow-hidden ${
        isDarkMode ? 'bg-gray-900' : 'bg-white'
      }`} style={{ boxShadow: '0 8px 32px rgba(0,0,0,0.15)' }}>
        {/* Header */}
        <div className={`p-4 ${
          isDarkMode 
            ? 'bg-gradient-to-r from-pink-900/50 to-purple-900/50' 
            : 'bg-gradient-to-r from-[#FF5DAF] to-[#FF7DC4]'
        }`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-white" />
              <h2 className="text-lg font-bold font-poppins text-white">
                Selecionar Data
              </h2>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center hover:bg-white/30 transition-colors"
            >
              <X className="w-4 h-4 text-white" />
            </button>
          </div>

          {/* Selected Date Display */}
          <div className="mt-4 text-center">
            <p className="text-white/80 text-sm">Data selecionada</p>
            <p className="text-white text-2xl font-bold font-poppins capitalize">
              {format(selectedDate, "dd 'de' MMMM", { locale: ptBR })}
            </p>
            <p className="text-white/80 text-sm">
              {format(selectedDate, 'yyyy')}
            </p>
          </div>
        </div>

        {/* Month Navigation */}
        <div className={`flex items-center justify-between p-4 border-b ${
          isDarkMode ? 'border-gray-800' : 'border-gray-100'
        }`}>
          <button
            onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
              isDarkMode 
                ? 'hover:bg-white/10 text-gray-300' 
                : 'hover:bg-gray-100 text-gray-600'
            }`}
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          <h3 className={`text-lg font-semibold font-poppins capitalize ${
            isDarkMode ? 'text-gray-200' : 'text-gray-800'
          }`}>
            {format(currentMonth, 'MMMM yyyy', { locale: ptBR })}
          </h3>

          <button
            onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
              isDarkMode 
                ? 'hover:bg-white/10 text-gray-300' 
                : 'hover:bg-gray-100 text-gray-600'
            }`}
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {/* Calendar Grid */}
        <div className="p-4">
          {/* Day Headers */}
          <div className="grid grid-cols-7 gap-1 mb-2">
            {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map((day) => (
              <div 
                key={day} 
                className={`text-center text-xs font-medium py-2 ${
                  isDarkMode ? 'text-gray-500' : 'text-gray-400'
                }`}
              >
                {day}
              </div>
            ))}
          </div>

          {/* Days Grid */}
          <div className="grid grid-cols-7 gap-1">
            {/* Empty cells */}
            {emptyCells.map((_, index) => (
              <div key={`empty-${index}`} className="aspect-square" />
            ))}

            {/* Day cells */}
            {days.map((day) => {
              const isSelected = isSameDay(day, selectedDate);
              const isTodayDate = isToday(day);
              const isCurrentMonth = isSameMonth(day, currentMonth);

              return (
                <button
                  key={day.toISOString()}
                  onClick={() => handleSelectDate(day)}
                  className={`aspect-square rounded-full flex items-center justify-center text-sm font-medium transition-all ${
                    isSelected
                      ? 'bg-[#FF5DAF] text-white shadow-lg scale-110'
                      : isTodayDate
                        ? isDarkMode
                          ? 'bg-pink-500/20 text-pink-400 ring-2 ring-pink-500/50'
                          : 'bg-[#FFD6EA] text-[#FF5DAF] ring-2 ring-[#FF5DAF]/30'
                        : isCurrentMonth
                          ? isDarkMode
                            ? 'text-gray-200 hover:bg-white/10'
                            : 'text-[#2B1B2B] hover:bg-[#FFF0F8]'
                          : isDarkMode
                            ? 'text-gray-600'
                            : 'text-[#7A5A73]/50'
                  }`}
                >
                  {format(day, 'd')}
                </button>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className={`p-4 border-t flex gap-2 ${
          isDarkMode ? 'border-gray-800' : 'border-[#F3C9DF]'
        }`}>
          <button
            onClick={handleGoToToday}
            className={`flex-1 py-3 rounded-xl font-medium transition-colors ${
              isDarkMode 
                ? 'bg-white/10 hover:bg-white/20 text-gray-200' 
                : 'bg-[#FFF0F8] hover:bg-[#FFD6EA] text-[#2B1B2B]'
            }`}
          >
            Ir para Hoje
          </button>
          <button
            onClick={onClose}
            className="flex-1 py-3 rounded-xl font-medium bg-[#FF5DAF] hover:bg-[#FF4DA0] text-white transition-colors"
          >
            Confirmar
          </button>
        </div>
      </div>
    </div>
  );
}
