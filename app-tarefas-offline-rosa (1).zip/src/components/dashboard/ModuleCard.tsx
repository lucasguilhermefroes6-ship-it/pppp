import { LucideIcon, Plus } from 'lucide-react';
import { cn } from '@/utils/cn';

export interface ModuleCardProps {
  icon: LucideIcon;
  title: string;
  subtitle: string;
  onClick: () => void;
  showAddButton?: boolean;
  onAddClick?: () => void;
  isDarkMode?: boolean;
}

export function ModuleCard({
  icon: Icon,
  title,
  subtitle,
  onClick,
  showAddButton = false,
  onAddClick,
  isDarkMode = false,
}: ModuleCardProps) {
  return (
    <div
      onClick={onClick}
      className={cn(
        'rounded-[20px] border p-4',
        'active:scale-[0.98] transition-all duration-200 cursor-pointer',
        'relative',
        isDarkMode 
          ? 'bg-gray-800/50 border-pink-500/20 hover:border-pink-500/40'
          : 'bg-white border-[#F0A8C8] hover:border-[#E84393]/50'
      )}
      style={{
        boxShadow: isDarkMode 
          ? '0 2px 8px rgba(0,0,0,0.3)'
          : '0 2px 8px rgba(0,0,0,0.06)'
      }}
    >
      {/* Add Button (for Water card) */}
      {showAddButton && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onAddClick?.();
          }}
          className={cn(
            'absolute top-3 right-3 w-8 h-8 rounded-full flex items-center justify-center transition-colors border',
            isDarkMode
              ? 'bg-pink-500/20 hover:bg-pink-500/30 border-pink-500/30'
              : 'bg-[#FFEBF5] hover:bg-[#FFCCE0] border-[#F0A8C8]'
          )}
        >
          <Plus className={`w-4 h-4 ${isDarkMode ? 'text-pink-400' : 'text-[#E84393]'}`} />
        </button>
      )}

      {/* Icon - Barbie rosa suave! */}
      <div
        className={cn(
          'w-14 h-14 rounded-2xl flex items-center justify-center mb-3',
          isDarkMode 
            ? 'bg-gradient-to-br from-pink-400 to-pink-500'
            : 'bg-gradient-to-br from-[#FFEBF5] to-[#FFD6EC]'
        )}
        style={{
          boxShadow: isDarkMode 
            ? '0 6px 16px -4px rgba(236, 72, 153, 0.3)'
            : '0 4px 12px -2px rgba(232, 67, 147, 0.25)'
        }}
      >
        <Icon className={cn(
          'w-7 h-7',
          isDarkMode ? 'text-white' : 'text-[#E84393]'
        )} />
      </div>

      {/* Title & Subtitle */}
      <h3 className={cn(
        'font-poppins font-semibold',
        isDarkMode ? 'text-gray-100' : 'text-[#2B1B2B]'
      )}>{title}</h3>
      <p className={cn(
        'text-xs mt-0.5',
        isDarkMode ? 'text-pink-400/80' : 'text-[#6B4A63]'
      )}>{subtitle}</p>
    </div>
  );
}
