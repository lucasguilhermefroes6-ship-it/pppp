import { useState, useEffect } from 'react';
import { Screen } from './types/screens';

// Screens - using correct exports
import { HomeScreen } from './screens/HomeScreen';
import { TasksScreen } from './screens/TasksScreen';
import { TaskFormScreen } from './screens/TaskFormScreen';
import GoalsScreen from './screens/GoalsScreen';
import PomodoroScreen from './screens/PomodoroScreen';
import FinancesScreen from './screens/FinancesScreen';
import NewTransactionScreen from './screens/NewTransactionScreen';
import FinanceStatsScreen from './screens/FinanceStatsScreen';
import WaterScreen from './screens/WaterScreen';
import SleepScreen from './screens/SleepScreen';
import WorkoutScreen from './screens/WorkoutScreen';
import MoodScreen from './screens/MoodScreen';
import FemininityScreen from './screens/FemininityScreen';
import NotesScreen from './screens/NotesScreen';
import NoteViewScreen from './screens/NoteViewScreen';
import NoteEditScreen from './screens/NoteEditScreen';
import FoldersScreen from './screens/FoldersScreen';
import FolderEditScreen from './screens/FolderEditScreen';
import FolderDetailScreen from './screens/FolderDetailScreen';
import FolderItemEditScreen from './screens/FolderItemEditScreen';
import FoldersSearchScreen from './screens/FoldersSearchScreen';
import MeasurementsScreen from './screens/MeasurementsScreen';
import MeasurementEditScreen from './screens/MeasurementEditScreen';
import { NotepadScreen, NotepadEditScreen } from './screens/NotepadScreen';
import { SecretDiaryGateScreen, SecretDiaryHomeScreen, SecretDiaryEditScreen, SecretDiarySettingsScreen } from './screens/SecretDiaryScreen';
import HealthSummaryScreen from './screens/HealthSummaryScreen';
import WellbeingSummaryScreen from './screens/WellbeingSummaryScreen';
import MyRecordsScreen from './screens/MyRecordsScreen';
import MyRecordsEditScreen from './screens/MyRecordsEditScreen';
import MyRecordsGoalsScreen from './screens/MyRecordsGoalsScreen';
import SettingsScreen from './screens/SettingsScreen';
import SleepWeeklySummaryScreen from './screens/SleepWeeklySummaryScreen';

// Initialize stores
import { useStore } from './store/useStore';
import { useGoalStore } from './store/useGoalStore';
import { useWaterStore } from './store/useWaterStore';
import { useSleepStore } from './store/useSleepStore';
import { useFinanceStore } from './store/useFinanceStore';
import { useFemininityStore } from './store/useFemininityStore';
import { useWorkoutStore } from './store/useWorkoutStore';
import { useMoodStore } from './store/useMoodStore';
import { useNotesStore } from './store/useNotesStore';
import { useFolderStore } from './store/useFolderStore';
import { useMeasurementsStore } from './store/useMeasurementsStore';
import { useNotepadStore } from './store/useNotepadStore';
import { useSecretDiaryStore } from './store/useSecretDiaryStore';
import { useThemeStore } from './store/useThemeStore';
import { useMyRecordsStore } from './store/useMyRecordsStore';

function App() {
  const [screen, setScreen] = useState<Screen>({ name: 'home' });
  
  // Initialize all stores on mount
  useEffect(() => {
    const initializeApp = async () => {
      console.log('Initializing Vida Rosa app...');
      try {
        await useStore.getState().initialize();
        await useGoalStore.getState().initialize();
        await useWaterStore.getState().initialize();
        await useSleepStore.getState().initialize();
        await useFinanceStore.getState().initialize();
        await useFemininityStore.getState().initialize();
        await useWorkoutStore.getState().initialize();
        await useMoodStore.getState().initialize();
        await useNotesStore.getState().initialize();
        await useFolderStore.getState().loadFolders();
        await useMeasurementsStore.getState().loadEntries();
        await useNotepadStore.getState().loadNotes();
        await useSecretDiaryStore.getState().loadSettings();
        await useThemeStore.getState().initialize();
        await useMyRecordsStore.getState().initDB();
        console.log('App initialized successfully!');
      } catch (error) {
        console.error('Error initializing app:', error);
      }
    };
    initializeApp();
  }, []);

  // Render the appropriate screen
  const renderScreen = () => {
    switch (screen.name) {
      case 'home':
        return <HomeScreen onNavigate={setScreen} />;
      
      // Tasks
      case 'tasks':
        return <TasksScreen onNavigate={setScreen} />;
      case 'task-form':
        return (
          <TaskFormScreen 
            taskId={'taskId' in screen ? screen.taskId : undefined} 
            onNavigate={setScreen} 
          />
        );
      
      // Goals
      case 'goals':
        return <GoalsScreen onNavigate={setScreen} />;
      
      // Pomodoro
      case 'pomodoro':
        return <PomodoroScreen onNavigate={setScreen} />;
      
      // Finances
      case 'expenses':
        return <FinancesScreen onNavigate={setScreen} />;
      case 'new-transaction':
        return (
          <NewTransactionScreen 
            isFixed={'isFixed' in screen ? screen.isFixed as boolean : false}
            editTransactionId={'editTransactionId' in screen ? screen.editTransactionId as string : undefined}
            onNavigate={setScreen} 
          />
        );
      case 'stats':
        return <FinanceStatsScreen onNavigate={setScreen} />;
      
      // Water
      case 'water':
        return <WaterScreen onNavigate={setScreen} />;
      
      // Sleep
      case 'sleep':
        return <SleepScreen onNavigate={setScreen} />;
      
      // Workout
      case 'workout':
        return <WorkoutScreen onNavigate={setScreen} />;
      
      // Mood
      case 'mood':
        return <MoodScreen onNavigate={setScreen} />;
      
      // Femininity
      case 'femininity':
        return <FemininityScreen onNavigate={setScreen} />;
      
      // Notes
      case 'notes':
        return <NotesScreen onNavigate={setScreen} />;
      case 'note-view':
        return (
          <NoteViewScreen 
            noteId={'noteId' in screen ? screen.noteId : ''}
            onNavigate={setScreen} 
          />
        );
      case 'note-edit':
        return (
          <NoteEditScreen 
            noteId={'noteId' in screen ? screen.noteId : undefined}
            onNavigate={setScreen} 
          />
        );
      
      // Folders
      case 'folders':
        return <FoldersScreen onNavigate={setScreen} />;
      case 'folder-edit':
        return (
          <FolderEditScreen 
            folderId={'folderId' in screen ? screen.folderId : undefined}
            onNavigate={setScreen} 
          />
        );
      case 'folder-detail':
        return (
          <FolderDetailScreen 
            folderId={'folderId' in screen ? screen.folderId : ''}
            onNavigate={setScreen} 
          />
        );
      case 'folder-item-edit':
        return (
          <FolderItemEditScreen 
            folderId={'folderId' in screen ? screen.folderId : ''}
            itemId={'itemId' in screen ? screen.itemId : undefined}
            itemType={'itemType' in screen ? screen.itemType : undefined}
            onNavigate={setScreen} 
          />
        );
      case 'folders-search':
        return <FoldersSearchScreen onNavigate={setScreen} />;
      
      // Measurements
      case 'measurements':
        return <MeasurementsScreen setScreen={setScreen} />;
      case 'measurement-edit':
        return (
          <MeasurementEditScreen 
            entryId={'entryId' in screen ? screen.entryId : undefined}
            setScreen={setScreen} 
          />
        );
      
      // Notepad
      case 'notepad':
        return <NotepadScreen setScreen={setScreen} />;
      case 'notepad-edit':
        return (
          <NotepadEditScreen 
            noteId={'noteId' in screen ? screen.noteId : undefined}
            setScreen={setScreen} 
          />
        );
      
      // Secret Diary
      case 'secret-diary':
        return <SecretDiaryGateScreen setScreen={setScreen} />;
      case 'secret-diary-home':
        return <SecretDiaryHomeScreen setScreen={setScreen} />;
      case 'secret-diary-edit':
        return (
          <SecretDiaryEditScreen 
            entryId={'entryId' in screen ? screen.entryId : undefined}
            createNew={'createNew' in screen ? screen.createNew : false}
            setScreen={setScreen} 
          />
        );
      case 'secret-diary-settings':
        return <SecretDiarySettingsScreen setScreen={setScreen} />;
      
      // Summaries
      case 'health-summary':
        return <HealthSummaryScreen setScreen={setScreen} />;
      case 'wellbeing-summary':
        return <WellbeingSummaryScreen setScreen={setScreen} />;
      
      // My Records
      case 'my-records':
        return <MyRecordsScreen setScreen={setScreen} />;
      case 'my-records-edit':
        return (
          <MyRecordsEditScreen 
            dateKey={'dateKey' in screen ? screen.dateKey : undefined}
            setScreen={setScreen} 
          />
        );
      case 'my-records-goals':
        return <MyRecordsGoalsScreen setScreen={setScreen} />;
      
      // Settings
      case 'settings':
        return (
          <SettingsScreen 
            setScreen={setScreen}
            isDarkMode={useThemeStore.getState().mode === 'dark'}
            setIsDarkMode={(value) => useThemeStore.getState().setTheme(value ? 'dark' : 'light')}
          />
        );
      
      // Sleep Weekly Summary
      case 'sleep-weekly-summary':
        return <SleepWeeklySummaryScreen setScreen={setScreen} />;
      
      default:
        return <HomeScreen onNavigate={setScreen} />;
    }
  };

  return (
    <div className="font-poppins">
      {renderScreen()}
    </div>
  );
}

export default App;
